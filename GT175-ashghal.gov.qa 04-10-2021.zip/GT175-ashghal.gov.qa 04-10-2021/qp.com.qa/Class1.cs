﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace ScrapClass
{
    public class Class1
    {

        static SqlConnection sqlconnection;
        public SqlDataReader MySqlDataReader;
        SqlConnection ErrConnection;
        SqlCommand Sqlcmd = new SqlCommand();
        static string ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
        //*******************************************************************************************************************UAS
        int MFA = 0; //0:SelFinance , 
        int status = 2; //0-Fresh Records , 1-in process, 2 - for all clear
        int Com_QC = 0; //1 -CQC Required, 0- Not Required
        int Sel_status = 1;//0- Sel Required,1- Sel High,2- Sel Low,3- Sel Reject
        int CPV_status = 1;////0- CPV Required,1- CPV Done
        int Q_status = 1;//0- QC Required,1- QC Done
        string icb_ncb = "icb";
        int notice_type = 2;
        string reg_Id = "Rg00003";
        Boolean Go = false;
        string filename = string.Empty;
        string gt_idref = string.Empty;


        public string MySqlQuery = ""; string OnLeft = ""; string OnRight = ""; string OnRight0 = ""; string OnRight1 = ""; string OnRight2 = ""; string ReplyStrings = ""; string MyWorkBuff = ""; string MyNullString = ""; string MySingleSpace = " ";
        public int Posting_Id = 0; int MyBegin = -1; int MyEnd = -1; int MyCurr1 = -1; int MyCurr2 = -1; int MyCurr = -1; int MyReturnValue = 1; int MyReturnCode = 0;
        List<string> RequiredFields = new List<string>(); List<string> RequiredPages = new List<string>();
        int country = 0;
        int mj = 0;
        int sd = 0;
        int td = 0;

        public int SegDoc(string HtmlDoc, string DocPath)
        {
           
                MyReturnValue = 0;
                ScrapData(HtmlDoc, DocPath);
                if (RequiredPages[20].Length > 200)
                {
                    RequiredPages[20] = RequiredPages[20].Remove(200).ToString().Trim();
                    RequiredPages[20] = RequiredPages[20] + "...";
                }
                try
                {
                    if (RequiredPages[70] != "")
                    {
                        string DeadLine = RequiredPages[70];
                        DateTime dt = Convert.ToDateTime(DeadLine);
                        DateTime dt2 = Convert.ToDateTime(System.DateTime.Today);
                        TimeSpan ts = dt - dt2;
                        int days = ts.Days;
                        if (days >= 1)
                        {
                            if (RequiredPages[20] == "")
                            {
                                MessageBox.Show("ShortDesc Blank !!!");
                                sd++;
                                if (sd >= 3)
                                {
                                    MessageBox.Show("Give it for Maintenance now !!!");
                                    //Environment.Exit(0);
                                    //Application.Exit();
                                }
                            }
                            else
                            {
                                InsertRecord(RequiredFields, HtmlDoc, DocPath);
                            }
                        }
                        else
                        {
                            GlobalLevel.Global.expired++;
                        }
                    }
                    else
                    {
                        if (RequiredPages[20] == "")
                        {
                            MessageBox.Show("ShortDesc Blank !!!");
                            sd++;
                            if (sd >= 3)
                            {
                                MessageBox.Show("Give it for Maintenance now !!!");
                                //Environment.Exit(0);
                                //Application.Exit();
                            }
                        }
                        else if (RequiredPages[30] == "")
                        {
                            MessageBox.Show("TenderDetails Blank !!!");
                            td++;
                            if (td >= 3)
                            {
                                MessageBox.Show("Give it for Maintenance now !!!");
                                //Environment.Exit(0);
                                //Application.Exit();
                            }

                        }
                        else
                        {
                            InsertRecord(RequiredFields, HtmlDoc, DocPath);
                        }
                    }

                }
                catch
                {
                    InsertRecord(RequiredFields, HtmlDoc, DocPath);
                }
                return MyReturnCode;          
        }
        public void ScrapData(string HtmlDoc, string DocPath)
        {
            string status = "";
            string type = "";
            string bond = "";
            string value = "";
            string closedate = "";
            string opendate = "";
            RequiredFields.Clear();
            for (int i = 0; i < 40; i++)
            {
                RequiredFields.Add(MyNullString);
            }
            RequiredPages.Clear();
            for (int i = 0; i < 400; i++)
            {
                RequiredPages.Add(MyNullString);
            }
            OnLeft = MyNullString;
            OnRight0 = MyNullString;
            OnRight1 = MyNullString;
            OnRight2 = MyNullString;
            ReplyStrings = MyNullString;
            HtmlDoc = HtmlDoc.Replace("&amp;", "&").Trim();
            HtmlDoc = HtmlDoc.Replace("&nbsp;", " ").Trim();

            //****************************Email ID********************************10 to 20
            //OnLeft = "<SPAN id=emailNamespan>";
            //OnRight0 = "</SPAN>";
            //OnRight1 = "";
            //OnRight2 = "";
            //ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            //ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            ReplyStrings = HtmlDoc;
            if (ReplyStrings != "")
            {
                string[] res = GetEmail(ReplyStrings);
                if (res.Length >= 1)
                {
                    ReplyStrings = "";
                    foreach (string element in res)
                    {
                        if (ReplyStrings == "")
                        {
                            ReplyStrings = element;
                        }
                        else
                        {
                            if (!ReplyStrings.Contains(element))
                            {
                                //ReplyStrings = ReplyStrings + ", " + element;
                            }
                        }
                    }
                    RequiredPages[280] = ReplyStrings.Trim().ToString();
                }
                else
                {
                    RequiredPages[280] = "";
                }
            }

            //****************************Address********************************20 to 30
            //1
            HtmlDoc = HtmlDoc.Replace("&nbsp;", " ");
            OnLeft = "class=\"contact-details-icon\">";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = ReplyStrings.Replace("<br />", "<br />\r\n");
            ReplyStrings = ReplyStrings.Replace("<br/>", "<br/>\r\n");
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            if (ReplyStrings != "")
            {
                RequiredPages[60] = ReplyStrings;
            }
            else
            {
                RequiredPages[60] = "";
            }

            //2
            //HtmlDoc = HtmlDoc.Replace("&nbsp;", " ");
            //OnLeft = "<SPAN id=regionspan>";
            //OnRight0 = "</SPAN>";
            //OnRight1 = "";
            //OnRight2 = "";
            //ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            //ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            //if (ReplyStrings != "")
            //{
            //    RequiredPages[21] = "\n<BR>Region: " + ReplyStrings;
            //}

            //****************************Address2********************************30 to 40
            //****************************City********************************40 to 50
            //****************************State********************************50 to 60
            //****************************PinCode********************************60 to 70
            //****************************Country********************************70 to 80
            RequiredPages[40] = "QA";

            //****************************URL********************************80 to 90
            //****************************Tel********************************90 to 100
            //****************************Fax********************************100 to 110
            //****************************Contact_Person********************************110 to 120
            //****************************Maj_Org********************************120 to 130
            //if (HtmlDoc.Contains("Buyer:</th>"))
            //{ OnLeft = "Buyer:</th>"; }
            //else { OnLeft = "Department :</th>"; }
            ////OnLeft = "Buyer:";
            //OnRight0 = "</td>";
            //OnRight1 = "";
            //OnRight2 = "";
            //ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);

            //ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            //ReplyStrings = ReplyStrings.Replace("*", "").Trim();
            //ReplyStrings = ReplyStrings.Replace("\r\n", "").Trim();
            //ReplyStrings = ReplyStrings.Replace("\r", "").Trim();
            //ReplyStrings = ReplyStrings.Replace("\n", "").Trim();
            //RequiredPages[120] = ReplyStrings;
            //if (ReplyStrings != "")
            {
                RequiredPages[50] = "Public Works Authority".ToUpper();
            }
            //else
            //{
            //    ReplyStrings = "Central Public Works Department".ToUpper();
            //    RequiredPages[120] = ReplyStrings.ToUpper();
            //}

            //****************************tender_notice_no********************************130 to 140
            OnLeft = "TenderNumberValue\">";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            ReplyStrings = ReplyStrings.Replace("*", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r\n", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\n", "").Trim();
            if (ReplyStrings != "")
            {
                RequiredPages[10] = ReplyStrings;
            }
            else
            {
                OnLeft = "TenderNumberValue>";
                OnRight0 = "</span>";
                OnRight1 = "</SPAN>";
                OnRight2 = "";
                ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);

                ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                ReplyStrings = ReplyStrings.Replace("*", "").Trim();
                ReplyStrings = ReplyStrings.Replace("\r\n", "").Trim();
                ReplyStrings = ReplyStrings.Replace("\r", "").Trim();
                ReplyStrings = ReplyStrings.Replace("\n", "").Trim();
                if (ReplyStrings != "")
                {
                    RequiredPages[10] = ReplyStrings;
                }
            }

            //****************************notice_type********************************140 to 150
            //RequiredPages[140] = "2";
            //****************************ind_classification********************************150 to 160
            //****************************global********************************160 to 170
            //RequiredPages[160] = "1";
            //****************************MFA********************************170 to 180
            //****************************tenders_details********************************180 to 190
            //1
            //RequiredPages[180] = RequiredPages[190];


            //****************************short_desc ********************************190 to 200
            //HtmlDoc = HtmlDoc.Replace("Description Of Work:", "Description of Work:");
            OnLeft = "TenderTitleValue\">";
            OnRight0 = "</";
            OnRight1 = "";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            ReplyStrings = ReplyStrings.Replace("*", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r\n", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\n", "").Trim();

            ReplyStrings = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(ReplyStrings.ToLower());
            if (ReplyStrings != "")
            {
                RequiredPages[20] = ReplyStrings;
                RequiredPages[30] = ReplyStrings;
            }
            else
            {
                OnLeft = "TenderTitleValue>";
                OnRight0 = "</";
                OnRight1 = "";
                OnRight2 = "";
                ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);

                ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                ReplyStrings = ReplyStrings.Replace("*", "").Trim();
                ReplyStrings = ReplyStrings.Replace("\r\n", "").Trim();
                ReplyStrings = ReplyStrings.Replace("\r", "").Trim();
                ReplyStrings = ReplyStrings.Replace("\n", "").Trim();

                ReplyStrings = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(ReplyStrings.ToLower());
                if (ReplyStrings != "")
                {
                    RequiredPages[20] = ReplyStrings;
                    RequiredPages[30] = ReplyStrings;
                }
                else
                {

                }

            }
            //****************************              ********************************190 to 200
                        
            //2
            OnLeft = "TypeValue\">";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            if (ReplyStrings != "")
            {
                type = "\n<BR><B>Tender Type: </B>" + ReplyStrings;
            }
            else
            {
                OnLeft = "TypeValue>";
                OnRight0 = "</span>";
                OnRight1 = "</SPAN>";
                OnRight2 = "";
                ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                if (ReplyStrings != "")
                {
                    type = "\n<BR><B>Tender Type: </B>" + ReplyStrings;
                }
                else
                {

                }

            }
           
            //3 
            OnLeft = "Tender Participants</span>";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            if (ReplyStrings != "")
            {
                value = "\n<BR><B>Tender ParticipantsValue: </B>" + ReplyStrings;
            }
            else
            {
                OnLeft = "TenderParticipantsValue>";
                OnRight0 = "</span>";
                OnRight1 = "</SPAN>";
                OnRight2 = "";
                ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                if (ReplyStrings != "")
                {
                    value = "\n<BR><B>Tender ParticipantsValue: </B>" + ReplyStrings;
                }
            }
            
            //4 
            OnLeft = "TenderBondValue\">";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            if (ReplyStrings != "")
            {
                bond = "\n<BR><B>Tender BondValue: </B>" + ReplyStrings;
            }
            else
            {
                OnLeft = "TenderBondValue>";
                OnRight0 = "</span>";
                OnRight1 = "</SPAN>";
                OnRight2 = "";
                ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                if (ReplyStrings != "")
                {
                    bond = "\n<BR><B>Tender BondValue: </B>" + ReplyStrings;
                }
            }

            
            //5 
            OnLeft = "TenderStatusValue\">";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            if (ReplyStrings != "")
            {
                status = "\n<BR><B>Tender StatusValue: </B>" + ReplyStrings;
            }
            else
            {
                OnLeft = "TenderStatusValue>";
                OnRight0 = "</span>";
                OnRight1 = "</SPAN>";
                OnRight2 = "";
                ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                if (ReplyStrings != "")
                {
                    status = "\n<BR><B>Tender StatusValue: </B>" + ReplyStrings;
                }
                else
                {

                }
            }

            OnLeft = "doc-fees\">";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            if (ReplyStrings != "")
            {
                RequiredPages[80] = "Tender Processing Fee: " + ReplyStrings;
            }
            else
            {
                OnLeft = "doc-fees>";
                OnRight0 = "</span>";
                OnRight1 = "</SPAN>";
                OnRight2 = "";
                ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                if (ReplyStrings != "")
                {
                    RequiredPages[80] = "Tender Processing Fee: " + ReplyStrings;
                }
                else
                {

                }
            }//IssuingDateValue

            if (HtmlDoc.Contains("TenderIssuingDateValue\">"))
                OnLeft = "TenderIssuingDateValue\">";
            else
                OnLeft = "TenderIssuingDateValue>";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            ReplyStrings = ReplyStrings.Replace("*", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r\n", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\n", "").Trim();
            opendate = ReplyStrings;
            opendate = "\n<BR><B>Opening Date: </B>" + opendate;

            if (HtmlDoc.Contains("TenderCloseDateValue\">"))
                OnLeft = "TenderCloseDateValue\">";
            else
                OnLeft = "TenderCloseDateValue>";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            ReplyStrings = ReplyStrings.Replace("*", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r\n", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\n", "").Trim();
            closedate = ReplyStrings;
            closedate = "\n<BR><B>Closing Date: </B>" + closedate;

            RequiredPages[30] = "<B>Tenders are invited for : </B>" + RequiredPages[20] + type + value + bond + status + opendate + closedate;

            //RequiredPages[180] = RequiredPages[190];
            //****************************est_cost********************************200 to 210
            //****************************currency********************************210 to 220
            //****************************doc_cost********************************220 to 230
            //****************************doc_start********************************230 to 240
            //****************************doc_last********************************240 to 250
            if (HtmlDoc.Contains("TenderCloseDateValue\">"))
                OnLeft = "TenderCloseDateValue\">";
            else
                OnLeft = "TenderCloseDateValue>";
            OnRight0 = "</span>";
            OnRight1 = "</SPAN>";
            OnRight2 = "";
            ReplyStrings = GetRqdStr(HtmlDoc, OnLeft, OnRight0, OnRight1, OnRight2);
            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
            ReplyStrings = ReplyStrings.Replace("*", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r\n", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\r", "").Trim();
            ReplyStrings = ReplyStrings.Replace("\n", "").Trim();
            try
            {
                string DeadLine = ReplyStrings;
                DeadLine = DeadLine.Replace(" ", "/");
                DateTime MyDateTime = new DateTime();
                MyDateTime = DateTime.ParseExact(DeadLine, "dd/MMMM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                string deadline = MyDateTime.ToString("yyyy-MM-dd");
                RequiredPages[70] = deadline.ToString();
            }
            catch
            {
                try
                {
                    string DeadLine = ReplyStrings;
                    DeadLine = DeadLine.Replace("-", "/");
                    DateTime MyDateTime = new DateTime();
                    MyDateTime = Convert.ToDateTime(ReplyStrings);
                    string deadline = MyDateTime.ToString("yyyy-MM-dd");
                    RequiredPages[70] = deadline.ToString();
                }
                catch
                {
                    RequiredPages[70] = ReplyStrings;
                }
            }

            if (RequiredPages[70] == "")
            {

            }

            //****************************open_date********************************250 to 260
            //****************************earnest_money********************************260 to 270
            //****************************Financier********************************270 to 280
            //****************************tender_doc_file********************************280 to 290
            RequiredPages[190] = DocPath;

            //****************************Sector********************************290 to 300
            //****************************corregendum********************************300 to 310
            //****************************source********************************310 to 320
            RequiredPages[180] = "ashghal.gov.qa";
        }
        public int InsertRecord(List<string> SegFields, string HtmlDoc, string DocPath)
        {
            CombineParasInRequiredFields();
            Fields_Validation(SegFields);
            SegFields[18] = SegFields[18].Replace("\n<BR>\n<BR>", "\n<BR>");






            SegFields[21] = notice_type.ToString();//notice_type
            SegFields[03] = SegFields[03].Replace("\r\n\r\n", "<BR>\r\n");


            SegFields[03] = SegFields[03].Replace("\r\n\r\n", "<BR>\r\n");
            SegFields[05] = SegFields[05].ToUpper();
            if (SegFields[02].Length > 200)
            {
                SegFields[02] = SegFields[02].Remove(200).ToString().Trim();
                SegFields[02] = SegFields[02] + "...";
            }
            if (SegFields[05].Length > 300)
            {
                SegFields[05] = SegFields[05].Remove(296).ToString().Trim();
                SegFields[05] = SegFields[05] + "...";
            }
            if (SegFields[01].Length > 100)
            {
                SegFields[01] = SegFields[01].Remove(96).ToString().Trim();
                SegFields[01] = SegFields[01] + "...";
            }

            SegFields[2] = SegFields[2].Replace("\r\n<BR>", "<BR>\r\n");
            SegFields[2] = SegFields[2].Replace("\r\n<br>", "<BR>\r\n");
            SegFields[2] = SegFields[2].Replace("Na&Nbsp;\r\n<br>", "");
            SegFields[2] = SegFields[2].Replace("Na \r\n<BR>", "");
            SegFields[2] = SegFields[2].Replace("\r\n\r\n", "<BR>\r\n");



            //==============================GoodTenders=======================
            SegFields[25] = Sel_status.ToString();
            SegFields[26] = CPV_status.ToString();
            SegFields[27] = Q_status.ToString();
            SegFields[16] = icb_ncb.ToString();
            SegFields[24] = Com_QC.ToString();
            SegFields[23] = reg_Id;
            SegFields[20] = status.ToString();
            SegFields[14] = MFA.ToString();
            SegFields[15] = MFA.ToString();
            SegFields[05] = SegFields[05].ToUpper();
            //===============================================





            CheckDuplicate(SegFields);
            if (Go == true)
            {
                GlobalLevel.Global.duplicate++;
                ShutDataReader();
                ShutConnection();
                return 1;
            }
            else
            {

                HtmlDoc = HtmlDoc.Replace("&amp;", "&");
                HtmlDoc = "<html lang=\"en\"><head>  <title>GoodTenders.com | Tenders Document </title> <meta charset = \"utf-8\">   <meta name =\"viewport\" content = \"width=device-width, initial-scale=1\">  <link rel =\"stylesheet\" href = \"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"><script src =\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>   <script src = \"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>     </head>" +
              "<body><div class=\"container\">  <h2>Tender Details</h2>  <table class=\"table table-hover\">    <tbody>" + HtmlDoc + "</tbody>  </table></div></body></html>";



                string id2 = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                string id = id2;
                Int64 gt_id = Int64.Parse(id.ToString());
                gt_id++;
                gt_idref = gt_id.ToString();
                int a = 0;
                while (a == 0)
                {
                    try
                    {
                        if (System.IO.Directory.Exists(@"E://Documents"))
                        {
                            string strOpFileName = "E://Documents//GT175" + gt_id.ToString() + ".html";
                            filename = "E://Documents//GT175" + gt_id.ToString() + ".html";
                            System.IO.StreamWriter swOut = new System.IO.StreamWriter(strOpFileName, false, Encoding.Unicode);
                            swOut.Write(HtmlDoc);
                            swOut.Close();
                            a++;
                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Please Map DocData folder to  Server..and create Z: Drive", "'" + SegFields[18].ToString() + "'");
                        }
                    }
                    catch (Exception)
                    {
                        a = 0;
                    }

                }

                ShutDataReader();
                int MyLoop = 0;
                while (MyLoop == 0)
                {



                    ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
                    using (SqlConnection connection = new SqlConnection(ConnectionString))
                    {
                        String query = "INSERT INTO [Masterdb_AMS].[dbo].[tblTenders]([file_id],[tender_notice_no],[short_description],[tender_details],[org_country],[organisation_name] ,[org_address] ,[org_email] ,[org_url] ,[org_City] ,[org_State] ,[org_PinCode] ,[org_Tel] ,[org_Fax] ,[org_Contact_Person] ,[deadline] ,[deadline_2] ,[est_cost] ,[currency] ,[doc_cost] ,[doc_start] ,[open_date] ,[earnest_money] ,[financier] ,[MFA] ,[ncbicb] ,[cpv_value] ,[source] ,[tender_doc_file] ,[status],[notice_type] ,[quality_addeddate] ,[file_name] ,[region_id] ,[compulsary_qc] ,[ext1] ,[ext2] ,[Selection_status] ,[CPV_status] ,[quality_status],[added_on]) VALUES (@file_id , @tender_notice_no, @short_description, @tender_details, @org_country, @organisation_name, @org_address, @org_email, @org_url, @org_City, @org_State, @org_PinCode, @org_Tel, @org_Fax, @org_Contact_Person, @deadline, @deadline_2, @est_cost, @currency, @doc_cost, @doc_start, @open_date, @earnest_money, @financier, @MFA, @ncbicb, @cpv_value, @source, @tender_doc_file, @status, @notice_type, @quality_addeddate, @file_name, @region_id, @compulsary_qc, @ext1, @ext2, @Selection_status, @CPV_status, @quality_status,@added_on)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@file_id", gt_idref.ToString() + ".html");
                            command.Parameters.AddWithValue("@tender_notice_no", SegFields[01].ToString());
                            command.Parameters.AddWithValue("@short_description", SegFields[02].ToString());
                            command.Parameters.AddWithValue("@tender_details", SegFields[03].ToString());
                            command.Parameters.AddWithValue("@org_country", SegFields[04].ToString());
                            command.Parameters.AddWithValue("@organisation_name", SegFields[05].ToString());
                            command.Parameters.AddWithValue("@org_address", SegFields[06].ToString());
                            command.Parameters.AddWithValue("@org_email", SegFields[28].ToString());
                            command.Parameters.AddWithValue("@org_url", SegFields[29].ToString());
                            command.Parameters.AddWithValue("@org_City", SegFields[30].ToString());
                            command.Parameters.AddWithValue("@org_State", SegFields[31].ToString());
                            command.Parameters.AddWithValue("@org_PinCode", SegFields[32].ToString());
                            command.Parameters.AddWithValue("@org_Tel", SegFields[33].ToString());
                            command.Parameters.AddWithValue("@org_Fax", SegFields[34].ToString());
                            command.Parameters.AddWithValue("@org_Contact_Person", SegFields[35].ToString());
                            command.Parameters.AddWithValue("@deadline", SegFields[07].ToString());
                            command.Parameters.AddWithValue("@deadline_2", SegFields[36].ToString());
                            command.Parameters.AddWithValue("@est_cost", SegFields[08].ToString());
                            command.Parameters.AddWithValue("@currency", SegFields[09].ToString());
                            command.Parameters.AddWithValue("@doc_cost", SegFields[10].ToString());
                            command.Parameters.AddWithValue("@doc_start", SegFields[11].ToString());
                            command.Parameters.AddWithValue("@open_date", SegFields[12].ToString());
                            command.Parameters.AddWithValue("@earnest_money", SegFields[13].ToString());
                            command.Parameters.AddWithValue("@financier", SegFields[14].ToString());
                            command.Parameters.AddWithValue("@MFA", SegFields[15].ToString());
                            command.Parameters.AddWithValue("@ncbicb", SegFields[16].ToString());
                            command.Parameters.AddWithValue("@cpv_value", SegFields[17].ToString());
                            command.Parameters.AddWithValue("@source", SegFields[18].Trim().ToString());
                            command.Parameters.AddWithValue("@tender_doc_file", SegFields[19].ToString());
                            command.Parameters.AddWithValue("@status", SegFields[20].ToString());
                            command.Parameters.AddWithValue("@added_on", DateTime.Now.ToString("MM/dd/yyyy H:mm"));
                            command.Parameters.AddWithValue("@notice_type", SegFields[21].ToString());
                            command.Parameters.AddWithValue("@quality_addeddate", DateTime.Now.ToString("MM/dd/yyyy H:mm"));
                            command.Parameters.AddWithValue("@file_name", filename);
                            command.Parameters.AddWithValue("@region_id", SegFields[23].ToString());
                            command.Parameters.AddWithValue("@compulsary_qc", SegFields[24].ToString());
                            command.Parameters.AddWithValue("@ext1", SegFields[37].ToString());
                            command.Parameters.AddWithValue("@ext2", SegFields[38].ToString());
                            command.Parameters.AddWithValue("@Selection_status", SegFields[25].ToString());
                            command.Parameters.AddWithValue("@CPV_status", SegFields[26].ToString());
                            command.Parameters.AddWithValue("@quality_status", SegFields[27].ToString());


                            try
                            {
                                connection.Open();
                                int result = command.ExecuteNonQuery();
                                // Check Error
                                if (result == 1)
                                    MyLoop = 1;
                                else
                                    MyLoop = 0;

                                if (result == 1)
                                {
                                    GlobalLevel.Global.inserted++;
                                }



                            }
                            catch (Exception ex)
                            {
                                if (ex.Message.Contains("Duplicate entry"))
                                {
                                    MyLoop = 1;
                                }
                                else if (ex.Message.Contains("Fatal error encountered during command execution."))
                                {
                                    MyLoop = 0;
                                }
                                else
                                {
                                    MyLoop = 0;
                                }
                            }

                        }
                    }
                }
                ShutDataReader();
                if (GlobalLevel.Global.flagServer == false)
                {
                    //MySQLInsertRecord(SegFields, HtmlDoc);
                }
                else
                {
                    InsertRecord_Live(SegFields, HtmlDoc);
                }
            }
            return MyReturnValue;
        }
        public int InsertRecord_Live(List<string> SegFields, string HtmlDoc)
        {
            ShutDataReader();
            int MyLoop = 0;

            while (MyLoop == 0)
            {
                ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    String query = "INSERT INTO [Masterdb_AMSFinal].[dbo].[tblTenders]([file_id],[tender_notice_no],[short_description],[tender_details],[org_country],[organisation_name] ,[org_address] ,[org_email] ,[org_url] ,[org_City] ,[org_State] ,[org_PinCode] ,[org_Tel] ,[org_Fax] ,[org_Contact_Person] ,[deadline] ,[deadline_2] ,[est_cost] ,[currency] ,[doc_cost] ,[doc_start] ,[open_date] ,[earnest_money] ,[financier] ,[MFA] ,[ncbicb] ,[cpv_value] ,[source] ,[tender_doc_file] ,[status],[notice_type] ,[quality_addeddate] ,[file_name] ,[region_id] ,[compulsary_qc] ,[ext1] ,[ext2] ,[Selection_status] ,[CPV_status] ,[quality_status],[added_on]) VALUES (@file_id , @tender_notice_no, @short_description, @tender_details, @org_country, @organisation_name, @org_address, @org_email, @org_url, @org_City, @org_State, @org_PinCode, @org_Tel, @org_Fax, @org_Contact_Person, @deadline, @deadline_2, @est_cost, @currency, @doc_cost, @doc_start, @open_date, @earnest_money, @financier, @MFA, @ncbicb, @cpv_value, @source, @tender_doc_file, @status, @notice_type, @quality_addeddate, @file_name, @region_id, @compulsary_qc, @ext1, @ext2, @Selection_status, @CPV_status, @quality_status,@added_on)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@file_id", gt_idref.ToString() + ".html");
                        command.Parameters.AddWithValue("@tender_notice_no", SegFields[01].ToString());
                        command.Parameters.AddWithValue("@short_description", SegFields[02].ToString());
                        command.Parameters.AddWithValue("@tender_details", SegFields[03].ToString());
                        command.Parameters.AddWithValue("@org_country", SegFields[04].ToString());
                        command.Parameters.AddWithValue("@organisation_name", SegFields[05].ToString());
                        command.Parameters.AddWithValue("@org_address", SegFields[06].ToString());
                        command.Parameters.AddWithValue("@org_email", SegFields[28].ToString());
                        command.Parameters.AddWithValue("@org_url", SegFields[29].ToString());
                        command.Parameters.AddWithValue("@org_City", SegFields[30].ToString());
                        command.Parameters.AddWithValue("@org_State", SegFields[31].ToString());
                        command.Parameters.AddWithValue("@org_PinCode", SegFields[32].ToString());
                        command.Parameters.AddWithValue("@org_Tel", SegFields[33].ToString());
                        command.Parameters.AddWithValue("@org_Fax", SegFields[34].ToString());
                        command.Parameters.AddWithValue("@org_Contact_Person", SegFields[35].ToString());
                        command.Parameters.AddWithValue("@deadline", SegFields[07].ToString());
                        command.Parameters.AddWithValue("@deadline_2", SegFields[36].ToString());
                        command.Parameters.AddWithValue("@est_cost", SegFields[08].ToString());
                        command.Parameters.AddWithValue("@currency", SegFields[09].ToString());
                        command.Parameters.AddWithValue("@doc_cost", SegFields[10].ToString());
                        command.Parameters.AddWithValue("@doc_start", SegFields[11].ToString());
                        command.Parameters.AddWithValue("@open_date", SegFields[12].ToString());
                        command.Parameters.AddWithValue("@earnest_money", SegFields[13].ToString());
                        command.Parameters.AddWithValue("@financier", SegFields[14].ToString());
                        command.Parameters.AddWithValue("@MFA", SegFields[15].ToString());
                        command.Parameters.AddWithValue("@ncbicb", SegFields[16].ToString());
                        command.Parameters.AddWithValue("@cpv_value", SegFields[17].ToString());
                        command.Parameters.AddWithValue("@source", SegFields[18].Trim().ToString());
                        command.Parameters.AddWithValue("@tender_doc_file", SegFields[19].ToString());
                        command.Parameters.AddWithValue("@status", SegFields[20].ToString());
                        command.Parameters.AddWithValue("@added_on", DateTime.Now.ToString("MM/dd/yyyy H:mm"));
                        command.Parameters.AddWithValue("@notice_type", SegFields[21].ToString());
                        command.Parameters.AddWithValue("@quality_addeddate", DateTime.Now.ToString("MM/dd/yyyy H:mm"));
                        command.Parameters.AddWithValue("@file_name", filename);
                        command.Parameters.AddWithValue("@region_id", SegFields[23].ToString());
                        command.Parameters.AddWithValue("@compulsary_qc", SegFields[24].ToString());
                        command.Parameters.AddWithValue("@ext1", SegFields[37].ToString());
                        command.Parameters.AddWithValue("@ext2", SegFields[38].ToString());
                        command.Parameters.AddWithValue("@Selection_status", SegFields[25].ToString());
                        command.Parameters.AddWithValue("@CPV_status", SegFields[26].ToString());
                        command.Parameters.AddWithValue("@quality_status", SegFields[27].ToString());


                        try
                        {
                            connection.Open();

                            int result = command.ExecuteNonQuery();
                            // Check Error
                            if (result == 1)
                                MyLoop = 1;
                            else
                                MyLoop = 0;


                        }
                        catch (Exception ex)
                        {
                            string query1 = "INSERT INTO [Masterdb_AMSFinal].[dbo].[tblTenders] (Error_Message,Function_Name,Exe_Name) Values ('" + ex.Message.Replace("'", "`").ToString() + "','" + System.Reflection.MethodBase.GetCurrentMethod().Name.ToString() + "','" + Application.ProductName.ToString() + "')";

                            if (ex.Message.Contains("Duplicate entry"))
                            {
                                MyLoop = 1;
                            }
                            else if (ex.Message.Contains("Fatal error encountered during command execution."))
                            {
                                MyLoop = 0;
                            }
                            else
                            {
                                MyLoop = 0;
                            }
                        }
                    }
                }
            }
            return MyReturnValue;
        }
        private SqlDataReader CheckDuplicate(List<string> SegFields)
        {
            if (GlobalLevel.Global.flagServer == false)
            {
                SegFields[18] = "ashghal.gov.qa";
            }
            else
            {
                SegFields[18] = "ashghal.gov.qa";
            }

            SegFields[01] = SegFields[01].Trim();
            SegFields[2] = SegFields[2].Trim();
            SegFields[28] = SegFields[28].Trim();
            try
            {
                ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    //String query = "Select gt_id from [Masterdb_AMS].[dbo].[tblTenders_africa] where tender_notice_no = N'" + SegFields[01].ToString() + "' and short_description = N'" + SegFields[02].ToString() + "'";


                    string query = "";
                    if (SegFields[01].ToString() != "" && SegFields[04].ToString() != "")//notice_no and country
                    {
                        query = "Select gt_id from [Masterdb_AMS].[dbo].[tblTenders]  where tender_notice_no = N'" + SegFields[01].ToString() + "' and org_country = N'" + SegFields[04].ToString() + "'";
                    }
                    else if (SegFields[02].ToString() != "" && SegFields[01].ToString() != "")//shortdesc and notice_no
                    {
                        query = "Select gt_id from [Masterdb_AMS].[dbo].[tblTenders]  where short_description = N'" + SegFields[02].ToString() + "' and deadline = N'" + SegFields[07].ToString() + "'";
                    }
                    else
                    {
                        //shortdesc and country
                        query = "Select gt_id from [Masterdb_AMS].[dbo].[tblTenders]  where short_description = N'" + SegFields[02].ToString() + "' and org_country = N'" + SegFields[04].ToString() + "'";
                    }


                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.CommandTimeout = 2000;
                        try
                        {
                            MySqlDataReader = command.ExecuteReader();
                            if (MySqlDataReader.HasRows == true)
                            {
                                Go = true;
                            }
                            else
                            {
                                Go = false;
                            }
                            command.Connection.Close();
                        }
                        catch (Exception)
                        { }


                    }
                }
            }
            catch (Exception)
            { }
            ShutDataReader();
            return MySqlDataReader;

        }

        private void ShutDataReader()
        {
            try
            {
                Sqlcmd.Dispose();
                MySqlDataReader.Dispose();
                MySqlDataReader.Close();
            }
            catch
            {

            }
        }
        private void ShutConnection()
        {
            try
            {
                SqlConnection.ClearAllPools();
                //sqlconnection.Dispose();
                //sqlconnection.Close();
            }
            catch
            {

            }
        }
        
        public void Fields_Validation(List<string> SegFields)
        {
            for (int i = 0; i < 35; i++)
            {
                SegFields[i] = SegFields[i].Replace("’", "`");// for MySql
                SegFields[i] = SegFields[i].Replace("'", "`");// for MySql
                SegFields[i] = SegFields[i].Replace("‘", "`");// for MySql
                //SegFields[i] = SegFields[i].Replace("'", "''");// for SQL
                SegFields[i] = SegFields[i].Replace("&amp;", "&");
                SegFields[i] = SegFields[i].Replace("&nbsp;", " ");
                SegFields[i] = SegFields[i].Replace("â€œ", " ");
                SegFields[i] = SegFields[i].Replace("â€.", " ");
                SegFields[i] = SegFields[i].Replace("Ã", " ");
                SegFields[i] = SegFields[i].Replace("â€™", " ");
                SegFields[i] = SegFields[i].Replace("Ã©", " ");
                SegFields[i] = SegFields[i].Replace("â€¢", " ");
                SegFields[i] = SegFields[i].Replace("â€“", " ");
                SegFields[i] = SegFields[i].Replace("’", " ");
                SegFields[i] = SegFields[i].Replace("–", " ");
                SegFields[i] = SegFields[i].Replace("“", "\"");
                SegFields[i] = SegFields[i].Replace("”", "\"");
                SegFields[i] = SegFields[i].Replace("’", "\'");
                SegFields[i] = SegFields[i].Replace("'", "''");
                SegFields[i] = SegFields[i].Replace("&amp;", "&");
                SegFields[i] = SegFields[i].Replace("&Amp;", "&");
                SegFields[i] = SegFields[i].Replace("&nbsp;", " ");
                SegFields[i] = SegFields[i].Trim();
            }
            for (int i = 0; SegFields.Count - 1 > i; i++)
            {
                if (SegFields[i].Length > 2900)
                { SegFields[i] = SegFields[i].Substring(0, 2900); }
                if (SegFields[i].ToString() == "")
                { SegFields[i] = ""; }
            }
        }
        private void CombineParasInRequiredFields()
        {
            string MyNewLine = Environment.NewLine;
            int MyNewLineIn = 0;
            for (int i = 0; i < RequiredFields.Count; i++)
            {
                int PrevJ = -1;
                for (int j = (i * 10); j < ((i * 10) + 10); j++)
                {
                    if ((RequiredPages[j].Trim()) != null && (RequiredPages[j].Trim()) != "")
                    {
                        if (PrevJ == -1) // This field has freshly started
                        {
                            RequiredFields[i] = RequiredPages[j];
                            PrevJ = j;
                        }
                        else
                        {
                            if (PrevJ == j)
                            {
                                RequiredFields[i] = RequiredFields[i] + MySingleSpace + RequiredPages[j];
                                MyNewLineIn = 1;
                            }
                            else
                            {
                                RequiredFields[i] = RequiredFields[i] + "\n<BR>" + RequiredPages[j];
                                PrevJ = j;
                            }
                        }
                    }
                }
                if (RequiredFields[i] != null && RequiredFields[i] != "")
                {
                    if (MyNewLineIn != 0)
                    {
                        RequiredFields[i] = RequiredFields[i] + MyNewLine + "\n<BR>";
                        MyNewLineIn = 0;
                    }
                }
            }

        }
        public string[] GetEmail(string Email)
        {
            MatchCollection coll = default(MatchCollection);
            int i = 0;
            coll = Regex.Matches(Email, "([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})");
            string[] results = new string[coll.Count];
            for (i = 0; i <= results.Length - 1; i++)
            {
                results[i] = coll[i].Value;
            }
            return results;
        }
        public String Translate(string Text)
        {
            string Final = "";
            int loop = 1;
            while (loop == 1)
            {
                Final = "";
                try
                {

                    List<string> GlUrlList = SplitIntoChunks(Text, 300);
                    //Text = "";
                    int Length = GlUrlList.Count;
                    for (int a = 0; a <= Length - 1; a++)
                    {
                        int aa = 0;
                        while (aa <= 3)
                        {
                            try
                            {
                                GlUrlList[a] = GlUrlList[a].Replace("&nbsp;", " ");
                                try
                                {
                                    while (GlUrlList[a].Contains("&lt;"))
                                    {
                                        string remove = GlUrlList[a].Substring(GlUrlList[a].IndexOf("&lt;"));
                                        remove = remove.Substring(0, remove.IndexOf("&gt;") + 04);
                                        GlUrlList[a] = GlUrlList[a].Replace(remove, "");
                                    }
                                }
                                catch
                                { }
                                string url = String.Format("http://translate.google.com/?langpair=auto|en&text={0}", GlUrlList[a]);
                                WebClient wc = new WebClient();
                                wc.Encoding = System.Text.Encoding.UTF8;
                                System.Threading.Thread.Sleep(1000);
                                var result = wc.DownloadString(url);
                                result = result.Substring(result.IndexOf("<span id=result_box"));
                                result = result.Remove(result.IndexOf("</span></div>") + "</span></div>".Length);
                                result = result.Replace("<br>", "\r\n");
                                result = Regex.Replace(result, @"<[^>]*>", "").Trim();
                                result = result.Replace("|", "\"");
                                //result = ReplaceFields(result);
                                result = ReplaceSpecialCharacters(result);
                                result = ReplaceHtmlSpecialCharacters(result);
                                result = result.Replace("\\\"", "\"");
                                Final += result;
                                Final = Final.Replace("?", "");
                                Final = Final.Replace("�", "");
                                aa = 4;
                            }
                            catch (Exception ex)
                            {
                                aa++;
                            }
                        }
                    }
                    //Text = Final;
                    loop = 0;
                    if (Final == "")
                    {
                        //Text = Final;
                        //loop = 1;
                    }
                }
                catch (Exception Ex)
                {
                    //Text = Final;
                    loop = 1;
                    return Text;
                }
            }
            return Final;
        }
        private List<string> SplitIntoChunks(string text, int chunkSize)
        {
            List<string> chunks = new List<string>();
            int offset = 0;
            while (offset < text.Length)
            {
                int size = Math.Min(chunkSize, text.Length - offset);
                chunks.Add(text.Substring(offset, size));
                offset += size;
            }
            return chunks;
        }
        public string GetRqdStr(string TheString, string OnLeft, string OnRight0, string OnRight1, string OnRight2)
        {

            if (TheString != null && TheString.Trim() != null)
            {
                MyBegin = TheString.IndexOf(OnLeft, 0);
                if (MyBegin == -1)
                {
                    ReplyStrings = "";
                }
                else
                {
                    if (OnRight0 == null || OnRight0 == "")
                    {
                        MyCurr = -1;
                    }
                    else
                    {
                        MyCurr = TheString.IndexOf(OnRight0, (MyBegin + OnLeft.Length));
                    }
                    if (OnRight1 == null || OnRight1 == "")
                    {
                        MyCurr1 = -1;
                    }
                    else
                    {
                        MyCurr1 = TheString.IndexOf(OnRight1, (MyBegin + OnLeft.Length));
                    }
                    if (OnRight2 == null || OnRight2 == "")
                    {
                        MyCurr2 = -1;
                    }
                    else
                    {
                        MyCurr2 = TheString.IndexOf(OnRight2, (MyBegin + OnLeft.Length));
                    }
                    if (MyCurr == -1 && MyCurr1 == -1 && MyCurr2 == -1)
                    {
                        MyEnd = TheString.Length;
                    }
                    else
                    {
                        if (MyCurr == -1)
                        {
                            if (MyCurr1 == -1)
                            {
                                MyEnd = MyCurr2;
                                OnRight = OnRight2;
                            }
                            else
                            {
                                if (MyCurr2 == -1)
                                {
                                    MyEnd = MyCurr1;
                                    OnRight = OnRight1;
                                }
                                else
                                {
                                    if (MyCurr1 < MyCurr2)
                                    {
                                        MyEnd = MyCurr1;
                                        OnRight = OnRight1;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr2;
                                        OnRight = OnRight2;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (MyCurr1 == -1)
                            {
                                if (MyCurr2 == -1)
                                {
                                    MyEnd = MyCurr;
                                    OnRight = OnRight0;
                                }
                                else
                                {
                                    if (MyCurr < MyCurr2)
                                    {
                                        MyEnd = MyCurr;
                                        OnRight = OnRight0;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr2;
                                        OnRight = OnRight2;
                                    }
                                }
                            }
                            else
                            {
                                if (MyCurr2 == -1)
                                {
                                    if (MyCurr < MyCurr1)
                                    {
                                        MyEnd = MyCurr;
                                        OnRight = OnRight0;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr1;
                                        OnRight = OnRight1;
                                    }
                                }
                                else
                                {
                                    if (MyCurr < MyCurr1)
                                    {
                                        if (MyCurr < MyCurr2)
                                        {
                                            MyEnd = MyCurr;
                                            OnRight = OnRight0;
                                        }
                                        else
                                        {
                                            MyEnd = MyCurr2;
                                            OnRight = OnRight2;
                                        }
                                    }
                                    else
                                    {
                                        if (MyCurr2 < MyCurr1)
                                        {
                                            MyEnd = MyCurr2;
                                            OnRight = OnRight2;
                                        }
                                        else
                                        {
                                            MyEnd = MyCurr1;
                                            OnRight = OnRight1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    MyWorkBuff = TheString.Substring((MyBegin + OnLeft.Length),
                                                 (MyEnd - MyBegin - OnLeft.Length));
                    ReplyStrings = MyWorkBuff.Trim();
                    //ReplyStrings = MyWorkBuff.Replace(Environment.NewLine, "");                   
                }
            }
            else
            {
                ReplyStrings = "";
            }
            return ReplyStrings.Trim();
        }
        public string ReplaceSpecialCharacters(string cString)
        {
            cString = cString.Replace("â€™", "-");
            cString = cString.Replace("â€“", "-");
            cString = cString.Replace("â€", "-");
            cString = cString.Replace("â€“", "-");
            cString = cString.Replace("¢", "c");
            cString = cString.Replace("£", "£");
            cString = cString.Replace("¤", "");
            cString = cString.Replace("¥", "");
            cString = cString.Replace("¦", "");
            cString = cString.Replace("§", "§");
            cString = cString.Replace("¨", "");
            cString = cString.Replace("©", "(c)");
            cString = cString.Replace("ª", "");
            cString = cString.Replace("«", "<");
            cString = cString.Replace("¬", "-");
            cString = cString.Replace("­", "-");
            cString = cString.Replace("®", "(r)");
            cString = cString.Replace("¯", "-");
            cString = cString.Replace("°", "");
            cString = cString.Replace("±", "+/-");
            cString = cString.Replace("²", "2");
            cString = cString.Replace("´", "'");
            cString = cString.Replace("µ", "y");
            cString = cString.Replace("¶", "P");
            cString = cString.Replace("·", ".");
            cString = cString.Replace("¸", "");
            cString = cString.Replace("¹", "1");
            cString = cString.Replace("º", "");
            cString = cString.Replace("»", ">");
            cString = cString.Replace("¼", "1/4");
            cString = cString.Replace("½", "1/2");
            cString = cString.Replace("¾", "3/4");
            cString = cString.Replace("¿", "?");
            cString = cString.Replace("À", "A");
            cString = cString.Replace("Á", "A");
            cString = cString.Replace("Â", "A");
            cString = cString.Replace("Ã", "A");
            cString = cString.Replace("Ä", "Ae");
            cString = cString.Replace("Å", "A");
            cString = cString.Replace("Æ", "Ae");
            cString = cString.Replace("Ç", "C");
            cString = cString.Replace("È", "E");
            cString = cString.Replace("É", "E");
            cString = cString.Replace("Ê", "E");
            cString = cString.Replace("Ë", "E");
            cString = cString.Replace("Ì", "I");
            cString = cString.Replace("Í", "I");
            cString = cString.Replace("Î", "I");
            cString = cString.Replace("Ï", "I");
            cString = cString.Replace("Ð", "D");
            cString = cString.Replace("Ñ", "N");
            cString = cString.Replace("Ò", "O");
            cString = cString.Replace("Ó", "O");
            cString = cString.Replace("Ô", "O");
            cString = cString.Replace("Õ", "O");
            cString = cString.Replace("Ö", "Oe");
            cString = cString.Replace("×", "x");
            cString = cString.Replace("Ø", "0");
            cString = cString.Replace("Ù", "U");
            cString = cString.Replace("Ú", "U");
            cString = cString.Replace("Û", "U");
            cString = cString.Replace("Ü", "Ue");
            cString = cString.Replace("Ý", "Y");
            cString = cString.Replace("Þ", "p");
            cString = cString.Replace("ß", "ss");
            cString = cString.Replace("à", "a");
            cString = cString.Replace("á", "a");
            cString = cString.Replace("â", "a");
            cString = cString.Replace("ã", "a");
            cString = cString.Replace("ä", "ae");
            cString = cString.Replace("å", "a");
            cString = cString.Replace("æ", "ae");
            cString = cString.Replace("ç", "c");
            cString = cString.Replace("è", "e");
            cString = cString.Replace("é", "e");
            cString = cString.Replace("ê", "e");
            cString = cString.Replace("ë", "e");
            cString = cString.Replace("ì", "i");
            cString = cString.Replace("í", "i");
            cString = cString.Replace("î", "i");
            cString = cString.Replace("ï", "i");
            cString = cString.Replace("ð", "a");
            cString = cString.Replace("ñ", "n");
            cString = cString.Replace("ò", "o");
            cString = cString.Replace("ó", "o");
            cString = cString.Replace("ô", "o");
            cString = cString.Replace("õ", "o");
            cString = cString.Replace("ö", "oe");
            cString = cString.Replace("ó", "o");
            cString = cString.Replace("÷", "/");
            cString = cString.Replace("ø", "0");
            cString = cString.Replace("ù", "u");
            cString = cString.Replace("ú", "u");
            cString = cString.Replace("û", "u");
            cString = cString.Replace("ü", "ue");
            cString = cString.Replace("ý", "y");
            cString = cString.Replace("þ", "p");
            cString = cString.Replace("ÿ", "y");
            cString = cString.Replace("–", " ");
            cString = cString.Replace("“", "\"");
            cString = cString.Replace("”", "\"");
            cString = cString.Replace("’", "\'");
            cString = cString.Replace("’", "");
            cString = cString.Replace("&ndash;", "–");
            cString = cString.Replace("&mdash;", "—");
            cString = cString.Replace("&iexcl;", "¡");
            cString = cString.Replace("&iquest;", "¿");
            cString = cString.Replace("&quot;", "\"");
            cString = cString.Replace("&ldquo;", "“");
            cString = cString.Replace("&rdquo;", "”");
            cString = cString.Replace("&lsquo;", "‘");
            cString = cString.Replace("&rsquo;", "’");
            cString = cString.Replace("&laquo;", "«");
            cString = cString.Replace("&raquo;", "»");
            cString = cString.Replace("&nbsp;", "  ");
            cString = cString.Replace("&amp;", "&");
            cString = cString.Replace("&cent;", "¢");
            cString = cString.Replace("&copy;", "©");
            cString = cString.Replace("&divide;", "÷");
            cString = cString.Replace("&gt;", ">");
            cString = cString.Replace("&lt;", "<");
            cString = cString.Replace("&micro;", "µ");
            cString = cString.Replace("&middot;", "·");
            cString = cString.Replace("&para;", "¶");
            cString = cString.Replace("&plusmn;", "±");
            cString = cString.Replace("&euro;", "€");
            cString = cString.Replace("&pound;", "£");
            cString = cString.Replace("&reg;", "®");
            cString = cString.Replace("&sect;", "§");
            cString = cString.Replace("&trade;", "™");
            cString = cString.Replace("&yen;", "¥");
            cString = cString.Replace("&deg;", "°");
            cString = cString.Replace("&aacute;", "á");
            cString = cString.Replace("&Aacute;", "Á");
            cString = cString.Replace("&agrave;", "à");
            cString = cString.Replace("&Agrave;", "À");
            cString = cString.Replace("&acirc;", "â");
            cString = cString.Replace("&Acirc;", "Â");
            cString = cString.Replace("&aring;", "å");
            cString = cString.Replace("&Aring;", "Å");
            cString = cString.Replace("&atilde;", "ã");
            cString = cString.Replace("&Atilde;", "Ã");
            cString = cString.Replace("&auml;", "ä");
            cString = cString.Replace("&Auml;", "Ä");
            cString = cString.Replace("&aelig;", "æ");
            cString = cString.Replace("&AElig;", "Æ");
            cString = cString.Replace("&ccedil;", "ç");
            cString = cString.Replace("&Ccedil;", "Ç");
            cString = cString.Replace("&eacute;", "é");
            cString = cString.Replace("&Eacute;", "É");
            cString = cString.Replace("&egrave;", "è");
            cString = cString.Replace("&Egrave;", "È");
            cString = cString.Replace("&ecirc;", "ê");
            cString = cString.Replace("&Ecirc;", "Ê");
            cString = cString.Replace("&euml;", "ë");
            cString = cString.Replace("&Euml;", "Ë");
            cString = cString.Replace("&iacute;", "í");
            cString = cString.Replace("&Iacute;", "Í");
            cString = cString.Replace("&igrave;", "ì");
            cString = cString.Replace("&Igrave;", "Ì");
            cString = cString.Replace("&icirc;", "î");
            cString = cString.Replace("&Icirc;", "Î");
            cString = cString.Replace("&iuml;", "ï");
            cString = cString.Replace("&Iuml;", "Ï");
            cString = cString.Replace("&ntilde;", "ñ");
            cString = cString.Replace("&Ntilde;", "Ñ");
            cString = cString.Replace("&oacute;", "ó");
            cString = cString.Replace("&Oacute;", "Ó");
            cString = cString.Replace("&ograve;", "ò");
            cString = cString.Replace("&Ograve;", "Ò");
            cString = cString.Replace("&ocirc;", "ô");
            cString = cString.Replace("&Ocirc;", "Ô");
            cString = cString.Replace("&oslash;", "ø");
            cString = cString.Replace("&Oslash;", "Ø");
            cString = cString.Replace("&otilde;", "õ");
            cString = cString.Replace("&Otilde;", "Õ");
            cString = cString.Replace("&ouml;", "ö");
            cString = cString.Replace("&Ouml;", "Ö");
            cString = cString.Replace("&szlig;", "ß");
            cString = cString.Replace("&uacute;", "ú");
            cString = cString.Replace("&Uacute;", "Ú");
            cString = cString.Replace("&ugrave;", "ù");
            cString = cString.Replace("&Ugrave;", "Ù");
            cString = cString.Replace("&ucirc;", "û");
            cString = cString.Replace("&Ucirc;", "Û");
            cString = cString.Replace("&uuml;", "ü");
            cString = cString.Replace("&Uuml;", "Ü");
            cString = cString.Replace("&yuml;", "ÿ");
            cString = cString.Replace("¡", ";");
            cString = cString.Replace("Ã­", "i");
            cString = cString.Replace("Ã³", "o");
            cString = cString.Replace("Ãº", "u");
            cString = cString.Replace("â€™", "-");
            cString = cString.Replace("â€“", "-");
            cString = cString.Replace("â€", "-");
            cString = cString.Replace("â€“", "-");
            cString = cString.Replace("¢", "c");
            cString = cString.Replace("£", "£");
            cString = cString.Replace("¤", "");
            cString = cString.Replace("¥", "");
            cString = cString.Replace("¦", "");
            cString = cString.Replace("§", "§");
            cString = cString.Replace("¨", "");
            cString = cString.Replace("©", "(c)");
            cString = cString.Replace("ª", "");
            cString = cString.Replace("«", "<");
            cString = cString.Replace("¬", "-");
            cString = cString.Replace("­", "-");
            cString = cString.Replace("®", "(r)");
            cString = cString.Replace("¯", "-");
            cString = cString.Replace("°", "");
            cString = cString.Replace("±", "+/-");
            cString = cString.Replace("²", "2");
            //cString = cString.Replace("³", "3");
            cString = cString.Replace("´", "'");
            cString = cString.Replace("µ", "y");
            cString = cString.Replace("¶", "P");
            cString = cString.Replace("·", ".");
            cString = cString.Replace("¸", "");
            cString = cString.Replace("¹", "1");
            cString = cString.Replace("º", "");
            cString = cString.Replace("»", ">");
            cString = cString.Replace("¼", "1/4");
            cString = cString.Replace("½", "1/2");
            cString = cString.Replace("¾", "3/4");
            cString = cString.Replace("¿", "?");
            cString = cString.Replace("À", "A");
            cString = cString.Replace("Á", "A");
            cString = cString.Replace("Â", "A");
            cString = cString.Replace("Ã", "A");
            cString = cString.Replace("Ä", "Ae");
            cString = cString.Replace("Å", "A");
            cString = cString.Replace("Æ", "Ae");
            cString = cString.Replace("Ç", "C");
            cString = cString.Replace("È", "E");
            cString = cString.Replace("É", "E");
            cString = cString.Replace("Ê", "E");
            cString = cString.Replace("Ë", "E");
            cString = cString.Replace("Ì", "I");
            cString = cString.Replace("Í", "I");
            cString = cString.Replace("Î", "I");
            cString = cString.Replace("Ï", "I");
            cString = cString.Replace("Ð", "D");
            cString = cString.Replace("Ñ", "N");
            cString = cString.Replace("Ò", "O");
            cString = cString.Replace("Ó", "O");
            cString = cString.Replace("Ô", "O");
            cString = cString.Replace("Õ", "O");
            cString = cString.Replace("Ö", "Oe");
            cString = cString.Replace("×", "x");
            cString = cString.Replace("Ø", "0");
            cString = cString.Replace("Ù", "U");
            cString = cString.Replace("Ú", "U");
            cString = cString.Replace("Û", "U");
            cString = cString.Replace("Ü", "Ue");
            cString = cString.Replace("Ý", "Y");
            cString = cString.Replace("Þ", "p");
            cString = cString.Replace("ß", "ss");
            cString = cString.Replace("à", "a");
            cString = cString.Replace("á", "a");
            cString = cString.Replace("â", "a");
            cString = cString.Replace("ã", "a");
            cString = cString.Replace("ä", "ae");
            cString = cString.Replace("å", "a");
            cString = cString.Replace("æ", "ae");
            cString = cString.Replace("ç", "c");
            cString = cString.Replace("è", "e");
            cString = cString.Replace("é", "e");
            cString = cString.Replace("ê", "e");
            cString = cString.Replace("ë", "e");
            cString = cString.Replace("ì", "i");
            cString = cString.Replace("í", "i");
            cString = cString.Replace("î", "i");
            cString = cString.Replace("ï", "i");
            cString = cString.Replace("ð", "a");
            cString = cString.Replace("ñ", "n");
            cString = cString.Replace("ò", "o");
            cString = cString.Replace("ó", "o");
            cString = cString.Replace("ô", "o");
            cString = cString.Replace("õ", "o");
            cString = cString.Replace("ö", "oe");
            cString = cString.Replace("ó", "o");
            cString = cString.Replace("÷", "/");
            cString = cString.Replace("ø", "0");
            cString = cString.Replace("ù", "u");
            cString = cString.Replace("ú", "u");
            cString = cString.Replace("û", "u");
            cString = cString.Replace("ü", "ue");
            cString = cString.Replace("ý", "y");
            cString = cString.Replace("þ", "p");
            cString = cString.Replace("ÿ", "y");
            cString = cString.Replace("–", " ");
            cString = cString.Replace("“", "\"");
            cString = cString.Replace("”", "\"");
            cString = cString.Replace("’", "\'");
            cString = cString.Replace("’", "");
            return cString;
        }
        public string ReplaceHtmlSpecialCharacters(string cString)
        {
            cString = cString.Replace("&#65;", "A");
            cString = cString.Replace("&#66;", "B");
            cString = cString.Replace("&#67;", "C");
            cString = cString.Replace("&#68;", "D");
            cString = cString.Replace("&#69;", "E");
            cString = cString.Replace("&#70;", "F");
            cString = cString.Replace("&#71;", "G");
            cString = cString.Replace("&#72;", "H");
            cString = cString.Replace("&#73;", "I");
            cString = cString.Replace("&#74;", "J");
            cString = cString.Replace("&#75;", "K");
            cString = cString.Replace("&#76;", "L");
            cString = cString.Replace("&#77;", "M");
            cString = cString.Replace("&#78;", "N");
            cString = cString.Replace("&#79;", "O");
            cString = cString.Replace("&#80;", "P");
            cString = cString.Replace("&#81;", "Q");
            cString = cString.Replace("&#82;", "R");
            cString = cString.Replace("&#83;", "S");
            cString = cString.Replace("&#84;", "T");
            cString = cString.Replace("&#85;", "U");
            cString = cString.Replace("&#86;", "V");
            cString = cString.Replace("&#87;", "W");
            cString = cString.Replace("&#88;", "X");
            cString = cString.Replace("&#89;", "Y");
            cString = cString.Replace("&#90;", "Z");
            cString = cString.Replace("&#91;", "[");
            cString = cString.Replace("&#92;", "\\");
            cString = cString.Replace("&#93;", "]");
            cString = cString.Replace("&#94;", "^");
            cString = cString.Replace("&#95;", " ");

            cString = cString.Replace("&#97;", "a");

            cString = cString.Replace("&#98;", "b");
            cString = cString.Replace("&#99;", "c");
            cString = cString.Replace("&#100;", "d");
            cString = cString.Replace("&#101;", "e");
            cString = cString.Replace("&#102;", "f");
            cString = cString.Replace("&#103;", "g");
            cString = cString.Replace("&#104;", "h");
            cString = cString.Replace("&#105;", "i");
            cString = cString.Replace("&#106;", "j");
            cString = cString.Replace("&#107;", "k");
            cString = cString.Replace("&#108;", "l");
            cString = cString.Replace("&#109;", "m");
            cString = cString.Replace("&#110;", "n");
            cString = cString.Replace("&#111;", "o");
            cString = cString.Replace("&#112;", "p");
            cString = cString.Replace("&#113;", "q");
            cString = cString.Replace("&#114;", "r");
            cString = cString.Replace("&#115;", "s");
            cString = cString.Replace("&#116;", "t");
            cString = cString.Replace("&#117;", "u");
            cString = cString.Replace("&#118;", "v");
            cString = cString.Replace("&#119;", "w");
            cString = cString.Replace("&#120;", "x");
            cString = cString.Replace("&#121;", "y");
            cString = cString.Replace("&#122;", "z");
            cString = cString.Replace("&#123;", "{");
            cString = cString.Replace("&#124;", "|");
            cString = cString.Replace("&#125;", "}");
            cString = cString.Replace("&#126;", "~");

            cString = cString.Replace("&#09;", "' '");
            cString = cString.Replace("&#10;", "' '");
            cString = cString.Replace("&#13;", "' '");

            cString = cString.Replace("&#32;", "' '");
            cString = cString.Replace("&#33;", "!");
            cString = cString.Replace("&#34;", "\"");
            cString = cString.Replace("&#35;", "#");
            cString = cString.Replace("&#36;", "$");
            cString = cString.Replace("&#37;", "%");
            cString = cString.Replace("&#38;", "&");
            cString = cString.Replace("&#39;", "'");
            cString = cString.Replace("&#40;", "(");
            cString = cString.Replace("&#41;", ")");
            cString = cString.Replace("&#42;", "*");
            cString = cString.Replace("&#43;", "+");
            cString = cString.Replace("&#44;", ",");
            cString = cString.Replace("&#45;", "-");
            cString = cString.Replace("&#46;", ".");
            cString = cString.Replace("&#47;", "/");
            cString = cString.Replace("&#48;", "0");
            cString = cString.Replace("&#49;", "1");
            cString = cString.Replace("&#50;", "2");
            cString = cString.Replace("&#51;", "3");
            cString = cString.Replace("&#53;", "4");
            cString = cString.Replace("&#53;", "5");
            cString = cString.Replace("&#54;", "6");
            cString = cString.Replace("&#55;", "7");
            cString = cString.Replace("&#56;", "8");
            cString = cString.Replace("&#57;", "9");
            cString = cString.Replace("&#58;", ":");
            cString = cString.Replace("&#59;", ";");
            cString = cString.Replace("&#60;", "<");
            cString = cString.Replace("&#61;", "=");
            cString = cString.Replace("&#62;", ">");
            cString = cString.Replace("&#63;", "?");
            cString = cString.Replace("&#64;", "@");
            cString = cString.Replace("&#8211;", "–");
            cString = cString.Replace("&#8212;", "—");
            cString = cString.Replace("&#161;", "¡");
            cString = cString.Replace("&#191;", "¿");
            cString = cString.Replace("&#34;", "\"");
            cString = cString.Replace("&#8220;", "“");
            cString = cString.Replace("&#8221;", "”");
            cString = cString.Replace("&#39;", "'");
            cString = cString.Replace("&#8216;", "‘");
            cString = cString.Replace("&#8217;", "’");
            cString = cString.Replace("&#171;", "«");
            cString = cString.Replace("&#187;", "»");
            cString = cString.Replace("&#160;", "  ");
            cString = cString.Replace("&#38;", "&");
            cString = cString.Replace("&#162;", "¢");
            cString = cString.Replace("&#169;", "©");
            cString = cString.Replace("&#247;", "÷");
            cString = cString.Replace("&#62;", ">");
            cString = cString.Replace("&#60;", "<");
            cString = cString.Replace("&#181;", "µ");
            cString = cString.Replace("&#183;", "·");
            cString = cString.Replace("&#182;", "¶");
            cString = cString.Replace("&#177;", "±");
            cString = cString.Replace("&#8364;", "€");
            cString = cString.Replace("&#163;", "£");
            cString = cString.Replace("&#174;", "®");
            cString = cString.Replace("&#167;", "§");
            cString = cString.Replace("&#153;", "™");
            cString = cString.Replace("&#165;", "¥");
            cString = cString.Replace("&#176;", "°");
            cString = cString.Replace("&#225;", "á");
            cString = cString.Replace("&#193;", "Á");
            cString = cString.Replace("&#224;", "à");
            cString = cString.Replace("&#192;", "À");
            cString = cString.Replace("&#226;", "â");
            cString = cString.Replace("&#194;", "Â");
            cString = cString.Replace("&#229;", "å");
            cString = cString.Replace("&#197;", "Å");
            cString = cString.Replace("&#227;", "ã");
            cString = cString.Replace("&#195;", "Ã");
            cString = cString.Replace("&#228;", "ä");
            cString = cString.Replace("&#196;", "Ä");
            cString = cString.Replace("&#230;", "æ");
            cString = cString.Replace("&#198;", "Æ");
            cString = cString.Replace("&#231;", "ç");
            cString = cString.Replace("&#199;", "Ç");
            cString = cString.Replace("&#233;", "é");
            cString = cString.Replace("&#201;", "É");
            cString = cString.Replace("&#232;", "è");
            cString = cString.Replace("&#200;", "È");
            cString = cString.Replace("&#234;", "ê");
            cString = cString.Replace("&#202;", "Ê");
            cString = cString.Replace("&#235;", "ë");
            cString = cString.Replace("&#203;", "Ë");
            cString = cString.Replace("&#237;", "í");
            cString = cString.Replace("&#205;", "Í");
            cString = cString.Replace("&#236;", "ì");
            cString = cString.Replace("&#204;", "Ì");
            cString = cString.Replace("&#238;", "î");
            cString = cString.Replace("&#206;", "Î");
            cString = cString.Replace("&#239;", "ï");
            cString = cString.Replace("&#207;", "Ï");
            cString = cString.Replace("&#241;", "ñ");
            cString = cString.Replace("&#209;", "Ñ");
            cString = cString.Replace("&#243;", "ó");
            cString = cString.Replace("&#211;", "Ó");
            cString = cString.Replace("&#242;", "ò");
            cString = cString.Replace("&#210;", "Ò");
            cString = cString.Replace("&#244;", "ô");
            cString = cString.Replace("&#212;", "Ô");
            cString = cString.Replace("&#248;", "ø");
            cString = cString.Replace("&#216;", "Ø");
            cString = cString.Replace("&#245;", "õ");
            cString = cString.Replace("&#213;", "Õ");
            cString = cString.Replace("&#246;", "ö");
            cString = cString.Replace("&#214;", "Ö");
            cString = cString.Replace("&#223;", "ß");
            cString = cString.Replace("&#250;", "ú");
            cString = cString.Replace("&#218;", "Ú");
            cString = cString.Replace("&#249;", "ù");
            cString = cString.Replace("&#217;", "Ù");
            cString = cString.Replace("&#251;", "û");
            cString = cString.Replace("&#219;", "Û");
            cString = cString.Replace("&#252;", "ü");
            cString = cString.Replace("&#220;", "Ü");
            cString = cString.Replace("&#255;", "ÿ");
            cString = cString.Replace("&#180;", "´");
            cString = cString.Replace("&#96;", "`");


            cString = cString.Replace("&#8211;", "–");
            cString = cString.Replace("&#8212;", "—");
            cString = cString.Replace("&#161;", "¡");
            cString = cString.Replace("&#191;", "¿");
            cString = cString.Replace("&#34;", "\"");
            cString = cString.Replace("&#8220;", "“");
            cString = cString.Replace("&#8221;", "”");
            cString = cString.Replace("&#39;", "'");
            cString = cString.Replace("&#8216;", "‘");
            cString = cString.Replace("&#8217;", "’");
            cString = cString.Replace("&#171;", "«");
            cString = cString.Replace("&#187;", "»");
            cString = cString.Replace("&#160;", "  ");
            cString = cString.Replace("&#38;", "&");
            cString = cString.Replace("&#162;", "¢");
            cString = cString.Replace("&#169;", "©");
            cString = cString.Replace("&#247;", "÷");
            cString = cString.Replace("&#62;", ">");
            cString = cString.Replace("&#60;", "<");
            cString = cString.Replace("&#181;", "µ");
            cString = cString.Replace("&#183;", "·");
            cString = cString.Replace("&#182;", "¶");
            cString = cString.Replace("&#177;", "±");
            cString = cString.Replace("&#8364;", "€");
            cString = cString.Replace("&#163;", "£");
            cString = cString.Replace("&#174;", "®");
            cString = cString.Replace("&#167;", "§");
            cString = cString.Replace("&#153;", "™");
            cString = cString.Replace("&#165;", "¥");
            cString = cString.Replace("&#176;", "°");
            cString = cString.Replace("&#225;", "á");
            cString = cString.Replace("&#193;", "Á");
            cString = cString.Replace("&#224;", "à");
            cString = cString.Replace("&#192;", "À");
            cString = cString.Replace("&#226;", "â");
            cString = cString.Replace("&#194;", "Â");
            cString = cString.Replace("&#229;", "å");
            cString = cString.Replace("&#197;", "Å");
            cString = cString.Replace("&#227;", "ã");
            cString = cString.Replace("&#195;", "Ã");
            cString = cString.Replace("&#228;", "ä");
            cString = cString.Replace("&#196;", "Ä");
            cString = cString.Replace("&#230;", "æ");
            cString = cString.Replace("&#198;", "Æ");
            cString = cString.Replace("&#231;", "ç");
            cString = cString.Replace("&#199;", "Ç");
            cString = cString.Replace("&#233;", "é");
            cString = cString.Replace("&#201;", "É");
            cString = cString.Replace("&#232;", "è");
            cString = cString.Replace("&#200;", "È");
            cString = cString.Replace("&#234;", "ê");
            cString = cString.Replace("&#202;", "Ê");
            cString = cString.Replace("&#235;", "ë");
            cString = cString.Replace("&#203;", "Ë");
            cString = cString.Replace("&#237;", "í");
            cString = cString.Replace("&#205;", "Í");
            cString = cString.Replace("&#236;", "ì");
            cString = cString.Replace("&#204;", "Ì");
            cString = cString.Replace("&#238;", "î");
            cString = cString.Replace("&#206;", "Î");
            cString = cString.Replace("&#239;", "ï");
            cString = cString.Replace("&#207;", "Ï");
            cString = cString.Replace("&#241;", "ñ");
            cString = cString.Replace("&#209;", "Ñ");
            cString = cString.Replace("&#243;", "ó");
            cString = cString.Replace("&#211;", "Ó");
            cString = cString.Replace("&#242;", "ò");
            cString = cString.Replace("&#210;", "Ò");
            cString = cString.Replace("&#244;", "ô");
            cString = cString.Replace("&#212;", "Ô");
            cString = cString.Replace("&#248;", "ø");
            cString = cString.Replace("&#216;", "Ø");
            cString = cString.Replace("&#245;", "õ");
            cString = cString.Replace("&#213;", "Õ");
            cString = cString.Replace("&#246;", "ö");
            cString = cString.Replace("&#214;", "Ö");
            cString = cString.Replace("&#223;", "ß");
            cString = cString.Replace("&#250;", "ú");
            cString = cString.Replace("&#218;", "Ú");
            cString = cString.Replace("&#249;", "ù");
            cString = cString.Replace("&#217;", "Ù");
            cString = cString.Replace("&#251;", "û");
            cString = cString.Replace("&#219;", "Û");
            cString = cString.Replace("&#252;", "ü");
            cString = cString.Replace("&#220;", "Ü");
            cString = cString.Replace("&#255;", "ÿ");
            cString = cString.Replace("&#180;", "´");
            cString = cString.Replace("&#96;", "`");
            return cString;
        }
    }
}
