﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Configuration;

namespace qp.com.qa
{
    public partial class Form1 : Form
    {
        //CancelEventHandler webBrowser1NewWindow = null;
        ScrapClass.Class1 MainClass = new ScrapClass.Class1();
        HtmlDocument theDoc = null;
        string Step = ""; string MyUrl = ""; string lastpage = string.Empty; string maindata = string.Empty;
        int MyReturnCode = 0; int a = 0; int pno = 2; int b = 0; int t = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dateTimePicker1From.Text = DateTime.Today.AddDays(-1).ToString();
            dateTimePicker2To.Text = DateTime.Today.AddDays(0).ToString();
            radioButton1live.Checked = true;
            webBrowser1.ScriptErrorsSuppressed = true;
            webBrowser1.StatusTextChanged += new EventHandler(webBrowser1_StatusTextChanged);
        }

        private void button2go_Click(object sender, EventArgs e)
        {//http://www.ashghal.gov.qa/en/Tenders/pages/erPTenders.aspx
            webBrowser1.Navigate("http://www.ashghal.gov.qa/en/Tenders/pages/erPTenders.aspx");
            panel1.Enabled = false;
            timer1.Enabled = true;
        }

        private void button1exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (t >= 100)
            {
                t = 0;
                timer1.Enabled = false;
                if (theDoc != null)
                    if (theDoc.Body != null)
                    {
                        if (theDoc.Body.InnerHtml.Contains("Open e-Tenders"))
                        {
                            label1pno.Visible = true;
                            label1pno.Text = "PageNo : " + 1;
                            CollectLinks();
                        }
                        else
                        {
                            timer1.Enabled = true;
                        }
                    }
                    else
                    {
                        timer1.Enabled = true;
                    }
            }
            else
            {
                t++;
                label1timer.Visible = true;
                label1timer.Text = t + "% Loading...";
                label1timer.Refresh();
            }
        }

        private void radioButton1live_CheckedChanged(object sender, EventArgs e)
        {
            //var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            //var connectionStringsSection = (ConnectionStringsSection)config.GetSection("ConnectionString");
            //string ConnectionString1 = ConfigurationManager.ConnectionStrings["Testing_ConnectionString"].ConnectionString;
            //config.Save();
            //ConfigurationManager.RefreshSection("ConnectionString");
            //GlobalLevel.Global.flagServer = true;
            //GlobalLevel.Global.server = "Live";
            //this.Text = "ashghal.gov.qa [Live Server Selected]";
            //label5server.Text = "Live Server Selected";
            //label5server.Refresh();
        }

        private void radioButton2test_CheckedChanged(object sender, EventArgs e)
        {
            var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var connectionStringsSection = (ConnectionStringsSection)config.GetSection("ConnectionString");
            string ConnectionString1 = ConfigurationManager.ConnectionStrings["Testing_ConnectionString"].ConnectionString;
            config.Save();
            ConfigurationManager.RefreshSection("ConnectionString");
            GlobalLevel.Global.flagServer = false;
            GlobalLevel.Global.server = "Test";
            this.Text = "ashghal.gov.qa [Test Server Selected]";
            label5server.Text = "Test Server Selected";
            label5server.Refresh();
        }

        public void NextButton1()
        {
            try
            {
                //    if (pno == 2)
                //    {
                //        lastpage = theDoc.Body.InnerHtml;
                //        lastpage = MainClass.GetRqdStr(lastpage, "<SPAN id=Nextpg", "<IMG", "", "");
                //        lastpage = lastpage.Replace("amp;", "");
                //        lastpage = MainClass.GetRqdStr(lastpage, "&ymns=", "&", "", "");
                //        if (lastpage == "")
                //        {
                //            lastpage = theDoc.Body.InnerHtml;
                //            lastpage = MainClass.GetRqdStr(lastpage, "<DIV class=paginationLinks>", "</A><A class=pg_next", "", "");
                //            while (lastpage.Contains(">"))
                //            {
                //                lastpage = lastpage.Substring(lastpage.IndexOf(">") + 01);
                //            }
                //        }
                //        if (lastpage == "")
                //        {
                //            MessageBox.Show("url variable are empty..!!Please give it for maintenance..\n\nPossible error will HTML tags changed", "ashghal.gov.qa");
                //            Application.Exit();
                //        }
                //    }
                //    else
                //    {

                //    }

                //int a = pno - 1;
                //if (lastpage != a.ToString())
                //{
                //    string dd = theDoc.Body.InnerHtml;
                //    dd = MainClass.GetRqdStr(dd, "" + (pno - 1) + "</A><A class=page", "</", "", "");
                //    dd = dd.Replace("amp;", "");
                //    dd = MainClass.GetRqdStr(dd, "href=\"", "\">", "", "");
                //    if (!dd.Contains("https://www.tenderwizard.com"))
                //    {
                //        dd = "https://www.tenderwizard.com" + dd;
                //    }
                //    string url = dd;
                //    webBrowser1.Navigate(url);
                //    label1pno.Text = "PageNo : " + pno;
                //    label1pno.Refresh();
                //}
                //else
                {
                    timer1.Enabled = false;
                    Step = "Step_3";
                    webBrowser1.Navigate(GlobalLevel.Global.Doc_Links[b]);
                }
            }
            catch
            {
                //objcls.GlUrlIndex = 1;
            }
            pno++;
        }
        public void NextButton2()
        {
            try
            {
                if (theDoc.Body != null)
                {
                    label1timer.Visible = false;
                    Step = "Step_2";
                    if (theDoc.Body.InnerHtml.Contains("\">Tender Freeview</A>"))
                    {
                        string data = theDoc.Body.InnerHtml;
                        data = data.Remove(data.IndexOf("\">Tender Freeview</A>"));
                        while (data.Contains("<A href=\""))
                        {
                            data = data.Substring(data.IndexOf("<A href=\"") + 09);
                        }
                        data = "http://www.tenderwizard.com" + data;
                        webBrowser1.Navigate(data);
                        timer1.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Tender navigation link dosn't find..!!Please give it for maintenance", "ashghal.gov.qa", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        Application.Exit();
                    }
                }
                else
                {
                    t = 0;
                    timer1.Enabled = true;
                }
            }
            catch
            {
                MessageBox.Show("Tender navigation link dosn't find..!!Please give it for maintenance\n\rError in ShowNextPage() Method.", "ashghal.gov.qa", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Application.Exit();
            }
        }
        public void Search()
        {
            HtmlElement OurElement = null;

            try
            {
                OurElement = theDoc.GetElementById("publishDateFrom");
                OurElement.OuterHtml = "<INPUT value=" + GlobalLevel.Global.Fromdate + " id=publishDateFrom class=\"input-sm form-control byRange\" title=\"Zeitraum Veröffentlichung Start\" tabIndex=2500 name=publishDateGroup:publishDateGroup_body:publishDateFrom jQuery111208789504241302466=\"43\" placeholder=\"TT.MM.JJJJ\" wicketFocusSet=\"true\">";

                OurElement = theDoc.GetElementById("publishDateTo");
                OurElement.OuterHtml = "<INPUT value=" + GlobalLevel.Global.Todate + " id=publishDateTo class=\"input-sm form-control byRange\" title=\"Zeitraum Veröffentlichung Ende\" tabIndex=2600 name=publishDateGroup:publishDateGroup_body:publishDateTo jQuery111208789504241302466=\"44\" placeholder=\"TT.MM.JJJJ\" wicketFocusSet=\"true\">";

                OurElement = theDoc.GetElementById("id18");
                OurElement.InvokeMember("click");
                Application.DoEvents();
            }
            catch
            {
                MessageBox.Show("Problem in search method..!!!");
            }

            webBrowser1.Document.GetElementById("eprocTenders:tenderCreateDateFrom").SetAttribute("value", dateTimePicker1From.Text);
            webBrowser1.Document.GetElementById("eprocTenders:tenderCreateDateTo").SetAttribute("value", dateTimePicker2To.Text);
            webBrowser1.Document.GetElementById("eprocTenders:butSearch").InvokeMember("click");
        }
        public void EnglishLang()
        {
            HtmlElementCollection OurElement = null;
            OurElement = theDoc.GetElementsByTagName("A");
            foreach (HtmlElement ele in OurElement)
            {
                if (ele.OuterHtml.Contains("\">English"))
                {
                    ele.InvokeMember("click");
                    Application.DoEvents();
                    break;
                }
            }
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (webBrowser1.ReadyState == WebBrowserReadyState.Complete)
            {
                theDoc = webBrowser1.Document;
                string MyDocType = webBrowser1.DocumentType.ToString();
                if (theDoc.Body.InnerText != null)
                    if (theDoc.Body.InnerText.Contains("Navigation to the webpage was canceled") || theDoc.Body.InnerText.Contains("This program cannot display the webpage"))
                    {
                        MessageBox.Show(new Form() { TopMost = true }, "Network Connection Failed.\r\n    OR\r\nNavigation to the webpage was canceled!!", "Network Problem!!", MessageBoxButtons.OK, MessageBoxIcon.None);
                        //webBrowser1.Refresh();
                        try
                        {
                            a--;
                            webBrowser1.Navigate(GlobalLevel.Global.Doc_Links[a]);
                            a++;
                        }
                        catch (Exception ex)
                        {

                        }
                        Step = "Step_3";
                    }
                    else
                    {
                        if (theDoc.Body.InnerText.Contains("This tender is a limited tender, you should login as an eligible company to view it"))
                        {

                            try
                            {
                                a++;
                                webBrowser1.Navigate(GlobalLevel.Global.Doc_Links[a]);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error in CollectData() method\n\nError are : " + ex, "ashghal.gov.qa");
                            }
                            Step = "Step_3";



                            //MessageBox.Show("Your session has expired!!!\n\r\n\rPlease OK to Restart EXE", "ashghal.gov.qa");
                            //webBrowser1.Navigate("http://www.tenderwizard.com/ROOTAPP/tender.jsp?Identity=CPWD&message=none");
                            //t = 0;
                            //timer1.Enabled = true;
                            //Step = "Step_1";
                            //pno = 2;
                            //GlobalLevel.Global.Doc_Links.Clear();
                        }
                        else
                        {
                            switch (Step)
                            {
                                case "Step_1":
                                    webBrowser1.Navigate("http://www.ashghal.gov.qa/en/Tenders/pages/erPTenders.aspx");
                                    // timer1.Enabled = true;
                                    Step = "Step_Link";
                                    break;
                                case "Step_Link":
                                    webBrowser1.Navigate("http://www.ashghal.gov.qa/en/Tenders/pages/erPTenders.aspx");
                                    Step = "Step_2";
                                    break;
                                case "Step_2":
                                    CollectLinks();
                                    break;

                                case "Step_3":
                                    CollectData();
                                    break;

                                case "Step_4":
                                    break;

                                case "Step_5":
                                    break;
                            }
                        }
                    }
            }
            else
            {
                Application.DoEvents();
            }
        }

        private void webBrowser1_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {

        }

        private void webBrowser1_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            txtUrlName.Text = e.Url.ToString();
            MyUrl = txtUrlName.Text;
        }

        private void webBrowser1_NewWindow(object sender, CancelEventArgs e)
        {
            e.Cancel = true;
        }

        private void webBrowser1_ProgressChanged(object sender, WebBrowserProgressChangedEventArgs e)
        {
            try
            {
                toolStripProgressBar1.Maximum = (int)e.MaximumProgress;
                toolStripProgressBar1.Value = (int)e.CurrentProgress;
            }
            catch (Exception ex)
            { }
        }

        private void webBrowser1_StatusTextChanged(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = webBrowser1.StatusText;
        }

        private void statusStrip1_TextChanged(object sender, EventArgs e)
        {
            //StatusLabel1.Text = statusStrip1.Text;//for extra label
            //StatusLabel1.Invalidate();
            //Application.DoEvents();
        }

        private void CollectLinks()
        {
            try
            {
                maindata = theDoc.Body.InnerHtml;
                maindata = theDoc.GetElementById("ctl00_ctl52_g_8baa5526_2e1e_41e3_9ed1_3c8844ba59dc_ctl00_OpenTenderGrid_grdOpenTenders").InnerHtml.ToString();

                
                if (maindata == "")
                {
                    MessageBox.Show("maindata variable are empty..!!Please give it for maintenance..\n\nPossible error will HTML tags changed", "ashghal.gov.qa");
                    Application.Exit();
                }
                maindata = MainClass.ReplaceSpecialCharacters(maindata);
                maindata = MainClass.ReplaceHtmlSpecialCharacters(maindata);

                maindata = maindata.Replace("href=", "¥href=");
                String[] Data = maindata.Split('¥');
                int rowlength = Data.Length - 1;
                {
                    try
                    {
                        for (int i = 1; i <= rowlength; i++)
                        {
                            string Links = string.Empty;
                            string tno = string.Empty;
                            string lno = string.Empty;
                            {
                                Links = Data[i];
                                if (Links.Contains("en/Tenders/Pages"))
                                {
                                    try
                                    {
                                        tno = Data[i];
                                        //tno = tno.Substring(tno.IndexOf("<INPUT id=sm_tenderNumber"));
                                        tno = tno.Remove(tno.IndexOf("\">"));
                                        tno = System.Text.RegularExpressions.Regex.Replace(tno, @"<[^>]*>", String.Empty).Trim();

                                        //lno = Data[i];
                                        //lno = lno.Substring(lno.IndexOf("<INPUT id=sm_lineNumber"));
                                        //lno = lno.Remove(lno.IndexOf("</TD>"));
                                        //lno = System.Text.RegularExpressions.Regex.Replace(lno, @"<[^>]*>", String.Empty).Trim();
                                        tno = tno.Replace("href=\"/en", "http://www.ashghal.gov.qa/en");
                                        //Links = "https://www.tenderwizard.com/ROOTAPP/servlet/venderdisplayservlet?buyername=Central%20Public%20Works%20Department&tendernumber=" + tno + "&linenumber=" + lno + "&modify=modnew1";
                                        GlobalLevel.Global.Doc_Links.Add(tno);
                                        label2linkcoll.Visible = true;
                                        label2linkcoll.Text = "Links Collected : " + GlobalLevel.Global.Doc_Links.Count.ToString();
                                        label2linkcoll.Refresh();
                                    }
                                    catch
                                    { }
                                }
                            }
                        }
                    }
                    catch (Exception ea)
                    {
                        MessageBox.Show("Error in GetDataLinks() Method../n/nGive it for Maintenance.../n/n" + ea.Message, "ashghal.gov.qa");
                        Application.Exit();
                    }
                }
                label2linkcoll.Visible = true;
                label2linkcoll.Text = "Links Collected : " + GlobalLevel.Global.Doc_Links.Count.ToString();
                label2linkcoll.Refresh();
                NextButton1();
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error in GetDataLinks() method...Give it for maintenance \n\n" + ee.Message, "ashghal.gov.qa");
                Application.Exit();
            }
        }
        private void CollectData()
        {
            if (a < GlobalLevel.Global.Doc_Links.Count - 1)
            {
                a++;
                label3datacoll.Visible = true;
                label3datacoll.Text = "Data Collected : " + a;
                label3datacoll.Refresh();
                string maindata = webBrowser1.DocumentText;
                maindata = maindata.Substring(maindata.IndexOf("<div id=\"TenderPrintableArea\">"));
                maindata = maindata.Remove(maindata.IndexOf("<div class=\"btns-container BTNsContainer CompanyBtn\">") + "<div class=\"btns-container BTNsContainer CompanyBtn\">".Length);
                maindata = maindata.Replace("&quot;", "\"");

                try
                {
                    String Link = maindata.ToString();
                    HtmlElement ele = theDoc.GetElementById("ctl00_ctl52_g_87cf3a90_4938_4bf7_988e_33dc84ba7c5d_ctl00_TenderDetailsUserControl_ERPSiteLink");
                    string val1 = ele.GetAttribute("href");
                    val1 = val1.Replace("&quot;", "\"");
                    string val2 = "<a href=\"" + val1 + "\">View the project brief</a>";
                    //string temp = maindata.Substring(maindata.IndexOf("<a id=\"ctl00_ctl34_g_245cdd2d_d20e_43e6_8d10_1c8c5fb581cb_ctl00_TenderDetailsUserControl_lnkBriefDocument"));
                    //temp = temp.Remove(temp.IndexOf("</a>") + "</a>".Length);
                    
                }
                catch (Exception edx)
                {

                }


                GlobalLevel.Global.Doc_Data.Add(maindata);
                try
                {
                    webBrowser1.Navigate(GlobalLevel.Global.Doc_Links[a]);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error in CollectData() method\n\nError are : " + ex, "ashghal.gov.qa");
                }
                Step = "Step_3";
            }
            else
            {
                Step = "Step_4";
                a++;
                label3datacoll.Visible = true;
                label3datacoll.Text = "Data Collected : " + a;
                label3datacoll.Refresh();
                string maindata = webBrowser1.DocumentText;
                maindata = maindata.Substring(maindata.IndexOf("<div id=\"TenderPrintableArea\">"));
                maindata = maindata.Remove(maindata.IndexOf("<div class=\"btns-container BTNsContainer CompanyBtn\">") + "<div class=\"btns-container BTNsContainer CompanyBtn\">".Length);
                maindata = maindata.Replace("&quot;", "\"");

                try
                {
                    String Link = maindata.ToString();
                    HtmlElement ele = theDoc.GetElementById("ctl00_ctl34_g_245cdd2d_d20e_43e6_8d10_1c8c5fb581cb_ctl00_TenderDetailsUserControl_lnkBriefDocument");
                    if (ele == null)
                    {
                        ele = theDoc.GetElementById("TenderPrintableArea");
                    }
                    string val1 = "";
                    try
                    {
                        val1 = ele.OuterHtml.ToString();
                        string val2 = val1.Substring(val1.IndexOf("true, \"\", \"/") + "true, \"\", \"/".Length);
                        val2 = val2.Remove(val2.IndexOf("\","));
                        val2 = val2.Replace("en/Tenders", "http://www.ashghal.gov.qa/en/Tenders");
                        val2 = val2.Replace("%2520", "%20");
                        val2 = "<a href=\"" + val2 + "\">View the project brief</a>";
                        //string temp = maindata.Substring(maindata.IndexOf("<a id=\"ctl00_ctl34_g_245cdd2d_d20e_43e6_8d10_1c8c5fb581cb_ctl00_TenderDetailsUserControl_lnkBriefDocument"));
                        //temp = temp.Remove(temp.IndexOf("</a>") + "</a>".Length);
                        //maindata = maindata.Replace(temp, val2);
                    }
                    catch (Exception ex)
                    {

                        try
                        {
                            HtmlElement ele1 = theDoc.GetElementById("ctl00_ctl34_g_245cdd2d_d20e_43e6_8d10_1c8c5fb581cb_ctl00_pnlTenderViews");
                            val1 = ele1.OuterHtml.ToString();
                            maindata = val1;
                            HtmlElementCollection elem = theDoc.GetElementsByTagName("a");
                            foreach (HtmlElement el in elem)
                            {
                                if (el.OuterHtml != null)
                                {
                                    if (el.OuterHtml.Contains("Print</A>"))
                                    {
                                        maindata = maindata.Replace(el.OuterHtml.ToString(), "");
                                    }
                                    if (el.OuterHtml.Contains("Email </A>"))
                                    {
                                        maindata = maindata.Replace(el.OuterHtml.ToString(), "");
                                    }
                                    if (el.OuterHtml.Contains("Back to Tenders"))
                                    {
                                        maindata = maindata.Replace(el.OuterHtml.ToString(), "");
                                    }
                                }

                            }
                        }
                        catch (Exception ex1)
                        { }

                    }

                }
                catch (Exception edx)
                {

                }
                try
                {
                    string val1 = maindata;
                    string val2 = maindata.Substring(maindata.IndexOf("<SPAN class=btn-scnd-crv>") + "<SPAN class=btn-scnd-crv>".Length);
                    val2 = val2.Remove(val2.IndexOf("</SPAN>"));

                    maindata = maindata.Replace(val2, "");

                }
                catch (Exception ex)
                { }

                maindata = maindata.Replace("<INPUT name=ctl00$ctl34$g_245cdd2d_d20e_43e6_8d10_1c8c5fb581cb$ctl00$TenderDetailsUserControl$btnBack class=btn id=ctl00_ctl34_g_245cdd2d_d20e_43e6_8d10_1c8c5fb581cb_ctl00_TenderDetailsUserControl_btnBack onclick='javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(\"ctl00$ctl34$g_245cdd2d_d20e_43e6_8d10_1c8c5fb581cb$ctl00$TenderDetailsUserControl$btnBack\", \"\", true, \"\", \"\", false, false))' type=submit value=\"Back to Tenders &amp; Auctions\">", "");
                GlobalLevel.Global.Doc_Data.Add(maindata);
                GetData();
            }
        }
        private void GetData()
        {
            int bb = 1;
            for (int b = 0; b <= GlobalLevel.Global.Doc_Data.Count - 1; b++)
            {
                try
                {
                    string data = GlobalLevel.Global.Doc_Data[b];
                    GlobalLevel.Global.DocPath = GlobalLevel.Global.Doc_Links[b];
                    GlobalLevel.Global.DataHtmlDoc = data;
                    if (data != "")
                    {
                        MyReturnCode = MainClass.SegDoc(GlobalLevel.Global.DataHtmlDoc, GlobalLevel.Global.DocPath);
                        label4datainserted.Visible = true;
                        label4datainserted.Text = "Insertion Completed : " + bb;
                        label4datainserted.Refresh();
                        bb++;
                    }
                    else
                    {

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error in GetData() method\n\nError are : " + ex, "ashghal.gov.qa");
                }
            }
            MessageBox.Show("All Data Inserted Successfully....!!\n\nTotal Data : " + GlobalLevel.Global.Doc_Links.Count + "\n\nTotal Inserted : " + GlobalLevel.Global.inserted + "\n\nDuplicate Data : " + GlobalLevel.Global.duplicate + "\n\nExpired Data : " + GlobalLevel.Global.expired, "ashghal.gov.qa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Application.Exit();
            Environment.Exit(0);
        }
    }
}
