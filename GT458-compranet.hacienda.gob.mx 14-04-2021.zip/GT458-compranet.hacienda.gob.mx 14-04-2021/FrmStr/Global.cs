﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETGB
{
    class Global
    {
        internal static string Conserver = "";
        internal static string DateFrm = "";
        internal static int Inserted = 0;
        internal static int Duplicate = 0;
        internal static int Skipped = 0;

        internal static List<string> Doc_Links = new List<string>();
        internal static List<string> SubmitterLinks = new List<string>();

        internal static List<string> TransFields = new List<string>();
        internal static bool Translated = false;
        internal static int traslation_type = 1;
    }
}
