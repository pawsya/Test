﻿using ETGB;
using System;
using System.Windows.Forms;

namespace monafasatBing
{
    public partial class Bingtranslate : Form
    {
        

        HtmlDocument theDoc = null;
        int timer = 0;
        string data = string.Empty;

        public Bingtranslate()
        {
            InitializeComponent();
        }

        private void Bingtranslate_Load(object sender, EventArgs e)
        {
            
            webBrowser1.Navigate("https://www.bing.com/search?q=bing+translation&FORM=AWRE");
            timer1.Enabled = true;


            data = " ♠♠♠ " + Global.TransFields[1];//Purchaser
            data = data + " ♣♣♣ " + Global.TransFields[2];//shortdesc
            data = data + " ♥♥♥ " + Global.TransFields[3];//tender details
            //data = data + " ♦♦♦ " + Global.TransFields[4];
            //data = data + " ♠♠♠ " + Global.TransFields[5];

        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            if (webBrowser1.ReadyState == WebBrowserReadyState.Complete)
            {
                
                webBrowser1.Document.GetElementById("tta_tgtsl").SetAttribute("value", "en");
                webBrowser1.Document.GetElementById("tta_input_ta").SetAttribute("value", data);
                timer1.Enabled = true;

            }
        }

        private void webBrowser1_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {

        }

        private void webBrowser1_ProgressChanged(object sender, WebBrowserProgressChangedEventArgs e)
        {
            try
            {
                progressBar1.Maximum = (int)e.MaximumProgress;
                progressBar1.Value = (int)e.CurrentProgress;
            }
            catch (Exception)
            { }
        }



        public void GetTranslate(string url, string ToTran, string Translated)
        {
            //Totra = ToTran;
            //webBrowser1.Navigate(url);
            //timer1.Enabled = true;

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            
            if (timer >= 50)
            {
                theDoc = webBrowser1.Document;
                timer = 0;
                timer1.Enabled = false;
                if (theDoc != null)
                {
                    // HtmlElement el = theDoc.GetElementById("t_tv");
                    HtmlElement el = theDoc.GetElementById("tta_output_ta");
                    if (theDoc.Body != null)
                    {
                        if (el.InnerHtml.Length < 10 && (!el.InnerHtml.Contains("~")))
                        {
                            if (theDoc.Body.InnerHtml.Contains("something went wrong"))
                            {
                                MessageBox.Show("something went wrong!! ");
                                timer1.Enabled = false;
                                int lenth = Global.TransFields[2].Length;
                                Global.TransFields[2] = Global.TransFields[2].Remove(lenth / 2);
                                webBrowser1.Navigate("https://www.bing.com/search?q=bing+translation&FORM=AWRE");
                            }
                            if (el.InnerHtml.Contains("..."))
                            {
                                timer1.Enabled = true;

                            }
                        }
                        else if (el.InnerHtml != "" && (!el.InnerHtml.Contains("Translation")))
                        {
                            try
                            {
                                //string data = "¢" + GlobalLevel.Global.TransFields[1];//Purchaser
                                //data = data + "£" + GlobalLevel.Global.TransFields[2];//shortdesc
                                //data = data + "¤" + GlobalLevel.Global.TransFields[3];//tender details
                                //data = data + "♣" + GlobalLevel.Global.TransFields[4];//tender details2
                                //data = data + "§" + GlobalLevel.Global.TransFields[5];//tender details3
                                string finaldata = el.InnerHtml.Replace("***", "* * *");
                                try
                                {

                                    string purchaser = finaldata.Substring(finaldata.IndexOf("♠") + 1);
                                    purchaser = purchaser.Remove(purchaser.IndexOf("♣"));
                                    Global.TransFields[1] = purchaser.Replace("♠", "").Replace("-", "");
                                }
                                catch (Exception ex)
                                { }

                                try
                                {
                                     string sd = finaldata.Substring(finaldata.IndexOf("♣♣♣") + "♣♣♣".Length);
                                    sd = sd.Remove(sd.IndexOf("♥"));
                                    Global.TransFields[2] = sd;
                                }
                                catch (Exception)
                                { }


                                try
                                {
                                    string td = el.InnerHtml.Substring(el.InnerHtml.IndexOf("♥♥♥") + 1);
                                    //td = td.Remove(td.IndexOf("♦"));
                                    Global.TransFields[3] = td.Replace("♥", "");
                                }
                                catch (Exception)
                                { }

                                //try
                                //{
                                //    string td2 = el.InnerHtml.Substring(el.InnerHtml.IndexOf("♦") + 1);
                                //    //if (td2.Contains("♠"))
                                //    //    td2 = td2.Remove(td2.IndexOf("♠"));
                                //    Global.TransFields[4] = td2.Replace("♦", "");
                                //}
                                //catch (Exception)
                                //{ }

                                //try
                                //{
                                //    string td3 = el.InnerHtml.Substring(el.InnerHtml.IndexOf("♠") + 1);
                                //    Global.TransFields[5] = td3.Replace("♠", "");
                                //}
                                //catch (Exception)
                                //{ }

                                this.DialogResult = DialogResult.OK;
                                timer1.Enabled = false;
                            }
                            catch (Exception)
                            {
                                MessageBox.Show("Problem detected in Being Translation");
                                timer1.Enabled = true;
                            }
                            //"¢ AO Scientific Center of Pediatrics and pediatric surgery £ purchase antifreeze concentrate  \"&gt; ¤ Zakop Antifreeze concentrate \" &gt; ♣ §"
                        }
                        else
                        {
                            timer1.Enabled = true;
                        }
                    }
                    else
                    {
                        timer1.Enabled = true;
                    }
                }
                else
                {
                    timer1.Enabled = true;
                }
            }
            else
            {
                timer++;
                label1timer.Visible = true;
                label1timer.Text = timer + "% Loading...";
                label1timer.Refresh();
                this.Text = "compranet.hacienda.gob.mx" + " Bing!!" + timer + "% Loading...";
            }
        }
    }
}
