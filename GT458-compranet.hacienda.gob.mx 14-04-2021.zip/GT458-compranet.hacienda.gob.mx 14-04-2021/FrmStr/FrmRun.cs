﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace ETGB
{
    public partial class FrmRun : Form
    {
        ETGB.ClassI Data = new ETGB.ClassI();
        HtmlDocument doc = null;
        List<string> links = new List<string>();
        List<string> submitter = new List<string>();

        static SqlConnection sqlconnection;
        public SqlDataReader sqldatareader;
        SqlCommand Sqlcmd = new SqlCommand();
        static string ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
        static DataTable OldLinks = new DataTable(); bool checkedLinks = false; int translator_repeat = 0; bool checkduplicatetrue = true;
        int trans_2_flag = 0;
        string OnLeft = ""; string OnRight = ""; string OnRight0 = ""; string OnRight1 = ""; string OnRight2 = ""; string ReplyStrings = ""; string Disclaimer = ""; string MyWorkBuff = "";
        int MyBegin = -1; int MyEnd = -1; int MyCurr1 = -1; int MyCurr2 = -1; int MyCurr = -1; int MyReturnValue = 0; int OnLeftLength = 0; int MyReturnCode = 0; string MyNullString = ""; string MySingleSpace = " ";
        int pno; int t = 0; string MyString = ""; public int Posting_Id = 0; public string MySqlQuery = ""; string[] res;int translator = 0;
        string status = ""; bool get_tender_nos = false; static DataTable Tender_Nos = new DataTable();int duplicate_link = 0;
        int j = 0;
        int i = 0;
        int a = 0;
        int Method = 0;
        int Pg_NO = 2;
        int Frm_Pg = 11;
        int To_Pg = 0;
        HtmlElement OurElement = null;
        public FrmRun()
        {
            InitializeComponent();
        }
        public void search_click()
        {
            if (doc.Body.InnerHtml.Contains("Search for Solicitations &amp; Awards"))
            {
                HtmlElementCollection eleCol = doc.GetElementsByTagName("button");
                foreach (HtmlElement ele in eleCol)
                {
                    if (ele.InnerHtml.Contains(" Search"))
                    {
                        ele.InvokeMember("click");
                        //timer1.Enabled = true;
                        Application.DoEvents();
                        timer1.Enabled = true;
                        break;
                    }
                }
                //label2linkcoll.Visible = true;
                //label2linkcoll.Text = "Links Collected : " + GlobalLevel.Global.Doc_Links.Count.ToString();
                //label2linkcoll.Refresh();
            }
        }
        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

            if (webBrowser1.ReadyState.ToString() == "Complete")
            {
                doc = webBrowser1.Document;
                if (doc.Body.InnerText.Contains("Navigation to the webpage was canceled") || doc.Body.InnerText.Contains("This program cannot display the webpage"))
                {
                    MessageBox.Show(new Form() { TopMost = true }, "Network Connection Failed.\r\n    OR\r\nNavigation to the webpage was canceled!!", "Network Problem!!", MessageBoxButtons.OK, MessageBoxIcon.None);
                    this.Close();
                    Application.Exit();
                    Environment.Exit(0);
                }

                switch (status)
                {
                    case "search_click":
                        status = "sad";
                        //NavigateLinks();              
                       // NextPage();
                        break;



                    case "Collectlink":

                        CollectLinks();
                        NavigateLinks();              
                        //NextPage();
                        break;

                    case "Data":
                        MakeDocument();
                        NavigateLinks();

                        break;
                }
            }
        }
        private void FrmRun_Load(object sender, EventArgs e)
        {
            webBrowser1.ScriptErrorsSuppressed = true;
            if (Global.Conserver == "Live")
            {
                this.Text = "compranet.hacienda.gob.mx - Live";
                webBrowser1.Navigate("https://compranet.hacienda.gob.mx/esop/guest/go/public/opportunity/current?locale=es_MX");
                timer1.Enabled = true;
            }
            else
            {
                this.Text = "compranet.hacienda.gob.mx - Test";//https://compranet.hacienda.gob.mx/esop/guest/go/public/opportunity/current?locale=es_MX
                webBrowser1.Navigate("https://compranet.hacienda.gob.mx/esop/guest/go/public/opportunity/current?locale=es_MX");
                timer1.Enabled = true;
            }

        }

        public void CollectLinks()
        {
            if (get_tender_nos == false)
            {
                CollectTenderNos();
                get_tender_nos = true;
            }

            try
            {
                HtmlElementCollection elecol = doc.GetElementsByTagName("tr");
                foreach (HtmlElement ele in elecol)
                {
                    if(ele.InnerHtml!=null)
                    {
                        if(ele.InnerHtml.Contains("onclick=\"javascript:goToDetail"))
                        {
                            HtmlElementCollection elcol = ele.GetElementsByTagName("td");
                            string link = "";
                            if (elcol[4].InnerHtml.Contains("javascript: goToDetail("))
                            {
                                 link = elcol[4].InnerHtml;
                            }
                            else
                            {
                                link = elcol[3].InnerHtml;
                            }
                            link = link.Substring(link.IndexOf("javascript:goToDetail('") + "javascript:goToDetail('".Length);
                            link = link.Remove(link.IndexOf("',"));
                            link = link.Replace("&amp;", "&");
       
                            link = "https://compranet.hacienda.gob.mx/esop/toolkit/opportunity/current/" + link + "/detail.si";
                            ETGB.Global.Doc_Links.Add(link);
                            ETGB.Global.Doc_Links = ETGB.Global.Doc_Links.Distinct().ToList();                            
                            lbl_linkcol.Text = "Links Collected : " + ETGB.Global.Doc_Links.Count;
                            lbl_linkcol.Refresh();
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show("Error in GetDataLinks() method...Give it for maintenance \n\n" + ee.Message, "compranet.hacienda.gob.mx");
                Application.Exit();
            }
        }
        public void NextPage()
        {
            try
            {
                if (doc.Body.InnerHtml.Contains(">" + Pg_NO + "</a>"))//>2</A>
                {
                    label1pno.Visible = true;
                    label1pno.Text = "Page No. : " + Pg_NO;
                    label1pno.Refresh();
                    HtmlElementCollection tdcoll = doc.GetElementsByTagName("a");
                    foreach (HtmlElement ele in tdcoll)
                    {
                        if (ele.OuterHtml.Contains(">" + Pg_NO + "</a>"))
                        {
                            ele.InvokeMember("click");
                            Application.DoEvents();
                            Pg_NO++;
                            status = "amit";
                            timer1.Enabled = true;
                            break;
                        }
                    }
                }
                else
                {
                    NavigateLinks();
                }
            }
            catch
            {

            }
        }

        public void NavigateLinks()
        {
            timer1.Enabled = false;
            if (checkedLinks == false)
            {
                CheckDuplicateLinks();
                checkedLinks = true;
            }

            if (a < ETGB.Global.Doc_Links.Count)
            {
                try
                {
                    string Link = ETGB.Global.Doc_Links[a];
                    webBrowser1.Navigate(Link);
                    a++;
                    status = "Data";
                    lbl_total.Text = "Total : " + ETGB.Global.Doc_Links.Count;
                    lbl_total.Refresh();

                    lbl_current.Text = "Current : " + a;
                    lbl_current.Refresh();

                    lbl_duplicate.Text = "Duplicate : " + Global.Duplicate;
                    lbl_duplicate.Refresh();

                    lbl_inserted.Text = "Inserted : " + Global.Inserted;
                    lbl_inserted.Refresh();
                }
                catch
                {

                }
            }
            else
            {
                MessageBox.Show("All Data Inserted Successfully....!!\n\nTotal Data : " + ETGB.Global.Doc_Links.Count + "\n\nTotal Inserted : " + ETGB.Global.Inserted + "\n\nDuplicate Data : " + ETGB.Global.Duplicate + "\n\nExpired Data : " + ETGB.Global.Skipped, "compranet.hacienda.gob.mx", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
                Environment.Exit(0);
            }
        }

        public void MakeDocument()
        {
            Expire_label.Visible = false;
            string FinalDoc = doc.Body.InnerHtml;
            string FinalTxt = doc.Body.InnerText;
            string TempLink = doc.Url.AbsoluteUri;
            label3.Visible = true;
            checkduplicatetrue = false;
            if (!(FinalDoc.Contains("invalid URL")) || !(FinalDoc.Contains("Sorry")))
            {
                try
                {
                    string title = FinalDoc.Substring(FinalDoc.IndexOf("<h1")).Trim();
                    title = title.Remove(title.IndexOf("</h1>"));
                    title = Regex.Replace(title, @"<[^>]*>", String.Empty).Trim();

                    HtmlElement elem = doc.GetElementById("cntDetail");
                    FinalDoc = elem.InnerHtml.ToString();
                    FinalDoc = FinalDoc.Substring(FinalDoc.IndexOf("<h3")).Trim();

                    FinalDoc = "<h1>" + title + "</h1><br>" + FinalDoc; 
                    FinalDoc = FinalDoc.Replace("href=\"", "href=\"https://compranet.hacienda.gob.mx");
                    FinalDoc = FinalDoc.Replace("src=\"", "src=\"https://compranet.hacienda.gob.mx");

                    string deadline = ""; string contact_person = ""; string opening_date = "";
                    string tender_no = ""; string short_desc = ""; string purchaser = ""; string typeoften = ""; string purchaser_address = ""; string p_email = "";
                    string price = ""; string requirments = ""; string detail = ""; string announcement = ""; string place = ""; string cpv = ""; string url = "";
                    try
                    {
                        //=============== [Notice_No] ==========================13
                        try
                        {
                            OnLeft = "Código del Expediente";
                            OnRight0 = "</li>";
                            OnRight1 = "Descripción del Expediente";
                            OnRight2 = "";
                            ReplyStrings = Data.GetRqdStr(FinalDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                            tender_no = ReplyStrings;
                        }
                        catch
                        {
                            tender_no = "";
                        }

                        DataRow[] temp = Tender_Nos.Select("tender_notice_no = '" + tender_no + "'");
                        if (temp.Length != 0 && tender_no != "")
                        {
                            Global.Duplicate++;
                            checkduplicatetrue = true;
                        }

                        //=============== [Short Desc] ==========================13
                        try
                        {
                            OnLeft = "Descripción del Anuncio";
                            OnRight0 = "</li>";
                            OnRight1 = "Notas";
                            OnRight2 = "";
                            ReplyStrings = Data.GetRqdStr(FinalDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                            if (ReplyStrings != "")
                            {
                                short_desc = ReplyStrings;
                            }
                            else
                            { }
                        }
                        catch
                        {
                            short_desc = "";
                        }

                        //=============== [Purchaser] ==========================13
                        try
                        {
                            OnLeft = "Nombre de la Unidad Compradora (UC)";
                            OnRight0 = "</li>";
                            OnRight1 = "Nombre del Operador en la UC";
                            OnRight2 = "";
                            ReplyStrings = Data.GetRqdStr(FinalDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                            purchaser = ReplyStrings.ToUpper();
                        }
                        catch
                        {
                            purchaser = "";
                        }

                        //=============== [Deadline] ==========================13
                        try
                        {
                            OnLeft = "Plazo de participación o vigencia del anuncio";
                            OnRight0 = "</li>";
                            OnRight1 = "Fecha de Inicio del Contrato";
                            OnRight2 = "";
                            ReplyStrings = Data.GetRqdStr(FinalDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                            ReplyStrings = ReplyStrings.Remove(ReplyStrings.IndexOf(" ") + " ".Length);
                            if (ReplyStrings != "")
                            {
                                try
                                {
                                    DateTime MyDateTime = new DateTime();
                                    MyDateTime = DateTime.ParseExact(ReplyStrings, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                    deadline = MyDateTime.ToString("yyyy-MM-dd");
                                }
                                catch (Exception ex)
                                {
                                    DateTime MyDateTime = new DateTime();
                                    MyDateTime = Convert.ToDateTime(ReplyStrings);
                                    deadline = MyDateTime.ToString("yyyy-MM-dd");
                                }
                            }
                        }
                        catch
                        {
                            deadline = "";
                        }

                        //=============== [Published Date] ==========================13
                        try
                        {
                            OnLeft = "Fecha de publicación del anuncio (Convocatoria / Invitación / Adjudicación / Proyecto de Convocatoria)";
                            OnRight0 = "</li>";
                            OnRight1 = "Plazo de participación o vigencia del anuncio";
                            OnRight2 = "";
                            ReplyStrings = Data.GetRqdStr(FinalDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                            opening_date = ReplyStrings;
                        }
                        catch
                        {
                            opening_date = "";
                        }

                        //=============== [Type] ==========================13
                        try
                        {
                            OnLeft = "Tipo de Contratación";
                            OnRight0 = "</li>";
                            OnRight1 = "Entidad Federativa";
                            OnRight2 = "";
                            ReplyStrings = Data.GetRqdStr(FinalDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                            typeoften = ReplyStrings;
                        }
                        catch
                        {
                            typeoften = "";
                        }
                        //=============== [Purchaser_Email] ====================
                        ReplyStrings = FinalDoc;
                        res = Data.GetResult(ReplyStrings);
                        res = res.Distinct().ToArray();
                        if (res.Length >= 1)
                        {
                            ReplyStrings = "";
                            foreach (string element in res)
                            {
                                if (ReplyStrings == "")
                                {
                                    ReplyStrings = element;
                                }
                                else
                                {
                                    if (!ReplyStrings.Contains(element))
                                    {
                                        ReplyStrings = ReplyStrings + ", " + element;
                                    }
                                }
                            }
                        }
                        else
                        {
                            ReplyStrings = "";
                        }
                        p_email = ReplyStrings;

                        //=============== [Contact Person] ==========================13
                        try
                        {
                            OnLeft = "Nombre del Operador en la UC";
                            OnRight0 = "</li>";
                            OnRight1 = "Correo Electrónico del Operador en la UC";
                            OnRight2 = "";
                            ReplyStrings = Data.GetRqdStr(FinalDoc, OnLeft, OnRight0, OnRight1, OnRight2);
                            ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                            contact_person = ReplyStrings;
                        }
                        catch
                        {
                            contact_person = "";
                        }

                        if (checkduplicatetrue != true)
                        {
                            if (Data.CheckDuplicate_b4(tender_no, TempLink) == false)
                            {
                                try
                                {
                                    if (deadline != "")
                                    {
                                        DateTime dt = DateTime.ParseExact(deadline, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
                                        DateTime dt2 = Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd"));
                                        TimeSpan ts = dt - dt2;
                                        int days = ts.Days;
                                        if (days >= 0)
                                        {
                                            checkduplicatetrue = false;
                                        }
                                        else
                                        {
                                            Global.Skipped++;
                                            checkduplicatetrue = false;
                                        }
                                    }
                                    else
                                    {
                                        checkduplicatetrue = false;
                                    }
                                }
                                catch (Exception)
                                {
                                    checkduplicatetrue = false;
                                }
                            }
                            else
                            {
                                Global.Duplicate++;
                                checkduplicatetrue = true;
                            }

                            Global.TransFields.Clear();
                            for (int i = 0; i < 30; i++) { Global.TransFields.Add(""); }
                            // FOR TRANSLATION purchaser, purchaser_address, short_desc, contact_person,typeoften

                            if (checkduplicatetrue != true)
                            {

                                string data_trans = short_desc + "  ♣   " + typeoften + "  ♣  " + purchaser;
                                if (data_trans.Length < 3000)
                                {
                                    try
                                    {

                                        data_trans = translate(data_trans);

                                        data_trans = data_trans.Replace("\r", "");
                                        data_trans = data_trans.Replace("\n", "");

                                        string[] data_trans_arr = data_trans.Split('♣');

                                        Global.TransFields[1] = data_trans_arr[2].Trim();
                                        Global.TransFields[2] = data_trans_arr[0].Trim();
                                        Global.TransFields[3] = data_trans_arr[1].Trim();
                                    }
                                    catch (Exception exx2)
                                    {

                                        if (purchaser != "")
                                        {
                                            Global.TransFields[1] = translate(purchaser); //Regex.Replace(purchaser, @"<[^>]*>", String.Empty).Trim();
                                        }
                                        if (short_desc != "")
                                        {
                                            Global.TransFields[2] = translate(short_desc);//Regex.Replace(short_desc, @"<[^>]*>", String.Empty).Trim();
                                        }
                                        if (typeoften != "")
                                        {
                                            Global.TransFields[3] = translate(typeoften);//Regex.Replace(purchaser_address, @"<[^>]*>", String.Empty).Trim();
                                        }
                                    }

                                }
                                else
                                {


                                    if (purchaser != "")
                                    {
                                        Global.TransFields[1] = translate(purchaser); //Regex.Replace(purchaser, @"<[^>]*>", String.Empty).Trim();
                                    }
                                    if (short_desc != "")
                                    {
                                        Global.TransFields[2] = translate(short_desc);//Regex.Replace(short_desc, @"<[^>]*>", String.Empty).Trim();
                                    }
                                    if (typeoften != "")
                                    {
                                        Global.TransFields[3] = translate(typeoften);//Regex.Replace(purchaser_address, @"<[^>]*>", String.Empty).Trim();
                                    }
                                }
                                //Global.TransFields[4] = Regex.Replace(typeoften, @"<[^>]*>", String.Empty).Trim();

                                if (checkduplicatetrue != true)
                                {
                                    if (Global.TransFields[1].Contains("\""))
                                    {
                                        Global.TransFields[1] = Global.TransFields[1].Replace("\"", "");
                                        Global.TransFields[1] = Global.TransFields[1].Trim();
                                    }



                                    Global.TransFields[1] = Global.TransFields[1].Trim();
                                    Global.TransFields[2] = Global.TransFields[2].Trim();
                                    Global.TransFields[3] = Global.TransFields[3].Trim();

                                    string Document1 = "";

                                    if (deadline != "")
                                    {
                                        Document1 = "<table border=\"1\" style=\"width:100%;border-spacing:0;border-collapse: collapse;border:1px solid #666666;\">" +
                                                    "<tr><td colspan=\"2\"; style=\"background-color:#CCCCCC; font-weight: bold; padding:7px;border-bottom:1px solid #666666;\">Tender Details</td></tr>" +
                                                    "<tr bgcolor=\"#FFFFFF\" onmouseover=\"this.style.backgroundColor='#C0D6FE'\" onmouseout=\"this.style.backgroundColor=''\"><td>Tender No </td><td>" + tender_no + "</td></tr>" +
                                                    "<tr bgcolor=\"#FFFFFF\" onmouseover=\"this.style.backgroundColor='#C0D6FE'\" onmouseout=\"this.style.backgroundColor=''\"><td>Notice Title </td><td>" + Global.TransFields[2] + "</td></tr>" +
                                                    "<tr bgcolor=\"#FFFFFF\" onmouseover=\"this.style.backgroundColor='#C0D6FE'\" onmouseout=\"this.style.backgroundColor=''\"><td>Purchaser </td><td>" + Global.TransFields[1] + "</td></tr>" +
                                                    "<tr bgcolor=\"#FFFFFF\" onmouseover=\"this.style.backgroundColor='#C0D6FE'\" onmouseout=\"this.style.backgroundColor=''\"><td>Purchaser Address </td><td>" + "Mexico <br>Contact Person :" + contact_person + "<br>Email : " + p_email + "</td></tr>" +
                                                    "<tr bgcolor=\"#FFFFFF\" onmouseover=\"this.style.backgroundColor='#C0D6FE'\" onmouseout=\"this.style.backgroundColor=''\"><td>Type Of Tender </td><td>" + typeoften + "</td></tr>" +
                                                    "<tr bgcolor=\"#FFFFFF\" onmouseover=\"this.style.backgroundColor='#C0D6FE'\" onmouseout=\"this.style.backgroundColor=''\"><td>Published Date </td><td>" + opening_date + "</td></tr>" +
                                                    "<tr bgcolor=\"#FFFFFF\" onmouseover=\"this.style.backgroundColor='#C0D6FE'\" onmouseout=\"this.style.backgroundColor=''\"><td>Closing Date </td><td>" + deadline + "</td></tr>" +
                                                    "<tr bgcolor=\"#FFFFFF\" onmouseover=\"this.style.backgroundColor='#C0D6FE'\" onmouseout=\"this.style.backgroundColor=''\"><td>More Details </td><td><a href=" + TempLink + " target=\"_blank\">Click Here</a></td></tr></table>";






                                        Document1 = "<HTML><BODY><style style=\"text/css\"> td{ padding:5px;}</style>" + Document1 + "<BR><BR><font color='RED'>[Disclaimer: The above text is machine translated. For accurate information kindly refer the below original document.]</font><BR><BR>" + FinalDoc + "</BODY></HTML>";
                                        FinalDoc = Document1;
                                        FinalDoc = FinalDoc.Replace("&amp;", "&");


                                    }
                                    else
                                    {

                                    }
                                    try
                                    {
                                        if (!FinalDoc.Contains("RFT Access Passcode:"))
                                            Data.GoToInsert(FinalDoc, FinalTxt, TempLink);
                                    }
                                    catch (Exception e)
                                    {
                                        MessageBox.Show("/r/n Error\r\n" + TempLink + "\r\n\r\n" + e);
                                    }

                                }
                            }
                        }

                    }
                    catch(Exception ex)
                    { }


                }
                catch (Exception ex)
                {
                    //MessageBox.Show("Error In Making Document  " + ex);
                }
                
            }
        }

        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        private void webBrowser1_ProgressChanged(object sender, WebBrowserProgressChangedEventArgs e)
        {
            try
            {
                toolStripProgressBar1.Maximum = (int)e.MaximumProgress;
                toolStripProgressBar1.Value = (int)e.CurrentProgress;
            }
            catch { }
        }

        private void webBrowser1_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            textBox1.Text = e.Url.ToString();
        }

        private string GetSource(string url)
        {
            System.Net.WebRequest WReq = null;
            System.Net.WebResponse WRes = null;
            System.IO.StreamReader SReader = null;
            WRes = null;
            string searchData = "";
            try
            {
                ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
                WReq = System.Net.WebRequest.Create(url);
                //WReq.Timeout = 2 * 60 * 1000;
                WRes = WReq.GetResponse();
                SReader = new System.IO.StreamReader(WRes.GetResponseStream());
                searchData = SReader.ReadToEnd();
                WRes.Close();
                WReq = null;
                WRes = null;
            }
            catch
            {
                //GetSource(url);
            }
            return searchData;
        }
        public string GetRqdStr(string TheString, string OnLeft, string OnRight0, string OnRight1, string OnRight2)
        {
            if (TheString != null && TheString.Trim() != null)
            {
                MyBegin = TheString.IndexOf(OnLeft, 0);
                if (MyBegin == -1)
                {
                    ReplyStrings = "";
                }
                else
                {
                    if (OnRight0 == null || OnRight0 == "")
                    {
                        MyCurr = -1;
                    }
                    else
                    {
                        MyCurr = TheString.IndexOf(OnRight0, (MyBegin + OnLeft.Length));
                    }
                    if (OnRight1 == null || OnRight1 == "")
                    {
                        MyCurr1 = -1;
                    }
                    else
                    {
                        MyCurr1 = TheString.IndexOf(OnRight1, (MyBegin + OnLeft.Length));
                    }
                    if (OnRight2 == null || OnRight2 == "")
                    {
                        MyCurr2 = -1;
                    }
                    else
                    {
                        MyCurr2 = TheString.IndexOf(OnRight2, (MyBegin + OnLeft.Length));
                    }
                    if (MyCurr == -1 && MyCurr1 == -1 && MyCurr2 == -1)
                    {
                        MyEnd = TheString.Length;
                    }
                    else
                    {
                        if (MyCurr == -1)
                        {
                            if (MyCurr1 == -1)
                            {
                                MyEnd = MyCurr2;
                                OnRight = OnRight2;
                            }
                            else
                            {
                                if (MyCurr2 == -1)
                                {
                                    MyEnd = MyCurr1;
                                    OnRight = OnRight1;
                                }
                                else
                                {
                                    if (MyCurr1 < MyCurr2)
                                    {
                                        MyEnd = MyCurr1;
                                        OnRight = OnRight1;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr2;
                                        OnRight = OnRight2;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (MyCurr1 == -1)
                            {
                                if (MyCurr2 == -1)
                                {
                                    MyEnd = MyCurr;
                                    OnRight = OnRight0;
                                }
                                else
                                {
                                    if (MyCurr < MyCurr2)
                                    {
                                        MyEnd = MyCurr;
                                        OnRight = OnRight0;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr2;
                                        OnRight = OnRight2;
                                    }
                                }
                            }
                            else
                            {
                                if (MyCurr2 == -1)
                                {
                                    if (MyCurr < MyCurr1)
                                    {
                                        MyEnd = MyCurr;
                                        OnRight = OnRight0;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr1;
                                        OnRight = OnRight1;
                                    }
                                }
                                else
                                {
                                    if (MyCurr < MyCurr1)
                                    {
                                        if (MyCurr < MyCurr2)
                                        {
                                            MyEnd = MyCurr;
                                            OnRight = OnRight0;
                                        }
                                        else
                                        {
                                            MyEnd = MyCurr2;
                                            OnRight = OnRight2;
                                        }
                                    }
                                    else
                                    {
                                        if (MyCurr2 < MyCurr1)
                                        {
                                            MyEnd = MyCurr2;
                                            OnRight = OnRight2;
                                        }
                                        else
                                        {
                                            MyEnd = MyCurr1;
                                            OnRight = OnRight1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    MyWorkBuff = TheString.Substring((MyBegin + OnLeft.Length),
                                                 (MyEnd - MyBegin - OnLeft.Length));
                    MyWorkBuff = MyWorkBuff.Trim();
                    ReplyStrings = MyWorkBuff.Replace(Environment.NewLine, "");
                }
            }
            else
            {
                ReplyStrings = "";
            }
            return ReplyStrings.Trim();
        }

        public HtmlElement ElementGet(string str, HtmlDocument theDoc)
        {
            String[] htmlTree = str.Split('>');
            String FoundElement = "Y";
            int clevel = 0;
            string currtag = "";
            HtmlElement currelement = theDoc.Body, currchild = null;
            for (int i = 2; i < htmlTree.Length; i++) // starting at index 2 and skipping the HTML and BODY elements.
            {
                clevel = int.Parse(htmlTree[i].Split(':')[1]);
                currtag = htmlTree[i].Split(':')[0];

                int j = 0, childcount = 0;
                if (FoundElement == "Y")
                {
                    FoundElement = "N";
                    childcount = currelement.Children.Count;
                    for (int k = 0; k < childcount; k++)
                    {
                        currchild = currelement.Children[k];
                        if (currchild.DomElement != null)
                        {
                            if (currchild.TagName == currtag)
                            {
                                if (j == clevel)
                                {
                                    currelement = currchild;
                                    childcount = 0;
                                    FoundElement = "Y";
                                    break;
                                }
                                else
                                    j++;
                            }
                        }
                    }
                }
            }
            if (FoundElement == "Y")
            {
                OurElement = currchild;
            }
            else
            {
                OurElement = null;
            }
            return OurElement;
        }

        private void Insert_btn_Click(object sender, EventArgs e)
        {
            NavigateLinks();
        }

        private void Expire_label_Click(object sender, EventArgs e)
        {

        }

        private void label_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (t >= 100)
            {
                t = 0;
                timer1.Enabled = false;
                doc = webBrowser1.Document;
                if (doc != null)
                {
                    if (doc.Body != null)
                    {
                        if (doc.Body.InnerHtml.Contains("Anuncios Vigentes"))
                        {
                            CollectLinks();
                            NextPage();
                        }
                        else
                        { }
                    }
                    else
                    {
                        timer1.Enabled = true;
                    }
                }
                else
                {
                    timer1.Enabled = true;
                }
            }
            else
            {
                t++;
                lbltimer.Visible = true;
                lbltimer.Text = t + "% Loading...";
                lbltimer.Refresh();
            }
        }

        private void lbl_total_Click(object sender, EventArgs e)
        {

        }

        private void lbl_current_Click(object sender, EventArgs e)
        {

        }

        private void lbl_duplicate_Click(object sender, EventArgs e)
        {

        }
        public void CheckDuplicateLinks()
        {
            int loop = 0;
            while (loop == 0)
                try
                {
                    ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
                    String query1 = "Select distinct(tender_doc_file) from [Masterdb_AMS].[dbo].[tblTenders] where source = 'compranet.hacienda.gob.mx'";
                    using (SqlConnection connection = new SqlConnection(ConnectionString))
                    {
                        using (SqlCommand command = new SqlCommand(query1, connection))
                        {
                            command.Connection = connection;
                            using (SqlDataAdapter sda = new SqlDataAdapter(command))
                            {
                                sda.Fill(OldLinks);
                            }
                        }
                    }
                    loop++;
                }
                catch (Exception EX)
                {
                    loop = 0;
                }
            GetOldLinks();
        }

        public void GetOldLinks()
        {


            lbl_chk1.Text = "Total Links before: " + ETGB.Global.Doc_Links.Count.ToString();
            lbl_chk1.Refresh();
            lbl_chk2.Text = "Total Links After: " + ETGB.Global.Doc_Links.Count.ToString();
            lbl_chk2.Refresh();
            lbl_chk3.Text = "Status.. ";
            lbl_chk3.Refresh();


            int i = 1;
            try
            {

                foreach (DataRow dRow in OldLinks.Rows)
                {
                    i++;
                    if (ETGB.Global.Doc_Links.Contains(dRow["tender_doc_file"]))
                    {
                        ETGB.Global.Doc_Links.Remove(dRow["tender_doc_file"].ToString());
                    }
                    else
                    {
                    }
                    lbl_chk3.Text = "Status.." + i.ToString() + " / " + OldLinks.Rows.Count.ToString();
                    lbl_chk3.Refresh();
                }
            }
            catch (Exception)
            { }


            ETGB.Global.Doc_Links.Distinct();

            lbl_chk2.Text = "Total Links After: " + ETGB.Global.Doc_Links.Count.ToString();
            lbl_chk2.Refresh();

        }

        private void label2linkcol_Click(object sender, EventArgs e)
        {

        }
        string mac_id = "";
        public static PhysicalAddress GetMacAddress()
        {
            try
            {
                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.NetworkInterfaceType == NetworkInterfaceType.Wireless80211 && nic.OperationalStatus == OperationalStatus.Up)
                    {
                        return nic.GetPhysicalAddress();
                    }
                }
                foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.NetworkInterfaceType == NetworkInterfaceType.Ethernet && nic.OperationalStatus == OperationalStatus.Up)
                    {
                        return nic.GetPhysicalAddress();
                    }
                }
                return null;
            }
            catch (Exception exception1)
            {
                MessageBox.Show(exception1.ToString() + " in GetMacAddress", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return null;
        }

        public String TranslateNew(string Text)
        {
            Text = Text.Replace("/", "&sol;");
            Text = Text.Replace(":", "®");
            Text = Text.Replace("+", "¶");
            Text = Text.Replace("(", "μ");
            Text = Text.Replace(")", "∩");


            int loop = 1;
            while (loop == 1)
            {
                string Final = "";
                try
                {

                    List<string> GlUrlList = SplitIntoChunks(Text, 200);
                    Text = "";
                    int Length = GlUrlList.Count;
                    for (int a = 0; a <= Length - 1; a++)
                    {
                        int tr = 0;
                        while (tr < 1)
                        {
                            try
                            {

                                string translation = string.Empty;







                                string fromCulture = "auto";
                                fromCulture = fromCulture.ToLower();
                                string[] tokens = fromCulture.Split('-');
                                if (tokens.Length > 1)
                                    fromCulture = tokens[0];


                                // normalize ToCulture
                                string toCulture = "en";
                                toCulture = toCulture.ToLower();
                                tokens = toCulture.Split('-');
                                if (tokens.Length > 1)
                                    toCulture = tokens[0];

                                string url1 = string.Format(@"http://translate.google.com/translate_a/t?client=j&text={0}&hl=en&sl={1}&tl={2}",
                                System.Web.HttpUtility.UrlEncode(System.Web.HttpUtility.UrlEncode(GlUrlList[a])), fromCulture, toCulture);
                                // Retrieve Translation with HTTP GET call
                                string html = null;
                                try
                                {
                                    System.Net.WebClient web = new System.Net.WebClient();

                                    // MUST add a known browser user agent or else response encoding doen't return UTF-8 (WTF Google?)
                                    web.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36");
                                    web.Headers.Add(System.Net.HttpRequestHeader.AcceptCharset, "UTF-8");

                                    // Make sure we have response encoding to UTF-8
                                    web.Encoding = Encoding.UTF8;
                                    html = web.DownloadString(url1);
                                    html = System.Web.HttpUtility.UrlDecode(html);

                                    // Fix up translation
                                    translation = html.Trim();
                                    translation = translation.Replace(" ?", "?");
                                    translation = translation.Replace(" !", "!");
                                    translation = translation.Replace(" ,", ",");
                                    translation = translation.Replace(" .", ".");
                                    translation = translation.Replace(" ;", ";");
                                    translation = translation.Replace("<br>", "\r\n");
                                    translation = Regex.Replace(translation, @"<[^>]*>", "").Trim();
                                    translation = translation.Replace("|", "\"");
                                    if (translation.EndsWith("\""))
                                    {
                                        translation = translation.Remove(translation.Length - 1);
                                    }
                                    translation = ReplaceSpecialCharacters(translation);
                                    Final += translation;
                                    Final = Final.Replace("\\\"", "\"");
                                    tr++;
                                }
                                catch (Exception ex)
                                {
                                    //  MessageBox.Show("Stop for 503 error from WorldBank " + DateTime.Now.ToShortTimeString());
                                    //Application.Exit();
                                    //Environment.Exit(0);
                                    tr = 0;

                                    try
                                    {
                                        string url = string.Format("https://translate.googleapis.com/translate_a/single?client=gtx&sl={0}&tl={1}&dt=t&q={2}", "auto", "en", System.Web.HttpUtility.UrlEncode(GlUrlList[a]));
                                        string outputFile = Path.GetTempFileName();
                                        using (System.Net.WebClient wc = new System.Net.WebClient())
                                        {
                                            wc.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36");
                                            wc.DownloadFile(url, outputFile);
                                        }
                                        // Get translated text
                                        if (File.Exists(outputFile))
                                        {

                                            //Get phrase collection
                                            string text = File.ReadAllText(outputFile);
                                            text = text.Replace("\\\"", "");
                                            text = text.Replace("[[[\"", "");
                                            text = text.Replace("\\u0026", "&");
                                            text = text.Replace("&sol;", "/");
                                            if (text.Contains(GlUrlList[a]))
                                            {
                                                translation = text.Remove(text.IndexOf(",\"" + GlUrlList[a]));
                                            }
                                            else
                                            {
                                                translation = GlUrlList[a];
                                            }
                                            // Fix up translation
                                            translation = translation.Trim();
                                            translation = translation.Replace("\\u0026", "&");
                                            translation = translation.Replace("&sol;", "/");
                                            translation = translation.Replace(" ?", "?");
                                            translation = translation.Replace(" !", "!");
                                            translation = translation.Replace(" ,", ",");
                                            translation = translation.Replace(" .", ".");
                                            translation = translation.Replace(" ;", ";");
                                            translation = translation.Replace("<br>", "\r\n");
                                            translation = Regex.Replace(translation, @"<[^>]*>", "").Trim();
                                            translation = translation.Replace("|", "\"");
                                            if (translation.EndsWith("\""))
                                            {
                                                translation = translation.Remove(translation.Length - 1);
                                            }
                                            translation = ReplaceSpecialCharacters(translation);
                                            Final += translation;
                                            Final = Final.Replace("\\\"", "\"");
                                            tr++;
                                        }
                                    }
                                    catch (Exception exe)
                                    {
                                        if (exe.Message.Contains("StartIndex cannot be less than zero"))
                                        {
                                            Final += translation;
                                            Final = Final.Replace("\\\"", "\"");
                                            tr++;
                                        }
                                        else
                                        {
                                            MessageBox.Show("Stop for 503 error from  " + DateTime.Now.ToShortTimeString());
                                            //Application.Exit();
                                            //Environment.Exit(0);
                                            tr = 0;
                                        }
                                    }

                                }
                                //}
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Stop for 503 error from UNGM " + DateTime.Now.ToShortTimeString());
                                //Application.Exit();
                                //Environment.Exit(0);
                                tr = 0;
                            }
                        }
                    }

                    Text = Final;
                    loop = 0;
                    if (Text == "")
                    {
                        Text = Final;
                        loop = 1;
                    }
                }
                catch (Exception ex)
                {
                    Text = Final;
                    loop = 1;
                    return Text;
                }
            }

            Text = Text.Replace("&sol;", "/");
            Text = Text.Replace("®", ":");
            Text = Text.Replace("¶", "+");
            Text = Text.Replace("μ", "(");
            Text = Text.Replace("∩", ")");

            return Text;
        }
        public string ReplaceSpecialCharacters(string cString)
        {
            cString = cString.Replace("â€™", "-");
            cString = cString.Replace("â€“", "-");
            cString = cString.Replace("â€", "-");
            cString = cString.Replace("â€“", "-");
            cString = cString.Replace("¢", "c");
            cString = cString.Replace("£", "£");
            cString = cString.Replace("¤", "");
            cString = cString.Replace("¥", "");
            cString = cString.Replace("¦", "");
            cString = cString.Replace("§", "§");
            cString = cString.Replace("¨", "");
            cString = cString.Replace("©", "(c)");
            cString = cString.Replace("ª", "");
            cString = cString.Replace("«", "<");
            cString = cString.Replace("¬", "-");
            cString = cString.Replace("­", "-");
            cString = cString.Replace("®", "(r)");
            cString = cString.Replace("¯", "-");
            cString = cString.Replace("°", "");
            cString = cString.Replace("±", "+/-");
            cString = cString.Replace("²", "2");
            cString = cString.Replace("´", "'");
            cString = cString.Replace("µ", "y");
            cString = cString.Replace("¶", "P");
            cString = cString.Replace("·", ".");
            cString = cString.Replace("¸", "");
            cString = cString.Replace("¹", "1");
            cString = cString.Replace("º", "");
            cString = cString.Replace("»", ">");
            cString = cString.Replace("¼", "1/4");
            cString = cString.Replace("½", "1/2");
            cString = cString.Replace("¾", "3/4");
            cString = cString.Replace("¿", "?");
            cString = cString.Replace("À", "A");
            cString = cString.Replace("Á", "A");
            cString = cString.Replace("Â", "A");
            cString = cString.Replace("Ã", "A");
            cString = cString.Replace("Ä", "Ae");
            cString = cString.Replace("Å", "A");
            cString = cString.Replace("Æ", "Ae");
            cString = cString.Replace("Ç", "C");
            cString = cString.Replace("È", "E");
            cString = cString.Replace("É", "E");
            cString = cString.Replace("Ê", "E");
            cString = cString.Replace("Ë", "E");
            cString = cString.Replace("Ì", "I");
            cString = cString.Replace("Í", "I");
            cString = cString.Replace("Î", "I");
            cString = cString.Replace("Ï", "I");
            cString = cString.Replace("Ð", "D");
            cString = cString.Replace("Ñ", "N");
            cString = cString.Replace("Ò", "O");
            cString = cString.Replace("Ó", "O");
            cString = cString.Replace("Ô", "O");
            cString = cString.Replace("Õ", "O");
            cString = cString.Replace("Ö", "Oe");
            cString = cString.Replace("×", "x");
            cString = cString.Replace("Ø", "0");
            cString = cString.Replace("Ù", "U");
            cString = cString.Replace("Ú", "U");
            cString = cString.Replace("Û", "U");
            cString = cString.Replace("Ü", "Ue");
            cString = cString.Replace("Ý", "Y");
            cString = cString.Replace("Þ", "p");
            cString = cString.Replace("ß", "ss");
            cString = cString.Replace("à", "a");
            cString = cString.Replace("á", "a");
            cString = cString.Replace("â", "a");
            cString = cString.Replace("ã", "a");
            cString = cString.Replace("ä", "ae");
            cString = cString.Replace("å", "a");
            cString = cString.Replace("æ", "ae");
            cString = cString.Replace("ç", "c");
            cString = cString.Replace("è", "e");
            cString = cString.Replace("é", "e");
            cString = cString.Replace("ê", "e");
            cString = cString.Replace("ë", "e");
            cString = cString.Replace("ì", "i");
            cString = cString.Replace("í", "i");
            cString = cString.Replace("î", "i");
            cString = cString.Replace("ï", "i");
            cString = cString.Replace("ð", "a");
            cString = cString.Replace("ñ", "n");
            cString = cString.Replace("ò", "o");
            cString = cString.Replace("ó", "o");
            cString = cString.Replace("ô", "o");
            cString = cString.Replace("õ", "o");
            cString = cString.Replace("ö", "oe");
            cString = cString.Replace("ó", "o");
            cString = cString.Replace("÷", "/");
            cString = cString.Replace("ø", "0");
            cString = cString.Replace("ù", "u");
            cString = cString.Replace("ú", "u");
            cString = cString.Replace("û", "u");
            cString = cString.Replace("ü", "ue");
            cString = cString.Replace("ý", "y");
            cString = cString.Replace("þ", "p");
            cString = cString.Replace("ÿ", "y");
            cString = cString.Replace("–", " ");
            cString = cString.Replace("“", "\"");
            cString = cString.Replace("”", "\"");
            cString = cString.Replace("’", "\'");
            cString = cString.Replace("’", "");
            cString = cString.Replace("&ndash;", "–");
            cString = cString.Replace("&mdash;", "—");
            cString = cString.Replace("&iexcl;", "¡");
            cString = cString.Replace("&iquest;", "¿");
            cString = cString.Replace("&quot;", "\"");
            cString = cString.Replace("&ldquo;", "“");
            cString = cString.Replace("&rdquo;", "”");
            cString = cString.Replace("&lsquo;", "‘");
            cString = cString.Replace("&rsquo;", "’");
            cString = cString.Replace("&laquo;", "«");
            cString = cString.Replace("&raquo;", "»");
            cString = cString.Replace("&nbsp;", "  ");
            cString = cString.Replace("&amp;", "&");
            cString = cString.Replace("&cent;", "¢");
            cString = cString.Replace("&copy;", "©");
            cString = cString.Replace("&divide;", "÷");
            cString = cString.Replace("&gt;", ">");
            cString = cString.Replace("&lt;", "<");
            cString = cString.Replace("&micro;", "µ");
            cString = cString.Replace("&middot;", "·");
            cString = cString.Replace("&para;", "¶");
            cString = cString.Replace("&plusmn;", "±");
            cString = cString.Replace("&euro;", "€");
            cString = cString.Replace("&pound;", "£");
            cString = cString.Replace("&reg;", "®");
            cString = cString.Replace("&sect;", "§");
            cString = cString.Replace("&trade;", "™");
            cString = cString.Replace("&yen;", "¥");
            cString = cString.Replace("&deg;", "°");
            cString = cString.Replace("&aacute;", "á");
            cString = cString.Replace("&Aacute;", "Á");
            cString = cString.Replace("&agrave;", "à");
            cString = cString.Replace("&Agrave;", "À");
            cString = cString.Replace("&acirc;", "â");
            cString = cString.Replace("&Acirc;", "Â");
            cString = cString.Replace("&aring;", "å");
            cString = cString.Replace("&Aring;", "Å");
            cString = cString.Replace("&atilde;", "ã");
            cString = cString.Replace("&Atilde;", "Ã");
            cString = cString.Replace("&auml;", "ä");
            cString = cString.Replace("&Auml;", "Ä");
            cString = cString.Replace("&aelig;", "æ");
            cString = cString.Replace("&AElig;", "Æ");
            cString = cString.Replace("&ccedil;", "ç");
            cString = cString.Replace("&Ccedil;", "Ç");
            cString = cString.Replace("&eacute;", "é");
            cString = cString.Replace("&Eacute;", "É");
            cString = cString.Replace("&egrave;", "è");
            cString = cString.Replace("&Egrave;", "È");
            cString = cString.Replace("&ecirc;", "ê");
            cString = cString.Replace("&Ecirc;", "Ê");
            cString = cString.Replace("&euml;", "ë");
            cString = cString.Replace("&Euml;", "Ë");
            cString = cString.Replace("&iacute;", "í");
            cString = cString.Replace("&Iacute;", "Í");
            cString = cString.Replace("&igrave;", "ì");
            cString = cString.Replace("&Igrave;", "Ì");
            cString = cString.Replace("&icirc;", "î");
            cString = cString.Replace("&Icirc;", "Î");
            cString = cString.Replace("&iuml;", "ï");
            cString = cString.Replace("&Iuml;", "Ï");
            cString = cString.Replace("&ntilde;", "ñ");
            cString = cString.Replace("&Ntilde;", "Ñ");
            cString = cString.Replace("&oacute;", "ó");
            cString = cString.Replace("&Oacute;", "Ó");
            cString = cString.Replace("&ograve;", "ò");
            cString = cString.Replace("&Ograve;", "Ò");
            cString = cString.Replace("&ocirc;", "ô");
            cString = cString.Replace("&Ocirc;", "Ô");
            cString = cString.Replace("&oslash;", "ø");
            cString = cString.Replace("&Oslash;", "Ø");
            cString = cString.Replace("&otilde;", "õ");
            cString = cString.Replace("&Otilde;", "Õ");
            cString = cString.Replace("&ouml;", "ö");
            cString = cString.Replace("&Ouml;", "Ö");
            cString = cString.Replace("&szlig;", "ß");
            cString = cString.Replace("&uacute;", "ú");
            cString = cString.Replace("&Uacute;", "Ú");
            cString = cString.Replace("&ugrave;", "ù");
            cString = cString.Replace("&Ugrave;", "Ù");
            cString = cString.Replace("&ucirc;", "û");
            cString = cString.Replace("&Ucirc;", "Û");
            cString = cString.Replace("&uuml;", "ü");
            cString = cString.Replace("&Uuml;", "Ü");
            cString = cString.Replace("&yuml;", "ÿ");
            cString = cString.Replace("¡", ";");
            cString = cString.Replace("Ã­", "i");
            cString = cString.Replace("Ã³", "o");
            cString = cString.Replace("Ãº", "u");
            cString = cString.Replace("â€™", "-");
            cString = cString.Replace("â€“", "-");
            cString = cString.Replace("â€", "-");
            cString = cString.Replace("â€“", "-");
            cString = cString.Replace("¢", "c");
            cString = cString.Replace("£", "£");
            cString = cString.Replace("¤", "");
            cString = cString.Replace("¥", "");
            cString = cString.Replace("¦", "");
            cString = cString.Replace("§", "§");
            cString = cString.Replace("¨", "");
            cString = cString.Replace("©", "(c)");
            cString = cString.Replace("ª", "");
            cString = cString.Replace("«", "<");
            cString = cString.Replace("¬", "-");
            cString = cString.Replace("­", "-");
            cString = cString.Replace("®", "(r)");
            cString = cString.Replace("¯", "-");
            cString = cString.Replace("°", "");
            cString = cString.Replace("±", "+/-");
            cString = cString.Replace("²", "2");
            //cString = cString.Replace("³", "3");
            cString = cString.Replace("´", "'");
            cString = cString.Replace("µ", "y");
            cString = cString.Replace("¶", "P");
            cString = cString.Replace("·", ".");
            cString = cString.Replace("¸", "");
            cString = cString.Replace("¹", "1");
            cString = cString.Replace("º", "");
            cString = cString.Replace("»", ">");
            cString = cString.Replace("¼", "1/4");
            cString = cString.Replace("½", "1/2");
            cString = cString.Replace("¾", "3/4");
            cString = cString.Replace("¿", "?");
            cString = cString.Replace("À", "A");
            cString = cString.Replace("Á", "A");
            cString = cString.Replace("Â", "A");
            cString = cString.Replace("Ã", "A");
            cString = cString.Replace("Ä", "Ae");
            cString = cString.Replace("Å", "A");
            cString = cString.Replace("Æ", "Ae");
            cString = cString.Replace("Ç", "C");
            cString = cString.Replace("È", "E");
            cString = cString.Replace("É", "E");
            cString = cString.Replace("Ê", "E");
            cString = cString.Replace("Ë", "E");
            cString = cString.Replace("Ì", "I");
            cString = cString.Replace("Í", "I");
            cString = cString.Replace("Î", "I");
            cString = cString.Replace("Ï", "I");
            cString = cString.Replace("Ð", "D");
            cString = cString.Replace("Ñ", "N");
            cString = cString.Replace("Ò", "O");
            cString = cString.Replace("Ó", "O");
            cString = cString.Replace("Ô", "O");
            cString = cString.Replace("Õ", "O");
            cString = cString.Replace("Ö", "Oe");
            cString = cString.Replace("×", "x");
            cString = cString.Replace("Ø", "0");
            cString = cString.Replace("Ù", "U");
            cString = cString.Replace("Ú", "U");
            cString = cString.Replace("Û", "U");
            cString = cString.Replace("Ü", "Ue");
            cString = cString.Replace("Ý", "Y");
            cString = cString.Replace("Þ", "p");
            cString = cString.Replace("ß", "ss");
            cString = cString.Replace("à", "a");
            cString = cString.Replace("á", "a");
            cString = cString.Replace("â", "a");
            cString = cString.Replace("ã", "a");
            cString = cString.Replace("ä", "ae");
            cString = cString.Replace("å", "a");
            cString = cString.Replace("æ", "ae");
            cString = cString.Replace("ç", "c");
            cString = cString.Replace("è", "e");
            cString = cString.Replace("é", "e");
            cString = cString.Replace("ê", "e");
            cString = cString.Replace("ë", "e");
            cString = cString.Replace("ì", "i");
            cString = cString.Replace("í", "i");
            cString = cString.Replace("î", "i");
            cString = cString.Replace("ï", "i");
            cString = cString.Replace("ð", "a");
            cString = cString.Replace("ñ", "n");
            cString = cString.Replace("ò", "o");
            cString = cString.Replace("ó", "o");
            cString = cString.Replace("ô", "o");
            cString = cString.Replace("õ", "o");
            cString = cString.Replace("ö", "oe");
            cString = cString.Replace("ó", "o");
            cString = cString.Replace("÷", "/");
            cString = cString.Replace("ø", "0");
            cString = cString.Replace("ù", "u");
            cString = cString.Replace("ú", "u");
            cString = cString.Replace("û", "u");
            cString = cString.Replace("ü", "ue");
            cString = cString.Replace("ý", "y");
            cString = cString.Replace("þ", "p");
            cString = cString.Replace("ÿ", "y");
            cString = cString.Replace("–", " ");
            cString = cString.Replace("“", "\"");
            cString = cString.Replace("”", "\"");
            cString = cString.Replace("’", "\'");
            cString = cString.Replace("’", "");
            return cString;
        }
        private List<string> SplitIntoChunks(string text, int chunkSize)
        {
            List<string> chunks = new List<string>();
            int offset = 0;
            while (offset < text.Length)
            {
                int size = Math.Min(chunkSize, text.Length - offset);
                chunks.Add(text.Substring(offset, size));
                offset += size;
            }
            return chunks;
        }

        public string translate(string data)
        {
            if (data.Trim().ToString() != "")
            {
                if (Global.traslation_type == 2)
                {
                    try
                    {
                        data = TranslateNew(data);
                    }
                    catch (Exception exx)
                    {
                        data = "";
                    }
                    return data.ToString();
                }
                else
                {
                    try
                    {
                        mac_id = GetMacAddress().ToString();
                    }
                    catch
                    {
                        mac_id = "123";
                    }
                    string username = Environment.UserName;

                    string filename = "";

                    if (Global.traslation_type == 0)
                    {
                        filename = @"C:\Program Files (x86)\Sharingan Translator\Sharingan_Translator.exe";
                    }
                    else
                    {
                        filename = @"C:\Translator\dotnet_translate.exe";
                        data = Base64Encode(data);
                    }
                    while (translator_repeat == 0)
                    {
                        try
                        {
                            string temp_data = data;
                            var psi = new ProcessStartInfo();
                            psi.FileName = filename;
                            //var script = scriptname;
                            if (temp_data.Contains("'"))
                            {
                                temp_data = data.Replace('"', '♥');
                            }
                            temp_data = temp_data.Replace("'", "♫");
                            var text = temp_data;
                            if (Global.traslation_type == 0)
                            {
                                psi.Arguments = $"\"{mac_id}\" \"{"-l"}\" \"{text}\"";
                            }
                            else
                            {
                                psi.Arguments = $"\"{text}\"";
                            }
                            psi.UseShellExecute = false;
                            psi.CreateNoWindow = true;
                            psi.RedirectStandardOutput = true;
                            psi.RedirectStandardError = true;

                            var errors = "";
                            var results = "";

                            using (var process = Process.Start(psi))
                            {

                                results = process.StandardOutput.ReadToEnd();
                                if (Global.traslation_type != 0)
                                {
                                    results = Base64Decode(results).ToString();
                                }
                                results = results.Replace("\r\n", "");
                                results = results.Replace("b'", "");
                                results = results.Replace("b\"", "");
                                if (results.EndsWith("'"))
                                {
                                    results = results.Remove(results.LastIndexOf("'"));
                                }

                                if (results.EndsWith("\""))
                                {
                                    results = results.Remove(results.LastIndexOf("\""));
                                }
                                try
                                {
                                    results = Decode(results);
                                    results = results.Replace('♥', '"');
                                    results = results.Replace("♫", "'");
                                }
                                catch (Exception exx)
                                {
                                    MessageBox.Show("UTF-encoding/decoding error");

                                }
                                errors = process.StandardError.ReadToEnd();

                            }
                            if (results.Contains("An Error occured in Mac ID Authentication"))
                            {

                                MessageBox.Show("An Error occured in Mac ID Authentication", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                                return "error";

                            }

                            results = results.ToString();
                            if (results.Contains("error: "))
                            {
                                translator_repeat = 0;
                            }
                            else
                            {
                                return results;
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                            translator_repeat = 0;
                        }
                    }

                    return "error";
                }
            }
            else
            {
                return data.Trim().ToString();
            }
        }


        private string GetSource2(string url)
        {
            System.Net.WebRequest WReq = null;
            System.Net.WebResponse WRes = null;
            System.IO.StreamReader SReader = null;
            WRes = null;
            string searchData = "";
            try
            {
                ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
                WReq = System.Net.WebRequest.Create(url);
                //WReq.Timeout = 2 * 60 * 1000;
                WRes = WReq.GetResponse();
                SReader = new System.IO.StreamReader(WRes.GetResponseStream());
                searchData = SReader.ReadToEnd();
                WRes.Close();
                WReq = null;
                WRes = null;
            }
            catch
            {
                //GetSource(url);
            }
            return searchData;
        }
        static string Decode(string input)
        {
            var sb = new StringBuilder();
            int position = 0;
            var bytes = new List<byte>();
            while (position < input.Length)
            {
                char c = input[position++];
                if (c == '\\')
                {
                    if (position < input.Length)
                    {
                        c = input[position++];
                        if (c == 'x' && position <= input.Length - 2)
                        {
                            var b = Convert.ToByte(input.Substring(position, 2), 16);
                            position += 2;
                            bytes.Add(b);
                        }
                        else
                        {
                            AppendBytes(sb, bytes);
                            sb.Append('\\');
                            sb.Append(c);
                        }
                        continue;
                    }
                }
                AppendBytes(sb, bytes);
                sb.Append(c);
            }
            AppendBytes(sb, bytes);
            return sb.ToString();
        }

        private static void AppendBytes(StringBuilder sb, List<byte> bytes)
        {
            if (bytes.Count != 0)
            {
                var str = System.Text.Encoding.UTF8.GetString(bytes.ToArray());
                sb.Append(str);
                bytes.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
            Environment.Exit(0);
        }

        public void CollectTenderNos()
        {
            int loop = 0;
            while (loop == 0)
                try
                {
                    ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;//[Masterdb_AMS].[dbo].[tblTenders]
                    String query1 = "Select distinct(tender_notice_no) from [Masterdb_AMS].[dbo].[tblTenders] where source = 'compranet.hacienda.gob.mx'";
                    using (SqlConnection connection = new SqlConnection(ConnectionString))
                    {
                        using (SqlCommand command = new SqlCommand(query1, connection))
                        {
                            command.Connection = connection;
                            using (SqlDataAdapter sda = new SqlDataAdapter(command))
                            {
                                sda.Fill(Tender_Nos);
                            }
                        }
                    }
                    loop++;
                }
                catch (Exception)
                {
                    loop = 0;
                }
        }
    }
}
