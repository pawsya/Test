﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace ETGB
{
    class ClassI
    {
        static SqlConnection sqlconnection;
        public SqlDataReader MySqlDataReader;
        SqlConnection ErrConnection;
        SqlCommand Sqlcmd = new SqlCommand();
        static string ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
        //*******************************************************************************************************************UAS
        int MFA = 0; //0:SelFinance , 
        int status = 2; //0-Fresh Records , 1-in process, 2 - for all clear
        int Com_QC = 0; //1 -CQC Required, 0- Not Required
        int Sel_status = 1;//0- Sel Required,1- Sel High,2- Sel Low,3- Sel Reject
        int CPV_status = 1;////0- CPV Required,1- CPV Done
        int Q_status = 1;//0- QC Required,1- QC Done
        string icb_ncb = "icb";
        int notice_type = 2;
        string reg_Id = "Rg00005";
        Boolean Go = false;
        string filename = string.Empty;
        string gt_idref = string.Empty;
        static DataTable OldLinks = new DataTable();


        public string MySqlQuery = ""; string OnLeft = ""; string OnRight = ""; string OnRight0 = ""; string OnRight1 = ""; string OnRight2 = ""; string ReplyStrings = ""; string MyWorkBuff = ""; string MyNullString = ""; string MySingleSpace = " ";
        public int Posting_Id = 0; int MyBegin = -1; int MyEnd = -1; int MyCurr1 = -1; int MyCurr2 = -1; int MyCurr = -1; int MyReturnValue = 1; int MyReturnCode = 0;
        DateTime MyAddChgTime = System.DateTime.Now; string[] res;

        string Value = "";
        int brk = 0;
        List<string> Fields = new List<string>();

        public bool CheckDuplicate_b4(string tenderNo, string tenderDocFile)
        {


            try
            {
                ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    string query = "";
                    if (tenderNo != "")
                    {
                        query = "Select gt_id from [Masterdb_AMS].[dbo].[tblTenders] where tender_notice_no = N'" + tenderNo.ToString() + "' and org_country = N'" + "MX" + "'";
                    }
                    else
                    {
                        query = "Select gt_id from [Masterdb_AMS].[dbo].[tblTenders] where tender_doc_file = N'" + tenderDocFile.ToString() + "'";
                    }


                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.CommandTimeout = 2000;
                        try
                        {
                            MySqlDataReader = command.ExecuteReader();
                            if (MySqlDataReader.HasRows == true)
                            {
                                Go = true;
                            }
                            else
                            {
                                Go = false;
                            }
                            command.Connection.Close();
                        }
                        catch (Exception ex)
                        { }


                    }
                }


            }
            catch (Exception ex)
            { }
            ShutDataReader();
            return Go;

        }
        public int GoToInsert(string FinalDoc, string FinalTxt, string tempLink)
        {
            FieldsTender(FinalDoc, FinalTxt, tempLink);
            if (Fields[07] != "")
            {
                Fields[07] = Fields[07].Replace("-", "/");
                DateTime dt1 = Convert.ToDateTime(Fields[07]);
                DateTime dt2 = System.DateTime.Today.Date;
                TimeSpan ts = dt1.Subtract(dt2);
                int DateDiff = ts.Days;
                if (DateDiff >= 0)
                {
                    Fields[07] = Fields[07].Replace("/", "-");
                    InsertRecord(Fields, FinalDoc);
                }
                else
                {
                    Global.Skipped++;
                }

            }
            else
            {
                InsertRecord(Fields, FinalDoc);
            }
            brk = 0;

            return 0;
        }

        public void FieldsTender(string Docs, string Txt, string tpLink)
        {
            Fields.Clear();
            for (int i = 0; i < 40; i++) { Fields.Add(""); }

            Docs = Docs.Replace("&amp;", "&").Trim();
            Docs = Docs.Replace("&nbsp;", " ").Trim();
            if (!(Docs.Contains("No Records") || Docs == null))
            {

                try
                {
                    //****************************Tender No. ********************************190 to 200
                    try
                    {
                        OnLeft = "Tender No </td>";
                        OnRight0 = "</td>";
                        OnRight1 = "";
                        OnRight2 = "";
                        ReplyStrings = GetRqdStr(Docs, OnLeft, OnRight0, OnRight1, OnRight2);
                        ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                        Fields[01] = ReplyStrings;
                    }
                    catch
                    {
                        Fields[01] = "";
                    }



                    //=============== [Notice_Type] ========================
                    Fields[21] = "2";
                    //****************************Maj_Org********************************120 to 130
                    try
                    {
                        OnLeft = "Purchaser </td>";
                        OnRight0 = "</td>";
                        OnRight1 = "";
                        OnRight2 = "";
                        ReplyStrings = GetRqdStr(Docs, OnLeft, OnRight0, OnRight1, OnRight2);
                        ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                        //ReplyStrings = Translate(ReplyStrings);
                        ReplyStrings = ReplyStrings.Replace("\n", "");
                        Fields[05] = ReplyStrings.ToUpper();
                    }
                    catch
                    {

                        Fields[05] = "";
                    }

                    //****************************Address********************************20 to 30
                    try
                    {
                        OnLeft = "Purchaser Address </td>";
                        OnRight0 = "</td>";
                        OnRight1 = "";
                        OnRight2 = "";
                        ReplyStrings = GetRqdStr(Docs, OnLeft, OnRight0, OnRight1, OnRight2);
                        ReplyStrings = ReplyStrings.Replace("<br>", "♦");
                        ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                        ReplyStrings = ReplyStrings.Replace("♦", "<br>");
                        Fields[06] = ReplyStrings.Trim();
                    }
                    catch
                    {
                        Fields[06] = "";
                    }
                   
                    //****************************Country********************************70 to 80
                    Fields[04] = "MX";
                    //****************************E-mail ********************************190 to 200
                    try
                    {
                        OnLeft = "Email :";
                        OnRight0 = "</td>";
                        OnRight1 = "";
                        OnRight2 = "";
                        ReplyStrings = GetRqdStr(Docs, OnLeft, OnRight0, OnRight1, OnRight2);
                        ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                        Fields[28] = ReplyStrings;
                    }
                    catch
                    {
                        Fields[28] = "";
                    }

                    //****************************short_desc ********************************190 to 200
                    try
                    {
                        OnLeft = "Notice Title </td>";
                        OnRight0 = "</td>";
                        OnRight1 = "";
                        OnRight2 = "";
                        ReplyStrings = GetRqdStr(Docs, OnLeft, OnRight0, OnRight1, OnRight2);
                        ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                        ReplyStrings = ReplyStrings.Replace("\"", "");
                        ReplyStrings = SentenceCase(ReplyStrings);
                        if (ReplyStrings != "")
                        {
                            Fields[02] = ReplyStrings;
                        }
                        else
                        { }

                    }
                    catch
                    {
                        Fields[02] = "";
                    }

                    //****************************tenders_details********************************180 to 190
                    string desc = string.Empty;
                    string init = string.Empty;
                    string fee = string.Empty;
                    string opnedate = string.Empty;
                    string closedate = string.Empty;
                    string category = string.Empty;
                    string state = string.Empty;

                    if (Docs.Contains("Type Of Tender </td>"))
                    {
                        try
                        {
                            init = Docs.Substring(Docs.IndexOf("Type Of Tender </td>") + "Type Of Tender </td>".Length);
                            init = init.Remove(init.IndexOf("</td>"));
                            init = Regex.Replace(init, @"<[^>]*>", String.Empty).Trim();
                            init = init.Replace("\n", "").Trim();
                            init = init.Replace("\r", "").Trim();
                            init = "<br>Type Of Tender : " + init;
                        }
                        catch { init = ""; }
                    }
                    else
                    { init = ""; }

                    if (Docs.Contains("Published Date </td>"))
                    {
                        try
                        {
                            opnedate = Docs.Substring(Docs.IndexOf("Published Date </td>") + "Published Date </td>".Length);
                            opnedate = opnedate.Remove(opnedate.IndexOf("</td>"));
                            opnedate = Regex.Replace(opnedate, @"<[^>]*>", String.Empty).Trim();
                            opnedate = opnedate.Replace("\n", "").Trim();
                            opnedate = opnedate.Replace("\r", "").Trim();
                            opnedate = "<br>Published Date : " + opnedate;
                        }
                        catch { opnedate = ""; }
                    }
                    else
                    { opnedate = ""; }

                    if (Docs.Contains("Closing Date </td>"))
                    {
                        try
                        {
                            closedate = Docs.Substring(Docs.IndexOf("Closing Date </td>") + "Closing Date </td>".Length);
                            closedate = closedate.Remove(closedate.IndexOf("</td>"));
                            closedate = Regex.Replace(closedate, @"<[^>]*>", String.Empty).Trim();
                            closedate = closedate.Replace("\n", "").Trim();
                            closedate = closedate.Replace("\r", "").Trim();
                            closedate = "<br>Closing Date : " + closedate;
                        }
                        catch { closedate = ""; }
                    }
                    else
                    { closedate = ""; }                                        

                    Fields[03] = "Tenders are invited for : " + Fields[02] +  init + opnedate + closedate;


                    //****************************Deadline ********************************190 to 200
                    try
                    {
                        OnLeft = "Closing Date </td>";
                        OnRight0 = "</td>";
                        OnRight1 = "";
                        OnRight2 = "";
                        ReplyStrings = GetRqdStr(Docs, OnLeft, OnRight0, OnRight1, OnRight2);
                        ReplyStrings = Regex.Replace(ReplyStrings, @"<[^>]*>", String.Empty).Trim();
                        ReplyStrings = ReplyStrings.Replace("\"", "");
                        if (ReplyStrings != "")
                        {
                            Fields[07] = ReplyStrings;
                        }
                        else
                        { }

                    }
                    catch
                    {
                        Fields[07] = "";
                    }

                    //=============== [Contact person] ==========================24
                    if (Docs.Contains("Contact Person :"))
                    {
                        try
                        {
                            Value = Docs.Substring(Docs.IndexOf("Contact Person :") + "Contact Person :".Length);
                            Value = Value.Remove(Value.IndexOf("<br>"));
                            Value = Value.Replace("<br>", "♦").Trim();
                            Value = Regex.Replace(Value, @"<[^>]*>", String.Empty).Trim();
                            Value = Value.Replace("♦", "<br>").Trim();
                            Value = Value.Replace("\r", "").Trim();
                            Value = Value.Replace("\t", "").Trim();
                            Value = Value.Replace("\n", " ").Trim();
                            Fields[35] = Value;
                        }
                        catch { Fields[35] = ""; }
                    }
                    else
                    { Fields[35] = ""; }
                    //=============== [Financier] ==========================
                    Fields[14] = "0";
                    //=============== [Cpv] ================================
                    Fields[17] = "";

                    //=============== [Source] =============================
                    Fields[18] = "compranet.hacienda.gob.mx";
                    //=============== [TenderLink] =========================
                    Fields[19] = tpLink;


                    ReplaceFields(Fields);
                }
                catch (Exception)
                { }
            }
            else
            { }
        }



        public int InsertRecord(List<string> SegFields, string HtmlDoc)
        {          
            SegFields[04] = "MX";
            SegFields[21] = notice_type.ToString();//notice_type
            SegFields[03] = SegFields[03].Replace("\r\n\r\n", "<BR>\r\n");


            SegFields[03] = SegFields[03].Replace("\r\n\r\n", "<BR>\r\n");
            SegFields[05] = SegFields[05].ToUpper();
            if (SegFields[02].Length > 200)
            {
                SegFields[02] = SegFields[02].Remove(200).ToString().Trim();
                SegFields[02] = SegFields[02] + "...";
            }

            SegFields[2] = SegFields[2].Replace("\r\n<BR>", "<BR>\r\n");
            SegFields[2] = SegFields[2].Replace("\r\n<br>", "<BR>\r\n");
            SegFields[2] = SegFields[2].Replace("Na&Nbsp;\r\n<br>", "");
            SegFields[2] = SegFields[2].Replace("Na \r\n<BR>", "");
            SegFields[2] = SegFields[2].Replace("\r\n\r\n", "<BR>\r\n");



            //==============================GoodTenders=======================
            SegFields[25] = Sel_status.ToString();
            SegFields[26] = CPV_status.ToString();
            SegFields[27] = Q_status.ToString();
            SegFields[16] = icb_ncb.ToString();
            SegFields[24] = Com_QC.ToString();
            SegFields[23] = reg_Id;
            SegFields[20] = status.ToString();
            SegFields[14] = MFA.ToString();
            SegFields[15] = MFA.ToString();
            SegFields[05] = SegFields[05].ToUpper();
            //===============================================

            if(SegFields[4] == "" || SegFields[7] == "" || SegFields[2] == "" || SegFields[5] == "")
            {
                SegFields[23] = "Rg00007";
                SegFields[20] = "1";
                SegFields[24] = "1";
            }
            else if (SegFields[4].Length > 3)
            {
                SegFields[23] = "Rg00007";
                SegFields[20] = "1";
                SegFields[24] = "1";
            }
            else
            {
                SegFields[23] = "Rg00005";
                SegFields[20] = "2";
                SegFields[24] = "0";
            }

            CheckDuplicate(SegFields);
            if (Go == true)
            {
                Global.Duplicate++;
                ShutDataReader();
                return 1;
            }
            else
            {
                HtmlDoc = HtmlDoc.Replace("&amp;", "&");

                HtmlDoc = "<html lang=\"en\"><head>  <title>GoodTenders.com | Tenders Document </title> <meta charset = \"utf-8\">   <meta name =\"viewport\" content = \"width=device-width, initial-scale=1\">  <link rel =\"stylesheet\" href =\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\"><script src =\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>   <script src =\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>     </head>" +
                "<body><div class=\"container\">  <h2>Tender Details</h2>  " + HtmlDoc + "</tbody>  </table></div></body></html>";

                string id2 = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                string id = id2;
                Int64 gt_id = Int64.Parse(id.ToString());
                gt_id++;
                gt_idref = gt_id.ToString();
                int a = 0;
                while (a == 0)
                {
                    try
                    {
                        if (System.IO.Directory.Exists(@"Z:"))
                        {
                            string strOpFileName = "Z:\\GT458" + gt_id.ToString() + ".html";
                            filename = "Z:\\GT458" + gt_id.ToString() + ".html";
                            System.IO.StreamWriter swOut = new System.IO.StreamWriter(strOpFileName, false, Encoding.Unicode);
                            swOut.Write(HtmlDoc);
                            swOut.Close();
                            a++;
                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("Please Map DocData folder to  Server..and create Z: Drive", "'" + SegFields[18].ToString() + "'");
                        }
                    }
                    catch (Exception)
                    {
                        a = 0;
                    }
                }
                ShutDataReader();
                int MyLoop = 0;
                while (MyLoop == 0)
                {



                    ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
                    using (SqlConnection connection = new SqlConnection(ConnectionString))
                    {
                        String query = "INSERT INTO [Masterdb_AMS].[dbo].[tblTenders]([file_id],[tender_notice_no],[short_description],[tender_details],[org_country],[organisation_name] ,[org_address] ,[org_email] ,[org_url] ,[org_City] ,[org_State] ,[org_PinCode] ,[org_Tel] ,[org_Fax] ,[org_Contact_Person] ,[deadline] ,[deadline_2] ,[est_cost] ,[currency] ,[doc_cost] ,[doc_start] ,[open_date] ,[earnest_money] ,[financier] ,[MFA] ,[ncbicb] ,[cpv_value] ,[source] ,[tender_doc_file] ,[status],[notice_type] ,[quality_addeddate] ,[file_name] ,[region_id] ,[compulsary_qc] ,[ext1] ,[ext2] ,[Selection_status] ,[CPV_status] ,[quality_status],[added_on]) VALUES (@file_id , @tender_notice_no, @short_description, @tender_details, @org_country, @organisation_name, @org_address, @org_email, @org_url, @org_City, @org_State, @org_PinCode, @org_Tel, @org_Fax, @org_Contact_Person, @deadline, @deadline_2, @est_cost, @currency, @doc_cost, @doc_start, @open_date, @earnest_money, @financier, @MFA, @ncbicb, @cpv_value, @source, @tender_doc_file, @status, @notice_type, @quality_addeddate, @file_name, @region_id, @compulsary_qc, @ext1, @ext2, @Selection_status, @CPV_status, @quality_status,@added_on)";

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@file_id", gt_idref.ToString() + ".html");
                            command.Parameters.AddWithValue("@tender_notice_no", SegFields[01].ToString());
                            command.Parameters.AddWithValue("@short_description", SegFields[02].ToString());
                            command.Parameters.AddWithValue("@tender_details", SegFields[03].ToString());
                            command.Parameters.AddWithValue("@org_country", SegFields[04].ToString());
                            command.Parameters.AddWithValue("@organisation_name", SegFields[05].ToString());
                            command.Parameters.AddWithValue("@org_address", SegFields[06].ToString());
                            command.Parameters.AddWithValue("@org_email", SegFields[28].ToString());
                            command.Parameters.AddWithValue("@org_url", SegFields[29].ToString());
                            command.Parameters.AddWithValue("@org_City", SegFields[30].ToString());
                            command.Parameters.AddWithValue("@org_State", SegFields[31].ToString());
                            command.Parameters.AddWithValue("@org_PinCode", SegFields[32].ToString());
                            command.Parameters.AddWithValue("@org_Tel", SegFields[33].ToString());
                            command.Parameters.AddWithValue("@org_Fax", SegFields[34].ToString());
                            command.Parameters.AddWithValue("@org_Contact_Person", SegFields[35].ToString());
                            command.Parameters.AddWithValue("@deadline", SegFields[07].ToString());
                            command.Parameters.AddWithValue("@deadline_2", SegFields[36].ToString());
                            command.Parameters.AddWithValue("@est_cost", SegFields[08].ToString());
                            command.Parameters.AddWithValue("@currency", SegFields[09].ToString());
                            command.Parameters.AddWithValue("@doc_cost", SegFields[10].ToString());
                            command.Parameters.AddWithValue("@doc_start", SegFields[11].ToString());
                            command.Parameters.AddWithValue("@open_date", SegFields[12].ToString());
                            command.Parameters.AddWithValue("@earnest_money", SegFields[13].ToString());
                            command.Parameters.AddWithValue("@financier", SegFields[14].ToString());
                            command.Parameters.AddWithValue("@MFA", SegFields[15].ToString());
                            command.Parameters.AddWithValue("@ncbicb", SegFields[16].ToString());
                            command.Parameters.AddWithValue("@cpv_value", SegFields[17].ToString());
                            command.Parameters.AddWithValue("@source", SegFields[18].Trim().ToString());
                            command.Parameters.AddWithValue("@tender_doc_file", SegFields[19].ToString());
                            command.Parameters.AddWithValue("@status", SegFields[20].ToString());
                            command.Parameters.AddWithValue("@added_on", DateTime.Now.ToString("MM/dd/yyyy H:mm"));
                            command.Parameters.AddWithValue("@notice_type", SegFields[21].ToString());
                            command.Parameters.AddWithValue("@quality_addeddate", DateTime.Now.ToString("MM/dd/yyyy H:mm"));
                            command.Parameters.AddWithValue("@file_name", filename);
                            command.Parameters.AddWithValue("@region_id", SegFields[23].ToString());
                            command.Parameters.AddWithValue("@compulsary_qc", SegFields[24].ToString());
                            command.Parameters.AddWithValue("@ext1", SegFields[37].ToString());
                            command.Parameters.AddWithValue("@ext2", SegFields[38].ToString());
                            command.Parameters.AddWithValue("@Selection_status", SegFields[25].ToString());
                            command.Parameters.AddWithValue("@CPV_status", SegFields[26].ToString());
                            command.Parameters.AddWithValue("@quality_status", SegFields[27].ToString());

                            #region --Test Query

                            //try
                            //{
                            //    string testquery = query + " VALUES ('" + gt_idref.ToString() + ".html" + "','" + SegFields[01].ToString() + "','" + SegFields[02].ToString() + "','" + SegFields[03].ToString() + "','" + SegFields[04].ToString()
                            //        + "','" + SegFields[05].ToString() + "','" + SegFields[06].ToString() + "','" + SegFields[28].ToString() + "','" + SegFields[29].ToString() + "','" + SegFields[30].ToString() + "','" + SegFields[31].ToString()
                            //        + "','" + SegFields[32].ToString() + "','" + SegFields[33].ToString() + "','" + SegFields[34].ToString() + "','" + SegFields[35].ToString() + "','" + SegFields[07].ToString() + "','" + SegFields[36].ToString()
                            //        + "','" + SegFields[08].ToString() + "','" + SegFields[09].ToString() + "','" + SegFields[10].ToString() + "','" + SegFields[11].ToString() + "','" + SegFields[12].ToString() + "','" + SegFields[13].ToString() + "','" + SegFields[14].ToString() + "','" + SegFields[15].ToString()
                            //        + "','" + SegFields[16].ToString() + "','" + SegFields[17].ToString() + "','" + SegFields[18].ToString() + "','" + SegFields[19].ToString() + "','" + SegFields[20].ToString()
                            //        + "','" + DateTime.Now.ToString("MM/dd/yyyy H:mm") + "','" + SegFields[21].ToString() + "','" + DateTime.Now.ToString("MM/dd/yyyy H:mm") + "','" + filename
                            //        + "','" + SegFields[23].ToString() + "','" + SegFields[24].ToString() + "','" + SegFields[37].ToString() + "','" + SegFields[38].ToString() + "','" + SegFields[25].ToString() + "','" + SegFields[26].ToString() + "','" + SegFields[27].ToString() + "')";
                            //}
                            //catch (Exception e)
                            //{ }
                            #endregion
                            try
                            {
                                connection.Open();
                                int result = command.ExecuteNonQuery();
                                // Check Error
                                if (result == 1)
                                    MyLoop = 1;
                                else
                                    MyLoop = 0;

                                if (result == 1)
                                {
                                    Global.Inserted++;
                                }



                            }
                            catch (Exception ex)
                            {
                                string query1 = "INSERT INTO [Masterdb_AMS].[dbo].[tblTenders] (Error_Message,Function_Name,Exe_Name) Values ('" + ex.Message.Replace("'", "`").ToString() + "','" + System.Reflection.MethodBase.GetCurrentMethod().Name.ToString() + "','" + Application.ProductName.ToString() + "')";
                               
                                if (ex.Message.Contains("Duplicate entry"))
                                {
                                    MyLoop = 1;
                                }
                                else if (ex.Message.Contains("Fatal error encountered during command execution."))
                                {
                                    MyLoop = 0;
                                }
                                else
                                {
                                    MyLoop = 0;
                                }
                            }

                        }
                    }


                }





            }

            InsertRecord_Live(SegFields, HtmlDoc);
            ShutDataReader();

            return MyReturnValue;
        }

        

        public int InsertRecord_Live(List<string> SegFields, string HtmlDoc)
        {
            ShutDataReader();
            int MyLoop = 0;

            while (MyLoop == 0)
            {
                ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    String query = "INSERT INTO [Masterdb_AMSFinal].[dbo].[tblTenders]([file_id],[tender_notice_no],[short_description],[tender_details],[org_country],[organisation_name] ,[org_address] ,[org_email] ,[org_url] ,[org_City] ,[org_State] ,[org_PinCode] ,[org_Tel] ,[org_Fax] ,[org_Contact_Person] ,[deadline] ,[deadline_2] ,[est_cost] ,[currency] ,[doc_cost] ,[doc_start] ,[open_date] ,[earnest_money] ,[financier] ,[MFA] ,[ncbicb] ,[cpv_value] ,[source] ,[tender_doc_file] ,[status],[notice_type] ,[quality_addeddate] ,[file_name] ,[region_id] ,[compulsary_qc] ,[ext1] ,[ext2] ,[Selection_status] ,[CPV_status] ,[quality_status],[added_on]) VALUES (@file_id , @tender_notice_no, @short_description, @tender_details, @org_country, @organisation_name, @org_address, @org_email, @org_url, @org_City, @org_State, @org_PinCode, @org_Tel, @org_Fax, @org_Contact_Person, @deadline, @deadline_2, @est_cost, @currency, @doc_cost, @doc_start, @open_date, @earnest_money, @financier, @MFA, @ncbicb, @cpv_value, @source, @tender_doc_file, @status, @notice_type, @quality_addeddate, @file_name, @region_id, @compulsary_qc, @ext1, @ext2, @Selection_status, @CPV_status, @quality_status,@added_on)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@file_id", gt_idref.ToString() + ".html");
                        command.Parameters.AddWithValue("@tender_notice_no", SegFields[01].ToString());
                        command.Parameters.AddWithValue("@short_description", SegFields[02].ToString());
                        command.Parameters.AddWithValue("@tender_details", SegFields[03].ToString());
                        command.Parameters.AddWithValue("@org_country", SegFields[04].ToString());
                        command.Parameters.AddWithValue("@organisation_name", SegFields[05].ToString());
                        command.Parameters.AddWithValue("@org_address", SegFields[06].ToString());
                        command.Parameters.AddWithValue("@org_email", SegFields[28].ToString());
                        command.Parameters.AddWithValue("@org_url", SegFields[29].ToString());
                        command.Parameters.AddWithValue("@org_City", SegFields[30].ToString());
                        command.Parameters.AddWithValue("@org_State", SegFields[31].ToString());
                        command.Parameters.AddWithValue("@org_PinCode", SegFields[32].ToString());
                        command.Parameters.AddWithValue("@org_Tel", SegFields[33].ToString());
                        command.Parameters.AddWithValue("@org_Fax", SegFields[34].ToString());
                        command.Parameters.AddWithValue("@org_Contact_Person", SegFields[35].ToString());
                        command.Parameters.AddWithValue("@deadline", SegFields[07].ToString());
                        command.Parameters.AddWithValue("@deadline_2", SegFields[36].ToString());
                        command.Parameters.AddWithValue("@est_cost", SegFields[08].ToString());
                        command.Parameters.AddWithValue("@currency", SegFields[09].ToString());
                        command.Parameters.AddWithValue("@doc_cost", SegFields[10].ToString());
                        command.Parameters.AddWithValue("@doc_start", SegFields[11].ToString());
                        command.Parameters.AddWithValue("@open_date", SegFields[12].ToString());
                        command.Parameters.AddWithValue("@earnest_money", SegFields[13].ToString());
                        command.Parameters.AddWithValue("@financier", SegFields[14].ToString());
                        command.Parameters.AddWithValue("@MFA", SegFields[15].ToString());
                        command.Parameters.AddWithValue("@ncbicb", SegFields[16].ToString());
                        command.Parameters.AddWithValue("@cpv_value", SegFields[17].ToString());
                        command.Parameters.AddWithValue("@source", SegFields[18].Trim().ToString());
                        command.Parameters.AddWithValue("@tender_doc_file", SegFields[19].ToString());
                        command.Parameters.AddWithValue("@status", SegFields[20].ToString());
                        command.Parameters.AddWithValue("@added_on", DateTime.Now.ToString("MM/dd/yyyy H:mm"));
                        command.Parameters.AddWithValue("@notice_type", SegFields[21].ToString());
                        command.Parameters.AddWithValue("@quality_addeddate", DateTime.Now.ToString("MM/dd/yyyy H:mm"));
                        command.Parameters.AddWithValue("@file_name", filename);
                        command.Parameters.AddWithValue("@region_id", SegFields[23].ToString());
                        command.Parameters.AddWithValue("@compulsary_qc", SegFields[24].ToString());
                        command.Parameters.AddWithValue("@ext1", SegFields[37].ToString());
                        command.Parameters.AddWithValue("@ext2", SegFields[38].ToString());
                        command.Parameters.AddWithValue("@Selection_status", SegFields[25].ToString());
                        command.Parameters.AddWithValue("@CPV_status", SegFields[26].ToString());
                        command.Parameters.AddWithValue("@quality_status", SegFields[27].ToString());


                        try
                        {
                            connection.Open();

                            int result = command.ExecuteNonQuery();
                            // Check Error
                            if (result == 1)
                                MyLoop = 1;
                            else
                                MyLoop = 0;


                        }
                        catch (Exception ex)
                        {
                            string query1 = "INSERT INTO [Masterdb_AMSFinal].[dbo].[tblTenders] (Error_Message,Function_Name,Exe_Name) Values ('" + ex.Message.Replace("'", "`").ToString() + "','" + System.Reflection.MethodBase.GetCurrentMethod().Name.ToString() + "','" + Application.ProductName.ToString() + "')";
                            
                            if (ex.Message.Contains("Duplicate entry"))
                            {
                                MyLoop = 1;
                            }
                            else if (ex.Message.Contains("Fatal error encountered during command execution."))
                            {
                                MyLoop = 0;
                            }
                            else
                            {
                                MyLoop = 0;
                            }
                        }
                    }
                }
            }
            return MyReturnValue;
        }

        private SqlDataReader CheckDuplicate(List<string> SegFields)
        {

            SegFields[18] = "compranet.hacienda.gob.mx";
            SegFields[01] = SegFields[01].Trim();
            SegFields[2] = SegFields[2].Trim();
            SegFields[19] = SegFields[19].Trim();
            try
            {
                ConnectionString = ConfigurationManager.ConnectionStrings["LiveCon"].ConnectionString;
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    string query = "";
                    if (SegFields[01].ToString() != "" && SegFields[04].ToString() != "" && SegFields[07].ToString() != "")//notice_no and country
                    {
                        query = "Select gt_id from [Masterdb_AMS].[dbo].[tblTenders]  where tender_notice_no = N'" + SegFields[01].ToString() + "' and org_country = N'" + SegFields[04].ToString() + "' and deadline = N'" + SegFields[07].ToString() + "'";
                    }
                    else if (SegFields[01].ToString() != "" && SegFields[04].ToString() != "")//notice_no and country
                    {
                        query = "Select gt_id from[Masterdb_AMS].[dbo].[tblTenders] where tender_notice_no = N'" + SegFields[01].ToString() + "' and org_country = N'" + SegFields[04].ToString() + "'";
                    }
                    else if (SegFields[02].ToString() != "" && SegFields[07].ToString() != "")//shortdesc and notice_no
                    {
                        query = "Select gt_id from[Masterdb_AMS].[dbo].[tblTenders] where short_description = N'" + SegFields[02].ToString() + "' and deadline = N'" + SegFields[07].ToString() + "'";
                    }
                    else
                    {
                        //shortdesc and country
                        query = "Select gt_id from[Masterdb_AMS].[dbo].[tblTenders] where short_description = N'" + SegFields[02].ToString() + "' and org_country = N'" + SegFields[04].ToString() + "'";
                    }

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        command.CommandTimeout = 2000;
                        try
                        {
                            MySqlDataReader = command.ExecuteReader();
                            if (MySqlDataReader.HasRows == true)
                            {
                                Go = true;
                            }
                            else
                            {
                                Go = false;
                            }
                            command.Connection.Close();
                        }
                        catch (Exception)
                        { }


                    }
                }


            }
            catch (Exception)
            { }
            ShutDataReader();
            return MySqlDataReader;

        }



        private void ShutDataReader()
        {
            MySqlDataReader.Close();
            MySqlDataReader.Dispose();
        }


        public static string SentenceCase(string message)
        {
            var lowerCase = message.ToLower();
            // matches the first sentence of a string, as well as subsequent sentences
            var r = new Regex(@"(^[a-z])|\.\s+(.)", RegexOptions.ExplicitCapture);
            // MatchEvaluator delegate defines replacement of setence starts to uppercase
            var result = r.Replace(lowerCase, s => s.Value.ToUpper());

            return result;

        }
        public string[] GetResult(string Email)
        {
            MatchCollection coll = default(MatchCollection);
            int i = 0;
            //email_id REGEXP  '^[a-zA-Z0-9][+a-zA-Z0-9._-]*@[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9]*\\.[a-zA-Z]{2,4}$'

            coll = Regex.Matches(Email, "([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})");
            string[] results = new string[coll.Count];
            for (i = 0; i <= results.Length - 1; i++)
            {
                results[i] = coll[i].Value;
            }
            return results;
        }

        public void ReplaceFields(List<string> Fields)
        {
            for (int i = 0; i < Fields.Count(); i++)
            {
                Fields[i] = Fields[i].Replace("‘", "`");
                Fields[i] = Fields[i].Replace("’", "`");
                //Fields[i] = Fields[i].Replace("'", "`");// for MySql
                Fields[i] = Fields[i].Replace("&amp;", "&");
                Fields[i] = Fields[i].Replace("&nbsp;", " ");
                Fields[i] = Regex.Replace(Fields[i], "&AMP;", "&", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&nbsp;", "", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#32;", "", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#33;", "!", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#34;", "\"", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#35;", "#", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#36;", "$", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#37;", "%", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#40;", "(", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#41;", ")", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#42;", "*", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#43;", "+", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#44;", ",", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#45;", "-", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#46;", ".", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#47;", "/", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#8211;", "–", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#8212;", "—", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#8216;", "‘", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#8217;", "’", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#8218;", "‚", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#8220;", "“", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#8221;", "”", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#8222;", "„", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#38;", "&", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&#39;", "''", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "&quot;", "“", RegexOptions.IgnoreCase);
                Fields[i] = Regex.Replace(Fields[i], "'", "''", RegexOptions.IgnoreCase);
            }
        }
        public string GetRqdStr(string TheString, string OnLeft, string OnRight0, string OnRight1, string OnRight2)
        {

            if (TheString != null && TheString.Trim() != null)
            {
                MyBegin = TheString.IndexOf(OnLeft, 0);
                if (MyBegin == -1)
                {
                    ReplyStrings = "";
                }
                else
                {
                    if (OnRight0 == null || OnRight0 == "")
                    {
                        MyCurr = -1;
                    }
                    else
                    {
                        MyCurr = TheString.IndexOf(OnRight0, (MyBegin + OnLeft.Length));
                    }
                    if (OnRight1 == null || OnRight1 == "")
                    {
                        MyCurr1 = -1;
                    }
                    else
                    {
                        MyCurr1 = TheString.IndexOf(OnRight1, (MyBegin + OnLeft.Length));
                    }
                    if (OnRight2 == null || OnRight2 == "")
                    {
                        MyCurr2 = -1;
                    }
                    else
                    {
                        MyCurr2 = TheString.IndexOf(OnRight2, (MyBegin + OnLeft.Length));
                    }
                    if (MyCurr == -1 && MyCurr1 == -1 && MyCurr2 == -1)
                    {
                        MyEnd = TheString.Length;
                    }
                    else
                    {
                        if (MyCurr == -1)
                        {
                            if (MyCurr1 == -1)
                            {
                                MyEnd = MyCurr2;
                                OnRight = OnRight2;
                            }
                            else
                            {
                                if (MyCurr2 == -1)
                                {
                                    MyEnd = MyCurr1;
                                    OnRight = OnRight1;
                                }
                                else
                                {
                                    if (MyCurr1 < MyCurr2)
                                    {
                                        MyEnd = MyCurr1;
                                        OnRight = OnRight1;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr2;
                                        OnRight = OnRight2;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (MyCurr1 == -1)
                            {
                                if (MyCurr2 == -1)
                                {
                                    MyEnd = MyCurr;
                                    OnRight = OnRight0;
                                }
                                else
                                {
                                    if (MyCurr < MyCurr2)
                                    {
                                        MyEnd = MyCurr;
                                        OnRight = OnRight0;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr2;
                                        OnRight = OnRight2;
                                    }
                                }
                            }
                            else
                            {
                                if (MyCurr2 == -1)
                                {
                                    if (MyCurr < MyCurr1)
                                    {
                                        MyEnd = MyCurr;
                                        OnRight = OnRight0;
                                    }
                                    else
                                    {
                                        MyEnd = MyCurr1;
                                        OnRight = OnRight1;
                                    }
                                }
                                else
                                {
                                    if (MyCurr < MyCurr1)
                                    {
                                        if (MyCurr < MyCurr2)
                                        {
                                            MyEnd = MyCurr;
                                            OnRight = OnRight0;
                                        }
                                        else
                                        {
                                            MyEnd = MyCurr2;
                                            OnRight = OnRight2;
                                        }
                                    }
                                    else
                                    {
                                        if (MyCurr2 < MyCurr1)
                                        {
                                            MyEnd = MyCurr2;
                                            OnRight = OnRight2;
                                        }
                                        else
                                        {
                                            MyEnd = MyCurr1;
                                            OnRight = OnRight1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    MyWorkBuff = TheString.Substring((MyBegin + OnLeft.Length),
                                                 (MyEnd - MyBegin - OnLeft.Length));
                    ReplyStrings = MyWorkBuff.Trim();
                    //ReplyStrings = MyWorkBuff.Replace(Environment.NewLine, "");                   
                }
            }
            else
            {
                ReplyStrings = "";
            }
            return ReplyStrings.Trim();
        }
    }
}
