﻿namespace ETGB
{
    partial class Frmstr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmstr));
            this.rbtn_Live = new System.Windows.Forms.RadioButton();
            this.rbtn_test = new System.Windows.Forms.RadioButton();
            this.Start_Button = new System.Windows.Forms.Button();
            this.DateFrm = new System.Windows.Forms.TextBox();
            this.FrmCal = new System.Windows.Forms.MonthCalendar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FrmCal_Btn = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbtn_Live
            // 
            this.rbtn_Live.AutoSize = true;
            this.rbtn_Live.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn_Live.Location = new System.Drawing.Point(6, 19);
            this.rbtn_Live.Name = "rbtn_Live";
            this.rbtn_Live.Size = new System.Drawing.Size(55, 20);
            this.rbtn_Live.TabIndex = 0;
            this.rbtn_Live.TabStop = true;
            this.rbtn_Live.Text = "Live";
            this.rbtn_Live.UseVisualStyleBackColor = true;
            this.rbtn_Live.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rbtn_test
            // 
            this.rbtn_test.AutoSize = true;
            this.rbtn_test.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn_test.Location = new System.Drawing.Point(92, 19);
            this.rbtn_test.Name = "rbtn_test";
            this.rbtn_test.Size = new System.Drawing.Size(57, 20);
            this.rbtn_test.TabIndex = 1;
            this.rbtn_test.TabStop = true;
            this.rbtn_test.Text = "Test";
            this.rbtn_test.UseVisualStyleBackColor = true;
            this.rbtn_test.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // Start_Button
            // 
            this.Start_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Start_Button.Location = new System.Drawing.Point(14, 67);
            this.Start_Button.Name = "Start_Button";
            this.Start_Button.Size = new System.Drawing.Size(141, 32);
            this.Start_Button.TabIndex = 2;
            this.Start_Button.Text = "Start";
            this.Start_Button.UseVisualStyleBackColor = true;
            this.Start_Button.Click += new System.EventHandler(this.button1_Click);
            // 
            // DateFrm
            // 
            this.DateFrm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateFrm.Location = new System.Drawing.Point(175, 89);
            this.DateFrm.Name = "DateFrm";
            this.DateFrm.Size = new System.Drawing.Size(153, 22);
            this.DateFrm.TabIndex = 3;
            this.DateFrm.Click += new System.EventHandler(this.DateFrm_Click);
            // 
            // FrmCal
            // 
            this.FrmCal.Location = new System.Drawing.Point(175, 18);
            this.FrmCal.Name = "FrmCal";
            this.FrmCal.TabIndex = 5;
            this.FrmCal.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.FrmCal_DateChanged);
            this.FrmCal.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.FrmCal_DateSelected);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtn_Live);
            this.groupBox1.Controls.Add(this.rbtn_test);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(14, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(161, 49);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Server";
            // 
            // FrmCal_Btn
            // 
            this.FrmCal_Btn.Location = new System.Drawing.Point(334, 89);
            this.FrmCal_Btn.Name = "FrmCal_Btn";
            this.FrmCal_Btn.Size = new System.Drawing.Size(31, 23);
            this.FrmCal_Btn.TabIndex = 4;
            this.FrmCal_Btn.Text = "...";
            this.FrmCal_Btn.UseVisualStyleBackColor = true;
            this.FrmCal_Btn.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(12, 116);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(79, 17);
            this.radioButton1.TabIndex = 119;
            this.radioButton1.Text = "Sharinghan";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Checked = true;
            this.radioButton3.Location = new System.Drawing.Point(12, 139);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(93, 17);
            this.radioButton3.TabIndex = 120;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Bing Translate";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(12, 163);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(77, 17);
            this.radioButton4.TabIndex = 121;
            this.radioButton4.Text = "Google Api";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // Frmstr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(404, 247);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.FrmCal);
            this.Controls.Add(this.FrmCal_Btn);
            this.Controls.Add(this.DateFrm);
            this.Controls.Add(this.Start_Button);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frmstr";
            this.Text = "compranet.hacienda.gob.mx";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbtn_Live;
        private System.Windows.Forms.RadioButton rbtn_test;
        private System.Windows.Forms.Button Start_Button;
        private System.Windows.Forms.TextBox DateFrm;
        private System.Windows.Forms.MonthCalendar FrmCal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button FrmCal_Btn;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
    }
}

