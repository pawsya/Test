﻿namespace ETGB
{
    partial class FrmRun
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRun));
            this.panel1 = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_linkcol = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbl_chk3 = new System.Windows.Forms.Label();
            this.lbl_chk2 = new System.Windows.Forms.Label();
            this.lbl_chk1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_inserted = new System.Windows.Forms.Label();
            this.lbl_duplicate = new System.Windows.Forms.Label();
            this.lbl_current = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.lbltimer = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1pno = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Insert_btn = new System.Windows.Forms.Button();
            this.Expire_label = new System.Windows.Forms.Label();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_duplicate_link = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbl_duplicate_link);
            this.panel1.Controls.Add(this.statusStrip1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.lbl_linkcol);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.lbltimer);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label1pno);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Insert_btn);
            this.panel1.Controls.Add(this.Expire_label);
            this.panel1.Controls.Add(this.webBrowser1);
            this.panel1.Location = new System.Drawing.Point(-1, 49);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1365, 688);
            this.panel1.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(10, 518);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(119, 22);
            this.statusStrip1.TabIndex = 7;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Pink;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(981, 444);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 25);
            this.button1.TabIndex = 20;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_linkcol
            // 
            this.lbl_linkcol.AutoSize = true;
            this.lbl_linkcol.BackColor = System.Drawing.Color.Cyan;
            this.lbl_linkcol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_linkcol.Location = new System.Drawing.Point(1027, 98);
            this.lbl_linkcol.Name = "lbl_linkcol";
            this.lbl_linkcol.Size = new System.Drawing.Size(41, 15);
            this.lbl_linkcol.TabIndex = 19;
            this.lbl_linkcol.Text = "label6";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbl_chk3);
            this.groupBox2.Controls.Add(this.lbl_chk2);
            this.groupBox2.Controls.Add(this.lbl_chk1);
            this.groupBox2.Location = new System.Drawing.Point(968, 320);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(167, 71);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CheckDuplicate Links";
            // 
            // lbl_chk3
            // 
            this.lbl_chk3.AutoSize = true;
            this.lbl_chk3.ForeColor = System.Drawing.Color.CadetBlue;
            this.lbl_chk3.Location = new System.Drawing.Point(10, 55);
            this.lbl_chk3.Name = "lbl_chk3";
            this.lbl_chk3.Size = new System.Drawing.Size(43, 13);
            this.lbl_chk3.TabIndex = 2;
            this.lbl_chk3.Text = "Status..";
            // 
            // lbl_chk2
            // 
            this.lbl_chk2.AutoSize = true;
            this.lbl_chk2.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lbl_chk2.Location = new System.Drawing.Point(10, 37);
            this.lbl_chk2.Name = "lbl_chk2";
            this.lbl_chk2.Size = new System.Drawing.Size(90, 13);
            this.lbl_chk2.TabIndex = 1;
            this.lbl_chk2.Text = "Total Links After :";
            // 
            // lbl_chk1
            // 
            this.lbl_chk1.AutoSize = true;
            this.lbl_chk1.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_chk1.Location = new System.Drawing.Point(10, 16);
            this.lbl_chk1.Name = "lbl_chk1";
            this.lbl_chk1.Size = new System.Drawing.Size(65, 13);
            this.lbl_chk1.TabIndex = 0;
            this.lbl_chk1.Text = "Total Links :";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.groupBox1.Controls.Add(this.lbl_inserted);
            this.groupBox1.Controls.Add(this.lbl_duplicate);
            this.groupBox1.Controls.Add(this.lbl_current);
            this.groupBox1.Controls.Add(this.lbl_total);
            this.groupBox1.Location = new System.Drawing.Point(947, 166);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 117);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            // 
            // lbl_inserted
            // 
            this.lbl_inserted.AutoSize = true;
            this.lbl_inserted.Location = new System.Drawing.Point(17, 98);
            this.lbl_inserted.Name = "lbl_inserted";
            this.lbl_inserted.Size = new System.Drawing.Size(34, 13);
            this.lbl_inserted.TabIndex = 6;
            this.lbl_inserted.Text = "Total:";
            // 
            // lbl_duplicate
            // 
            this.lbl_duplicate.AutoSize = true;
            this.lbl_duplicate.Location = new System.Drawing.Point(17, 72);
            this.lbl_duplicate.Name = "lbl_duplicate";
            this.lbl_duplicate.Size = new System.Drawing.Size(34, 13);
            this.lbl_duplicate.TabIndex = 5;
            this.lbl_duplicate.Text = "Total:";
            this.lbl_duplicate.Click += new System.EventHandler(this.lbl_duplicate_Click);
            // 
            // lbl_current
            // 
            this.lbl_current.AutoSize = true;
            this.lbl_current.Location = new System.Drawing.Point(17, 45);
            this.lbl_current.Name = "lbl_current";
            this.lbl_current.Size = new System.Drawing.Size(34, 13);
            this.lbl_current.TabIndex = 4;
            this.lbl_current.Text = "Total:";
            this.lbl_current.Click += new System.EventHandler(this.lbl_current_Click);
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Location = new System.Drawing.Point(17, 19);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(34, 13);
            this.lbl_total.TabIndex = 3;
            this.lbl_total.Text = "Total:";
            this.lbl_total.Click += new System.EventHandler(this.lbl_total_Click);
            // 
            // lbltimer
            // 
            this.lbltimer.AutoSize = true;
            this.lbltimer.Location = new System.Drawing.Point(1033, 411);
            this.lbltimer.Name = "lbltimer";
            this.lbltimer.Size = new System.Drawing.Size(35, 13);
            this.lbltimer.TabIndex = 13;
            this.lbltimer.Text = "label6";
            this.lbltimer.Click += new System.EventHandler(this.label2linkcol_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(449, 345);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 12;
            // 
            // label1pno
            // 
            this.label1pno.AutoSize = true;
            this.label1pno.Location = new System.Drawing.Point(97, 345);
            this.label1pno.Name = "label1pno";
            this.label1pno.Size = new System.Drawing.Size(0, 13);
            this.label1pno.TabIndex = 11;
            this.label1pno.Click += new System.EventHandler(this.label_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 336);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 10;
            // 
            // Insert_btn
            // 
            this.Insert_btn.BackColor = System.Drawing.Color.Lime;
            this.Insert_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Insert_btn.Location = new System.Drawing.Point(986, 289);
            this.Insert_btn.Name = "Insert_btn";
            this.Insert_btn.Size = new System.Drawing.Size(149, 25);
            this.Insert_btn.TabIndex = 9;
            this.Insert_btn.Text = "Click 2 Insert";
            this.Insert_btn.UseVisualStyleBackColor = false;
            this.Insert_btn.Click += new System.EventHandler(this.Insert_btn_Click);
            // 
            // Expire_label
            // 
            this.Expire_label.AutoSize = true;
            this.Expire_label.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Expire_label.ForeColor = System.Drawing.Color.Red;
            this.Expire_label.Location = new System.Drawing.Point(479, 268);
            this.Expire_label.Name = "Expire_label";
            this.Expire_label.Size = new System.Drawing.Size(160, 56);
            this.Expire_label.TabIndex = 8;
            this.Expire_label.Text = "label5";
            this.Expire_label.Visible = false;
            this.Expire_label.Click += new System.EventHandler(this.Expire_label_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.webBrowser1.Location = new System.Drawing.Point(0, 0);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(1163, 540);
            this.webBrowser1.TabIndex = 0;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            this.webBrowser1.Navigating += new System.Windows.Forms.WebBrowserNavigatingEventHandler(this.webBrowser1_Navigating);
            this.webBrowser1.ProgressChanged += new System.Windows.Forms.WebBrowserProgressChangedEventHandler(this.webBrowser1_ProgressChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(-1, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(1163, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(206, 750);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Total :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(264, 750);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Max Count";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(368, 750);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "C.Count";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl_duplicate_link
            // 
            this.lbl_duplicate_link.AutoSize = true;
            this.lbl_duplicate_link.BackColor = System.Drawing.Color.Cyan;
            this.lbl_duplicate_link.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_duplicate_link.Location = new System.Drawing.Point(1027, 136);
            this.lbl_duplicate_link.Name = "lbl_duplicate_link";
            this.lbl_duplicate_link.Size = new System.Drawing.Size(41, 15);
            this.lbl_duplicate_link.TabIndex = 21;
            this.lbl_duplicate_link.Text = "label6";
            // 
            // FrmRun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1186, 596);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmRun";
            this.Text = "compranet.hacienda.gob.mx";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Load += new System.EventHandler(this.FrmRun_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Label Expire_label;
        private System.Windows.Forms.Button Insert_btn;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1pno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbltimer;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_duplicate;
        private System.Windows.Forms.Label lbl_current;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbl_chk3;
        private System.Windows.Forms.Label lbl_chk2;
        private System.Windows.Forms.Label lbl_chk1;
        public System.Windows.Forms.Label lbl_inserted;
        private System.Windows.Forms.Label lbl_linkcol;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_duplicate_link;
    }
}