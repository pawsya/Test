﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ETGB
{
    public partial class Frmstr : Form
    {
        public Frmstr()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FrmCal.Visible = false;
            DateFrm.Text = DateTime.Today.AddDays(-1).ToString("yyyy-MM-dd");
            Global.DateFrm = DateFrm.Text;
            rbtn_Live.Checked = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            switch(rbtn_Live.Checked)
            {
                case checked(true):
                    this.Text = "compranet.hacienda.gob.mx (Live)";
                    Global.Conserver = "Live";
                    break;

                case checked(false):
                    this.Text = "compranet.hacienda.gob.mx (Test)";
                    Global.Conserver = "Test";
                    break;

                default:
                    this.Text = "compranet.hacienda.gob.mx (Live)";
                    Global.Conserver = "Live";
                    break;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmRun fr = new FrmRun();
            fr.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if(FrmCal.Visible==false)
            {
                FrmCal.Visible = true;
            }
            else
            {
                FrmCal.Visible = false;
            }
        }

        private void FrmCal_DateSelected(object sender, DateRangeEventArgs e)
        {
            FrmCal.Visible = false;
            DateFrm.Text = FrmCal.SelectionEnd.ToString("yyyy-MM-dd");
            Global.DateFrm = DateFrm.Text;
        }

        private void FrmCal_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void DateFrm_Click(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            Global.traslation_type = 0;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Global.traslation_type = 1;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Global.traslation_type = 2;
        }
    }
}
